import express from "express";
import Auth from "../middlewares/auth";
import HandleErrors from "../middlewares/handleError";

import {
    create,
    deleteReminder,
    getReminderbyUserId,
    updateRemindersNotification,
    sendTestNotification
} from "../controllers/ReminderController";

const RemindersRoutes = express.Router();

RemindersRoutes.post("/add", Auth, HandleErrors(create));

RemindersRoutes.get("/get-reminder/:user_id",Auth, HandleErrors(getReminderbyUserId));

RemindersRoutes.delete("/delete/:_id",Auth, HandleErrors(deleteReminder));
RemindersRoutes.post("/notification/update",Auth, HandleErrors(updateRemindersNotification));

// for notification testing purpose
RemindersRoutes.post("/notification", HandleErrors(sendTestNotification));

export default RemindersRoutes;
