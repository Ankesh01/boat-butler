import express from "express";
import Auth from "../middlewares/auth";

import HandleErrors from "../middlewares/handleError";

import { getAllQuestionnaire } from "../controllers/PageController";

const PagesRoutes = express.Router();

PagesRoutes.get("/get-all",Auth, HandleErrors(getAllQuestionnaire));

export default PagesRoutes;
