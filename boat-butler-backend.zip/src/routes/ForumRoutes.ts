import express from "express";

import HandleErrors from "../middlewares/handleError";

import {
  getAllForum,
  addForumTopics,
  getUserForumTopicById,
} from "../controllers/ForumController";
import Auth from "../middlewares/auth";
const ForumRoutes = express.Router();

ForumRoutes.get("/get-all", HandleErrors(getAllForum));
ForumRoutes.post("/get-userforum", HandleErrors(getUserForumTopicById));
ForumRoutes.post("/add", HandleErrors(addForumTopics));

// Auth,

export default ForumRoutes;
