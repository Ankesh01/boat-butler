import express from "express";
import Auth from "../middlewares/auth";

import HandleErrors from "../middlewares/handleError";

import { getPlanList, create, androidWebhook, getPaymentHistory } from "../controllers/PaymentContoller";

const paymentRoutes = express.Router();

paymentRoutes.get("/get-plans", Auth, HandleErrors(getPlanList));
paymentRoutes.post("/create", Auth, HandleErrors(create));
paymentRoutes.post("/webhook/android", HandleErrors(androidWebhook));
paymentRoutes.get(
  "/get-payment-history",
  Auth,
  HandleErrors(getPaymentHistory)
);

export default paymentRoutes;
