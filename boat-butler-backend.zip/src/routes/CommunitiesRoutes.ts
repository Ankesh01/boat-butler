import express from "express";

import HandleErrors from "../middlewares/handleError";

import {
  create,
  getCommunityById,
  getCommunityPosts,
  joinCommunity,
  getCommunityList,
  editCommunity,
  getCommunityDetails,
  communityRequest,
  deleteMember,
  communityReport,
} from "../controllers/CommunitiesController";
import Auth from "../middlewares/auth";

const CommunititesRoutes = express.Router();

CommunititesRoutes.post("/create", Auth, HandleErrors(create));
CommunititesRoutes.put("/edit/:id", Auth, HandleErrors(editCommunity));
CommunititesRoutes.put("/request-action", Auth, HandleErrors(communityRequest));
CommunititesRoutes.put("/report", Auth, HandleErrors(communityReport));
CommunititesRoutes.post("/delete-member", Auth, HandleErrors(deleteMember));
CommunititesRoutes.get("/posts/:id", Auth, HandleErrors(getCommunityPosts));
CommunititesRoutes.post(
  "/:communityId/join",
  Auth,
  HandleErrors(joinCommunity)
);
CommunititesRoutes.get(
  "/community-list/:user_id",
  Auth,
  HandleErrors(getCommunityList)
);

CommunititesRoutes.get("/get-by-id/:id", Auth, HandleErrors(getCommunityById));
CommunititesRoutes.post("/details", Auth, HandleErrors(getCommunityDetails));
export default CommunititesRoutes;
