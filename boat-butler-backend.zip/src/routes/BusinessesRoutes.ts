import express from "express";

import HandleErrors from "../middlewares/handleError";

// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
  getServiceProvidersList,
  getServiceProviderById,
  createBusiness,
  editBusiness,
  getGooglePlaceDetail,
} from "../controllers/BusinessesController";
import Auth from "../middlewares/auth";

// import Validation from "../validationSchema/authSchema"

const BusinessesRoutes = express.Router();

BusinessesRoutes.post("/create", Auth, HandleErrors(createBusiness));

BusinessesRoutes.patch("/edit/:businessId", Auth, HandleErrors(editBusiness));

BusinessesRoutes.post("/get-list", Auth, HandleErrors(getServiceProvidersList));
// BusinessesRoutes.post("/create", HandleErrors(createServiceProvider));
BusinessesRoutes.get("/:id", Auth, HandleErrors(getServiceProviderById));
BusinessesRoutes.get(
  "/googlePlace/:placeId",
  HandleErrors(getGooglePlaceDetail)
);

export default BusinessesRoutes;
