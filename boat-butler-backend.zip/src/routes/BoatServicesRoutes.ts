import express from "express";
import Auth from "../middlewares/auth";

import HandleErrors from "../middlewares/handleError";

import {
    create,
    update,
    getServiceById,
    getServiceHistory,
    getBoatServicesByUserId,
} from "../controllers/BoatServicesController";

const BoatServicesRoutes = express.Router();

BoatServicesRoutes.post("/create",Auth, HandleErrors(create));
BoatServicesRoutes.post("/:serviceId/update",Auth, HandleErrors(update));
BoatServicesRoutes.get("/:serviceId",Auth, HandleErrors(getServiceById));
BoatServicesRoutes.get("/get-history/:userId",Auth, HandleErrors(getServiceHistory));
BoatServicesRoutes.get("/get-all/:userId",Auth, HandleErrors(getBoatServicesByUserId));

export default BoatServicesRoutes;