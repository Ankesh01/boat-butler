import express from "express";

import HandleErrors from "../middlewares/handleError";

import {
  unlikeCommunityPost,
  likeCommunityPost,
} from "../controllers/PostsController";
import {
  create,
  getpostDetailById,
  getPostList,
  getSavedPostList,
} from "../controllers/PostsController";
import {
  reported,
  postComment,
  getComment,
  deleteCommentById,
} from "../controllers/PostsController";
import Auth from "../middlewares/auth";

const PostsRoutes = express.Router();

PostsRoutes.get("/post-detail/:id", Auth, HandleErrors(getpostDetailById));
PostsRoutes.post("/create", Auth, HandleErrors(create));
PostsRoutes.put("/like-community", Auth, HandleErrors(likeCommunityPost));
PostsRoutes.put("/unlike-community", Auth, HandleErrors(unlikeCommunityPost));
PostsRoutes.post("/post-comment", Auth, HandleErrors(postComment));
PostsRoutes.delete("/comment/delete", Auth, HandleErrors(deleteCommentById));
PostsRoutes.put("/report", Auth, HandleErrors(reported));
PostsRoutes.get("/get-comment/:post_id", Auth, HandleErrors(getComment));
PostsRoutes.get("/:userId/get-list", Auth, HandleErrors(getPostList));
PostsRoutes.get("/:userId/get-savedpost", Auth, HandleErrors(getSavedPostList));
// PostsRoutes.get("/:id", Auth, HandleErrors(getCommunityById));

export default PostsRoutes;
