import express from "express";
import {
  getAllReportedCommunityList,
  getAllReportedUserList,
  blockUser,
} from "../../controllers/admincontrollers/ReportManagementAdminController";
import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";

const ReportManagementRoutes = express.Router();
ReportManagementRoutes.get(
  "/get-reported-user",
  Auth,
  HandleErrors(getAllReportedUserList)
);

ReportManagementRoutes.get(
  "/get-reported-community",
  Auth,
  HandleErrors(getAllReportedCommunityList)
);

ReportManagementRoutes.delete(
  "/block-report-user/:_id",
  Auth,
  HandleErrors(blockUser)
);

export default ReportManagementRoutes;
