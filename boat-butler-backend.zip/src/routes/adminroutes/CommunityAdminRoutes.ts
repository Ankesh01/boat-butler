import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";
import CommunityAdminServices from "../../services/adminservices/CommunityAdminServices";

import {
  getCommunityList,
  searchCommunityList,
  getCommunityDetail,
  getCommunityDetailByType,
  getReportedUser,
  blockUser,
  deleteReportedPost,
  blockCommunity,
} from "../../controllers/admincontrollers/CommunityListController";

const CommunityAdminRoutes = express.Router();
CommunityAdminRoutes.get("/community-list", Auth, HandleErrors(getCommunityList));
CommunityAdminRoutes.get("/search", Auth, HandleErrors(searchCommunityList));
CommunityAdminRoutes.get("/detail/:_id", Auth, HandleErrors(getCommunityDetail));

CommunityAdminRoutes.get("/all-page-detail/:_id", Auth, HandleErrors(getCommunityDetailByType));

CommunityAdminRoutes.get("/reported-users/:_id",Auth, HandleErrors(getReportedUser));

CommunityAdminRoutes.patch("/block/:user_id", Auth, HandleErrors(blockUser));

CommunityAdminRoutes.delete("/delete-reported-post/:_id", Auth, HandleErrors(deleteReportedPost));

CommunityAdminRoutes.delete(
  "/block-community/:_id",
  Auth,
  HandleErrors(blockCommunity)
);

// CommunityAdminServices.qwerty()

export default CommunityAdminRoutes;
