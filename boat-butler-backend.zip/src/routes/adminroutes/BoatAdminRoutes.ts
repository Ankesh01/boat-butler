import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";
// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
    getboatlist,
    searchboatlist,
    boatdetaillist,
} from "../../controllers/admincontrollers/BoatListController";


// import Validation from "../validationSchema/authSchema"

const BoatAdminRoutes = express.Router();
BoatAdminRoutes.get("/boat-list", Auth, HandleErrors(getboatlist));
BoatAdminRoutes.get("/search", Auth, HandleErrors(searchboatlist));
// BoatAdminRoutes.get("/detail/:userId", HandleErrors(userlistdetail));
BoatAdminRoutes.get("/services/:_id", Auth, HandleErrors(boatdetaillist));
export default BoatAdminRoutes;
