import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";
// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
  getuserlist,
  searchuserlist,
  userlistdetail,
  userservicelist,
} from "../../controllers/admincontrollers/UserListController";


// import Validation from "../validationSchema/authSchema"

const UserAdminRoutes = express.Router();
UserAdminRoutes.get("/user-list",Auth, HandleErrors(getuserlist));
UserAdminRoutes.get("/search",Auth, HandleErrors(searchuserlist));
UserAdminRoutes.get("/detail/:userId",Auth, HandleErrors(userlistdetail));
UserAdminRoutes.get("/services/:_id",Auth, HandleErrors(userservicelist));
export default UserAdminRoutes;
