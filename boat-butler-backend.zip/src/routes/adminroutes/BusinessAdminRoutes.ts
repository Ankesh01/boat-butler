import express from "express";

import HandleErrors from "../../middlewares/handleError";
import {
  getServiceProvidersList,
  getGooglePlaceDetail,
} from "../../controllers/admincontrollers/BusinessesControllerAdmin";
import Auth from "../../middlewares/auth";

const BusinessesAdminRoutes = express.Router();

BusinessesAdminRoutes.get("/get-list",Auth, HandleErrors(getServiceProvidersList));
BusinessesAdminRoutes.get(
  "/googlePlace/:placeId", Auth,
  HandleErrors(getGooglePlaceDetail)
);

export default BusinessesAdminRoutes;
