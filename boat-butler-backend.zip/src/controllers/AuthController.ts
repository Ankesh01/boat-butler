import { Request, Response } from "express";

import AuthServices from "../services/AuthServices";
import { Iresetpassword } from "../Interfaces/serviceResponse";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";

/**
 * Login
 */
export const login = async (req: Request, res: Response) => {
  const response: ResponseObject = await AuthServices.login(req.body);

  res.status(200).send(response);
};
/**
 *  Signup
 */
export const signup = async (req: Request, res: Response) => {
  const response: ResponseObject = await AuthServices.signup(req.body);
  res.status(200).send(response);
};

export const socialLogin = async (
  req: Request,
  res: Response
) => {
  const response: ResponseObject = await AuthServices.socialLogin(req.body);
  res.status(200).send(response);
};

// export const socialSignup = async (
//   req: Request,
//   res: Response
// ): Promise<any> => {
//   const response: any = await AuthServices.socialSignup(req.body);
//   res.status(200).send(response);
// };
/**
 * Reset Password
 * @param req
 * @param res
 */
export const forgotpassword = async (
  req: Request,
  res: Response
): Promise<any> => {
  const response = await AuthServices.forgotpassword(req.body);
  res.status(200).send(response);
};

export const sendOtp = async (req: Request, res: Response): Promise<any> => {
  const response: any = await AuthServices.sendOtp(req.body);
  console.log("------", req.body);
  res.status(200).send(response);
};

export const otpVerification = async (
  req: Request,
  res: Response
): Promise<any> => {
  const response = await AuthServices.otpVerification(req.body);
  res.status(200).send(response);
};

/**
 *
 * @param req
 * @param res
 */
export const changePassword = async (
  req: Request & { id: string },
  res: Response
): Promise<any> => {
  const response = await AuthServices.changePassword(req.body);

  res.status(200).send({
    data: response,
  });
};

/**
 * Handling the auth token validation
 * @param req Http Request
 * @param res Http Response
 */

export const matchToken = async (
  req: Request & DataFromHeader,
  res: Response
) => {
  const response = await AuthServices.matchToken({
    id: req.id,
    token: req.token,
  });
  res.status(200).send(response);
};

/**
 * Profile
 */
export const profile = async (req: Request, res: Response) => {
  const response = await AuthServices.profile(req.body);

  res.status(200).send(response);
};

export const getUserDetail = async (req: Request, res: Response) => {
  const response = await AuthServices.getUserDetail(req.params?.id);

  res.status(200).send(response);
};

export const deleteUser = async (req: Request, res: Response) => {
  const response = await AuthServices.deleteUser(req.params?.id);

  res.status(200).send(response);
};


export const clearFcmToken = async (req: Request, res: Response) => {
  const response = await AuthServices.clearFcmToken(req.params?.userId);

  res.status(200).send(response);
};

export const updateUserTimezone = async (req: Request, res: Response) => {
  if(!req.query?.timezone){
    res.status(200).send({
      success: false,
      message: "user_not_found",
    });
  }
  const response = await AuthServices.updateUserTimezone(req.params?.userId, req.query?.timezone as string);

  res.status(200).send(response);
};
