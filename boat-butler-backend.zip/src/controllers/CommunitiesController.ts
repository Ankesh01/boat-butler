import { Request, Response } from "express";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import CommunitiesServices from "../services/CommunitiesServices";
/**
 * Create Community
 * @param req
 * @param res
 */

export const create = async (req: Request, res: Response) => {
  const response = await CommunitiesServices.create(req.body);

  res.status(200).send(response);
};

/**
 * Get Community by @id
 * @param req
 * @param res
 */

export const getCommunityById = async (req: Request, res: Response) => {
  const _id = req?.params?.id;
  const user_id = req.query.user_id as string;
  const response = await CommunitiesServices.getCommunityById(_id, user_id);

  res.status(200).send(response);
};

export const getCommunityPosts = async (req: Request, res: Response) => {
  const _id = req?.params?.id;
  const offset = Number(req?.query?.offset);
  const user_id = req?.query?.user_id as string;
  console.log("getCommunityPosts req?.query", req?.query);
  const response = await CommunitiesServices.getCommunityPosts(
    _id,
    offset,
    user_id
  );

  res.status(200).send(response);
};

export const joinCommunity = async (req: Request, res: Response) => {
  console.log("joinCommunity req.body **************** ", req.body);
  const response = await CommunitiesServices.joinCommunity(req.body);

  res.status(200).send(response);
};
export const communityRequest = async (req: Request, res: Response) => {
  const status = req.body.status;
  const user_id = req.body.user_id;
  const community_id = req.body.community_id;
  const response = await CommunitiesServices.communityRequest(
    user_id,
    status,
    community_id
  );

  res.status(200).send(response);
};
export const communityReport = async (req: Request, res: Response) => {
  const response = await CommunitiesServices.communityReport(req.body);

  res.status(200).send(response);
};
export const deleteMember = async (req: Request, res: Response) => {
  const user_id = req.body.user_id;
  const community_id = req.body.community_id;
  console.log("deleteMember req.body", req.body);
  const response = await CommunitiesServices.deleteMember(
    user_id,
    community_id
  );

  res.status(200).send(response);
};
export const getCommunityDetails = async (req: Request, res: Response) => {
  console.log("getCommunityRequestStatus req.body **************** ", req.body);
  let offset = Number(req.query.offset);
  let query = req.query.query as string;
  const status = req.body.status;
  const response = await CommunitiesServices.getCommunityDetails(
    req.body._id,
    status,
    offset,
    query
  );

  res.status(200).send(response);
};
export const getCommunityList = async (req: Request, res: Response) => {
  let user_id = req.params.user_id;
  let offset = Number(req?.query?.offset);
  let type = req?.query?.type as string;
  console.log("req.query--------------", req?.query);
  console.log("type------offset--------", type, offset);
  const response = await CommunitiesServices.getCommunityList(
    user_id,
    offset,
    type
  );
  res.status(200).send(response);
};

export const editCommunity = async (req: Request, res: Response) => {
  console.log("req?.params.id", req?.params.id);
  console.log("req?.body", req?.body);
  const id = req?.params?.id;
  const response = await CommunitiesServices.editCommunity(req.body, id);

  res.status(200).send(response);
};
