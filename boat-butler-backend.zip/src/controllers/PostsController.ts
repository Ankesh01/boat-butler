import { Request, Response } from "express";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import PostsServices from "../services/PostsServices";
/**
 * Create Community
 * @param req
 * @param res
 */

export const create = async (req: Request, res: Response) => {
  const response = await PostsServices.create(req.body);

  res.status(200).send(response);
};

export const likeCommunityPost = async (req: Request, res: Response) => {
  const response = await PostsServices.likeCommunityPost(req.body);

  res.status(200).send(response);
};

export const unlikeCommunityPost = async (req: Request, res: Response) => {
  const response = await PostsServices.unlikeCommunityPost(req.body);

  res.status(200).send(response);
};

export const reported = async (req: Request, res: Response) => {
  const response = await PostsServices.reported(req.body);

  res.status(200).send(response);
};

export const getpostDetailById = async (req: Request, res: Response) => {
  const _id = req?.params?.id;

  const response = await PostsServices.getpostDetailById(_id);

  res.status(200).send(response);
};

export const postComment = async (req: Request, res: Response) => {
  console.log("req.body", req.body);
  const response = await PostsServices.postComment(req.body);
  res.status(200).send(response);
};
export const getComment = async (req: Request, res: Response) => {
  const response = await PostsServices.getComment(req.params.post_id);
  res.status(200).send(response);
};

export const deleteCommentById = async (req: Request, res: Response) => {
  const response = await PostsServices.deleteCommentById(req.body);
  res.status(200).send(response);
};
export const getPostList = async (req: Request, res: Response) => {
  const offset = Number(req?.query?.offset);
  const response = await PostsServices.getPostList(req.params.userId, offset);
  res.status(200).send(response);
};
export const getSavedPostList = async (req: Request, res: Response) => {
  const offset = Number(req?.query?.offset);
  const query = req.query.searchKeyword as string;
  const response = await PostsServices.getSavedPostList(
    req.params.userId,
    offset,
    query
  );
  res.status(200).send(response);
};
