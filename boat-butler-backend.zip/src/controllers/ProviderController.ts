import { Request, Response } from "express";

import ProviderServices from "../services/ProviderServices";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { Provider } from "../models/providers";

/**
 * Handle http request for filling provider onboarding form
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const fillOnboardingForm = async (
  req: Request & DataFromHeader,
  res: Response
) => {
  const response: ResponseObject = await ProviderServices.fillOnboardingForm({
    ...req.body,
    userId: req.id,
  });
  res.status(200).send(response);
};

/**
 * Edit profile controller
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const editProfile = async (req: Request, res: Response) => {
  const response = await ProviderServices.editProfile({ ...req.body });
  res.status(200).send(response);
};

/**
 * Communicate to selected workforce members
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const communication = async (req: Request, res: Response) => {
  const response: ResponseObject = await ProviderServices.communication(
    req.body
  );
  res.status(200).send(response);
};

/**
 * Search workforce members with filters
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const searchCandidates = async (req: Request, res: Response) => {
  const response: ResponseObject = await ProviderServices.searchCandidates(
    req.body
  );
  res.status(200).send(response);
};

/**
 * Get communication templates
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const getCommunicationTemplates = async (
  req: Request,
  res: Response
) => {
  const response: ResponseObject =
    await ProviderServices.getCommunicationTemplates();

  res.status(200).send(response);
};

/**
 * questionaries
 * @param req Standard Http Response Object
 * @param res Standard Http Response Object
 */
export const questionaries = async (
  req: Request & DataFromHeader,
  res: Response
) => {
  const response = await ProviderServices.questionnaires(req.body);
  console.log("req", req.body);

  res.status(200).send(response);
};

/**
 * create job shifts
 */

export const createJobShift = async (
  req: Request & DataFromHeader,
  res: Response
) => {
  const response = await ProviderServices.createJobShift(req.body);
  console.log("req", req.body);

  res.status(200).send(response);
};

export const jobShift = async (
  req: Request & DataFromHeader,
  res: Response
) => {
  const response = await ProviderServices.jobShift(req.query.id);
  console.log(req.query.id);

  res.status(200).send(response);
};


/*
 * Invite candidates for specific job
 * @param req Standard Http Request Object
 * @param res Standard Http Response Object
 */
export const inviteCandidates = async (req: Request, res: Response) => {
  const response: ResponseObject = await ProviderServices.inviteCandidates(
    req.body
  );
  res.status(200).send(response);
};
