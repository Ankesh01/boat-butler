import { Request, Response } from "express";

import BoatServices from "../services/BoatServices";
import { Iresetpassword } from "../Interfaces/serviceResponse";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";

/**
 * Create Boat
 * @param req
 * @param res
 */

export const create = async (req: Request, res: Response) => {
  const response: ResponseObject = await BoatServices.create(req.body);

  res.status(200).send(response);
};

export const getEngineMakeList = async (req: Request, res: Response) => {
  const response: ResponseObject = await BoatServices.getEngineMakeList();
  res.status(200).send(response);
};

export const getBoatList = async (req: Request, res: Response) => {
  console.log("Request-------", req.params?.id);
  console.log("Search Query", req.query);
  const query = req.query.searchKeyword;
  const response = await BoatServices.getBoatDetail(req.params?.id, query);
  res.status(200).send(response);
};

export const searchFilters = async (req: Request, res: Response) => {
  console.log("searchFilter-------", req.body);
  // const id = req.params?.id;
  const response = await BoatServices.searchFilters(req.body.data);
  res.status(200).send(response);
};

export const getBoatDetailById = async (req: Request, res: Response) => {
  const boatId = req.params.boatId;
  const response = await BoatServices.getBoatDetailById(boatId);
  res.status(200).send(response);
};

export const getBoatCountByUserId = async (req: Request, res: Response) => {
  const userId = req?.query?.userId as string;
  const response = await BoatServices.getBoatCountByUserId(userId);
  res.status(200).send(response);
};
export const editBoatById = async (req: Request, res: Response) => {
  const boatId = req.params.boatId;
  const response = await BoatServices.editBoatById(boatId, req.body);
  res.status(200).send(response);
};

export const getBoatServices = async (req: Request, res: Response) => {
  const userId = req.params.userId;
  console.log("Search Query", req.query, req.params);
  const response = await BoatServices.getBoatServices(userId, req.query);
  res.status(200).send(response);
};
