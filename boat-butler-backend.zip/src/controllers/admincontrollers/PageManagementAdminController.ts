import { Request, Response } from "express";
import PageManagementServices from "../../services/adminservices/PageManagementAdminServices";

/**
 * @method to create new faq
 * @param req
 * @param res
 */
export const create = async (req: Request, res: Response) => {
  const response = await PageManagementServices.create(req.body);
  res.status(200).send(response);
};

/**
 * @method to get list of all faqs
 * @param req
 * @param res
 */
export const getAllFaqList = async (req: Request, res: Response) => {
  const response = await PageManagementServices.getfaqslist(req.query);
  res.status(200).send(response);
};

/**
 * @method to edit faqs
 * @param req
 * @param res
 */
export const editFaqs = async (req: Request, res: Response) => {
  const response = await PageManagementServices.updateFaqs(
    req.body,
    req.params.pageId
  );
  res.status(200).send(response);
};

/**
 * @method to fetch faq by id
 * @param req
 * @param res
 */
export const getPageProviderById = async (req: Request, res: Response) => {
  const id = req?.params?.id;
  const response = await PageManagementServices.getPageProviderById(id);
  res.status(200).send(response);
};

/**
 * @method to get list of all web page list
 * @param req
 * @param res
 */
export const getAllWebPagesList = async (req: Request, res: Response) => {
  const response = await PageManagementServices.getWebPageslist(req.query);
  res.status(200).send(response);
};
