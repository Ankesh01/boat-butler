import { Request, Response } from "express";

import BoatAdminServices from "../../services/adminservices/BoatAdminServices";


import { ResponseObject} from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const getboatlist = async (req: Request, res: Response) => {
  const response: ResponseObject = await BoatAdminServices.getboatlist(req.query);
  console.log("req.body", response)
  res.status(200).send(response);
};

export const searchboatlist = async (req: Request, res: Response) => {
  // console.log("hjhjh", req.query)
  const response = await BoatAdminServices.searchboatlist(req.query);
  res.status(200).send(response);
};

export const boatdetaillist = async (req: Request, res: Response) => {
    console.log("hjhjh", req.params)
    const response = await BoatAdminServices.boatdetaillist(req.params);
    res.status(200).send(response);
  };


