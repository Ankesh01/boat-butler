import { Request, Response } from "express";

import UserAdminServices from "../../services/adminservices/UserAdminServices";


import { ResponseObject} from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const getuserlist = async (req: Request, res: Response) => {
  const response: ResponseObject = await UserAdminServices.getuserslist(req.query);
  console.log("req.body", response)
  res.status(200).send(response);
};

export const searchuserlist = async (req: Request, res: Response) => {
  // console.log("hjhjh", req.query)
  const response = await UserAdminServices.searchuserslist(req.query);
  res.status(200).send(response);
};

export const userlistdetail = async (req: Request, res: Response) => {
  // console.log("hjhjh", req.params)
  const response = await UserAdminServices.userlistdetail(req.params);
  res.status(200).send(response);
};

export const userservicelist = async (req: Request, res: Response) => {
  console.log("hjhjh", req.params)
  const response = await UserAdminServices.userservicelist(req.params);
  res.status(200).send(response);
};
