import { Request, Response } from "express";
import ReportManagementServices from "../../services/adminservices/ReportManagementAdminServices";

/**
 * @method to get list of all users
 * @param req
 * @param res
 */
export const getAllReportedUserList = async (req: Request, res: Response) => {
  const response = await ReportManagementServices.getAllReportedUserList(
    req.query
  );
  res.status(200).send(response);
};

export const getAllReportedCommunityList = async (
  req: Request,
  res: Response
) => {
  const response = await ReportManagementServices.getAllReportedCommunityList(
    req.query
  );
  res.status(200).send(response);
};


export const blockUser = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let type = req.query.type;
  const response = await ReportManagementServices.blockUser(_id, type);
  res.status(200).send(response);
};
