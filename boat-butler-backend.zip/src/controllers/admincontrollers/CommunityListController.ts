import { Request, Response } from "express";

import CommunityAdminServices from "../../services/adminservices/CommunityAdminServices";

import { ResponseObject } from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const getCommunityList = async (req: Request, res: Response) => {
  const response: ResponseObject =
    await CommunityAdminServices.getCommunityList(req.query);
  console.log("req.body", response);
  res.status(200).send(response);
};

export const searchCommunityList = async (req: Request, res: Response) => {
  const response = await CommunityAdminServices.searchCommunityList(req.query);
  res.status(200).send(response);
};

export const getCommunityDetail = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let offset = req.query.offset;
  const response = await CommunityAdminServices.getCommunityDetail(_id, offset);
  res.status(200).send(response);
};

export const getCommunityDetailByType = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let offset = req.query.offset;
  let type = req.query.type;

  const response = await CommunityAdminServices.getCommunityDetailByType(
    _id,
    offset,
    type
  );
  res.status(200).send(response);
};

export const getReportedUser = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let offset = req.query.offset;
  const response = await CommunityAdminServices.getReportedUser(_id, offset as string);
  res.status(200).send(response);
};

export const blockUser = async (req: Request, res: Response) => {
  let user_id = req.params.user_id;
  const response = await CommunityAdminServices.blockUser(user_id);
  res.status(200).send(response);
};

export const deleteReportedPost = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let type = req.query.type;
  const response = await CommunityAdminServices.deleteReportedPost(_id, type);
  res.status(200).send(response);
};

export const blockCommunity = async (req: Request, res: Response) => {
  let _id = req.params._id;
  let type = req.query.type;
  const response = await CommunityAdminServices.blockCommunity(_id, type);
  res.status(200).send(response);
};
