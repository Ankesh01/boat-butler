import { Request, Response } from "express";

import PaymentServices from "../services/PaymentServices";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";

/**
 * Create Boat
 * @param req
 * @param res
 */

export const getPlanList = async (req: Request, res: Response) => {
  const response: ResponseObject = await PaymentServices.getPlanList();

  res.status(200).send(response);
};

export const create = async (req: Request, res: Response) => {
  console.log("CREATE PAYMENT API CALL ********************* ", req.body)
  const response: ResponseObject = await PaymentServices.create(req.body);

  res.status(200).send(response);
};
export const androidWebhook = async (req: Request, res: Response) => {
  console.log("android Webhook CALL ********************* ", req.body)
  // const response: ResponseObject = await PaymentServices.create(req.body);

  res.status(200).send({  success: true,
    message: "ok"});
  }

export const getPaymentHistory = async (req: Request, res: Response) => {
  let userId = req?.query?.userId as string;
  let offset = Number(req?.query?.offset);
  const response: ResponseObject = await PaymentServices.getPaymentHistory(
    userId,offset
  );

  res.status(200).send(response);
};
