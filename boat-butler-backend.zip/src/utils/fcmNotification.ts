import * as admin from "firebase-admin";
import "../../boat-butler-c5750-firebase-adminsdk-4ki0j-e3f252f966.json"
const serviceAccount = require("../../boat-butler-c5750-firebase-adminsdk-4ki0j-e3f252f966.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
})

interface IMessage {
    notification : { title : string; body : string};
    tokens : string[];
    data? : any | string
}

export const sendNotification = async (tokenList : string[],title : string, body : string, data?:string) =>{
    const message : IMessage = {
        notification : {title, body},
        tokens : tokenList
    }
    if(data && Object.keys(data).length!==0){
        message.data = data
    }
    const result = await admin.messaging().sendMulticast(message)
    console.log('notification result ', JSON.stringify(result))
}