import config from "../config/envConfig";
// const Twilio = require("twilio");
// const config = require("../config/envConfig");
const envConfig = config();
import sgMail from "@sendgrid/mail";


export const sendMail = async (email: string, content: any) => {
  sgMail.setApiKey(envConfig.sendgridMail.apiKey);
  console.log("Send email to ", email, content);
  const mailData = {
    from: envConfig.sendgridMail.sender,
    to: email,
    subject: content.subject,
    text: content.text,
    html: content.html,
  };
  try {
    await sgMail.send(mailData);
    console.log(`Mail sent successfully to ${email}`);
    return {
      isError: false,
      message: "Email sent successfully.",
    };
  } catch (error) {
    console.log("Mail send failed", JSON.stringify(error));
    return {
      isError: false,
      message: error,
    };
  }
};
