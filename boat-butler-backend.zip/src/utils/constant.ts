const MEMBER = "Member";
const PROVIDER = "Provider";
const STAFF = "Staff";
const ADMIN = "Admin";

const ROLES = {
  MEMBER: "Member",
  PROVIDER: "Provider",
  STAFF: "Staff",
  ADMIN: "Admin",
};

const PROVIDER_FORMS = {
  EXHIBIT_C: "exhibit_c",
  STAFFING_AGREEMENT: "staffing_agreement",
  EXHIBIT_F: "exhibit_f",
  EXHIBIT_B: "exhibit_b",
};

const PROVIDER_ONBOARDING_FORMS = [
  "exhibit_c",
  "staffing_agreement",
  "exhibit_f",
  "exhibit_b",
];

const INVITATION_MEDIUM = {
  MESSAGE: "message",
  CHAT: "chat",
  MAIL: "mail",
  PUSH_NOTIFICATION: "push_notification",
};

const MYSHIFT_DEV_ASSETS = "myshift-dev-assets";

export {
  MEMBER,
  PROVIDER,
  STAFF,
  ADMIN,
  ROLES,
  PROVIDER_FORMS,
  PROVIDER_ONBOARDING_FORMS,
  INVITATION_MEDIUM,
  MYSHIFT_DEV_ASSETS,
};
