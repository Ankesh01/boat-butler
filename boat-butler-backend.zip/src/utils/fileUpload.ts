import config from "../config/envConfig";

const AWS = require('aws-sdk');
const envConfig = config();
var awsconfig = {
  accessKeyId: 'AKIAREYE3RVKQ6HGAOAG',
  secretAccessKey: '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',
  region: 'us-east-2',
};
const bucketName = envConfig.aws_bucket

/**
 * @method to upload image
 * @param fileData
 * @param bucketName
 * @param filePath
 * @returns
 */
export const uploadImage = async (
  fileData: any,
  bucketName: any,
  filePath: any,
  fileFormat ?:string
) => {
  
  return new Promise((resolve, reject) => {
    AWS.config.update(awsconfig);
    const bucket = new AWS.S3({ params: { Bucket: bucketName } });
    const buf = Buffer.from(
      fileData.replace(/^data:image\/\w+;base64,/, ''),
      'base64'
    );
    const params = {
      Key: `${filePath}`, // file will be saved as testBucket/contacts.csv
      Body: buf,
      ContentType: fileFormat ? fileFormat :"jpeg",
      ACL: 'public-read',
    };
    bucket.upload(params, function (s3Err: any, data: any) {
      if (s3Err) {
        throw s3Err;
      }
      resolve(data.Location);
    });
  });
};

export const deleteFileFromS3 = async (filePath: string) => {
  if (!filePath || filePath.length === 0) {
    return;
  }
  AWS.config.update(awsconfig);
  const s3 = new AWS.S3();
  console.log('delete filePath ', filePath);
  let { pathname } = new URL(
    filePath,
    'https://boat-buttler-media.s3.us-east-2.amazonaws.com/'
  ); // dummy domain to avoid invalid URL error
  pathname = pathname.substring(1);

  const params = {
    Bucket: 'boat-buttler-media',
    Delete: {
      // required
      Objects: [
        // required
        {
          Key: pathname,
        },
      ],
    },
  };
  s3.deleteObjects(params, function (err: any, data: any) {
    if (err) console.log(err, err.stack);
    // an error occurred
    else console.log('Deleted image from bucket ', data); // successful response
  });
};

export const getPresignedUrlFromS3 = async(filePath : string, fileFormat : string) => new Promise(((resolve, reject) => {
  AWS.config.update(awsconfig);
  const bucket = new AWS.S3({ params: { Bucket: bucketName }, signatureVersion: 'v4' });
  const params = {
    Key: `${filePath}`, // file will be saved as testBucket/contacts.csv
    ContentType: fileFormat ? fileFormat :"jpeg",
    ACL: 'public-read',
    Expires : 60*60
  };
  try {
    bucket.getSignedUrl('putObject', params, function (err,         data) {
      if (err) {
        return reject(err);
      }
      resolve(data);
    });
  } catch (error) {
    return reject(error);
  }

}))
