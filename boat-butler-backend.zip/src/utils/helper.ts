import axios, { AxiosRequestConfig, AxiosPromise } from "axios";

import config from "../config/envConfig";

import { envData, GoogleAPIParams } from "../Interfaces/commonInterfaces";
import moment from "moment";

const { google_api_key, region }: envData = config();

class Helper {
  /**
   * Converts a string to a regular expression
   * @param str
   * @returns
   */
  regex = (str: string) => new RegExp(str, "i");

  /**
   * Call google apis
   * @param data Params
   * @returns
   */
  googleAPI = async (data: GoogleAPIParams): Promise<AxiosPromise> => {
    const config: AxiosRequestConfig = {
      url: data.url,
      method: data.method,
      headers: {
        "User-Agent": "Super Agent/0.0.1",
        "Content-Type": "application/x-www-form-urlencoded",
      },
      params: {
        region: region,
        key: google_api_key,
        ...data.params,
      },
    };
    const response = await axios(config);
    return response;
  };

  isBase64Image = async (image: string): Promise<boolean> => {
    try {
      return /^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?$/.test(
        image.split(",")[1]
      );
    } catch {
      return false;
    }
  };

   convertTZ(date, tzString) {
     return new Date((typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", {timeZone: tzString}))
  }
}

export default new Helper();
