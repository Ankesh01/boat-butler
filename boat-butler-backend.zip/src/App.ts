import express from "express";
import config from "./config/envConfig";
import {intializeCronJobs} from "./services/CronService"
var cors = require('cors')
const awsServerlessExpress = require('aws-serverless-express');

import Router from './Router';
import './db/connection';

const app = express();
const envConfig = config();
const port = envConfig.port;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
// app.use(express.json({ limit: '1mb' })); //For JSON requests
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use('/', Router);

app.listen(port, () => {
  console.log(`Server is running on ${port}`);
});

intializeCronJobs();

const server = awsServerlessExpress.createServer(app);
module.exports.handler = (event: any, context: any) =>
  awsServerlessExpress.proxy(server, event, context);

