import mongoose, { Schema } from "mongoose";
import { ForumMainSchema } from "../Interfaces/schemaInterfaces";

const forumMainSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    saved_post_ids: {
      type: Array,
    },
    shared_post_ids: {
      type: Array,
    },
    replied_post_ids: {
      type: Array,
    },
    liked_post_ids: {
      type: Array,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

forumMainSchema.set("toObject", { virtuals: true });
forumMainSchema.set("toJSON", { virtuals: true });

const ForumMain = mongoose.model<ForumMainSchema>("forummain", forumMainSchema);

export { ForumMain, ForumMainSchema };
