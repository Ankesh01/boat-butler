import mongoose, {Schema} from "mongoose";
import {SubscriptionSchema} from "../Interfaces/subscriptionInterfaces";

const subscriptionSchema = new mongoose.Schema(
    {

        title: {
            type: String,
        },
        plan_id: {
            type: String,
        },
        price: {
            type: Number,
        },
        boat_count : {
          type : Number,
        },
        slug: {
            type: String,
        },

    },
    {timestamps: {createdAt: "created_ts", updatedAt: "updated_ts"}}
);

subscriptionSchema.set("toObject", {virtuals: true});
subscriptionSchema.set("toJSON", {virtuals: true});

const SubscriptionPlans = mongoose.model<SubscriptionSchema>("subscription_plans", subscriptionSchema);

export {SubscriptionPlans, SubscriptionSchema};
