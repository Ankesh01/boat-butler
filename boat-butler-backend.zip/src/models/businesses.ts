import mongoose, { Schema } from "mongoose";
// import { BusinessesSchema } from "../Interfaces/businesses";

const PointSchema = new mongoose.Schema({
  coordinates: { type: [Number], index: "2dsphere" },
  type: {
    type: String,
    enum: ["Point"],
    default: "Point",
  },
  address_line1: { type: String },
  address_line2: { type: String },
  city: { type: String },
  state: { type: String },
  zip: { type: String },
});

const BusinessesSchema = new mongoose.Schema(
  {
    owner_name: {
      type: String,
    },

    business_name: {
      type: String,
    },
    registration_number: {
      type: String,
    },
    contact_number: {
      type: String,
    },
    email: {
      type: String,
    },
    location: PointSchema,

    business_hours: {
      type: Object,
    },
    business_days: {
      type: Array,
    },
    services: {
      type: String,
    },
    photos: {
      type: Array,
    },
    status: {
      type: String,
      enum: ["Active", "Draft", "Archive"],
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

BusinessesSchema.set("toObject", { virtuals: true });
BusinessesSchema.set("toJSON", { virtuals: true });

const Businesses = mongoose.model("businesses", BusinessesSchema);

export { Businesses, BusinessesSchema };
