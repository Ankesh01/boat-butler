// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { UserSchema } from "../Interfaces/schemaInterfaces";

const userSchema = new mongoose.Schema(
  {
    account_type: {
      type: String,
      enum: ["Admin", "Member"],
      default: "Member",
    },
    name: {
      type: String,
      required: true,
    },
    last_name: {
      type: String,
    },
    phone: {
      type: Number,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    gender: {
      type: String,
    },
    password: {
      type: String,
    },
    image: {
      type: String,
    },
    address_line_1: {
      type: String,
    },
    address_line_2: {
      type: String,
    },
    state: {
      type: String,
    },
    country: {
      type: String,
    },
    city: {
      type: String,
    },
    zipcode: {
      type: Number,
    },
    encOtp: {
      type: String,
    },
    is_active: {
      type: Number,
      default: 0,
    },
    is_verified: {
      type: Number,
      default: 0,
    },
    is_reported: {
      type: Number,
      default: 0,
    },
    reported_by: {
      type: Object,
      // type: Schema.Types.ObjectId,
      // ref: "users",
    },
    fcm_token: {
      type: String,
    },
    resetKey: {
      type: String,
    },
    timezone: {
      type: String,
    },
    reported_at: {
      type: Date,
    },

    status: {
      type: String,
      enum: ["Blocked"],
      //   default: "Pending",
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

userSchema.pre("remove", function (next) {
  console.log("this-----", this._id);

  this.model("boats").deleteMany({ user_id: this._id }, next);
  this.model("boat_services").deleteMany({ user_id: this._id }, next);
  this.model("reminders").deleteMany({ user_id: this._id }, next);
  // this.model("posts").deleteMany({ user_id: this._id }, next);
  // this.model("post_comments").deleteMany({ user_id: this._id }, next);
  // this.model("user_post_activities").deleteMany({ user_id: this._id }, next);
  // this.model("communities").deleteMany({ user_id: this._id }, next);
  // this.model("user_notifications").deleteMany({ user_id: this._id }, next);
  // this.model("payments").deleteMany({ user_id: this._id }, next);
  // this.model("members").deleteMany({ user_id: this._id }, next);
  next();
});

userSchema.set("toObject", { virtuals: true });
userSchema.set("toJSON", { virtuals: true });

const Users = mongoose.model<UserSchema>("users", userSchema);

export { Users, UserSchema };
