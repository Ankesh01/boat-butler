// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { BoatServiceSchema } from "../Interfaces/schemaInterfaces";

const boatServiceSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    boat_id: {
      type: Schema.Types.ObjectId,
      ref: "boats",
    },
    items: {
      type: Array,
    },
    due_date: {
      type: Date,
    },
    completion_date: {
      type: Date,
    },
    status: {
      type: String,
      enum: ["Pending", "Completed"],
    },
    receipts: {
      type: Array,
    },
    photos: {
      type: Array,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

boatServiceSchema.set("toObject", { virtuals: true });
boatServiceSchema.set("toJSON", { virtuals: true });

const BoatService = mongoose.model<BoatServiceSchema>(
  "boat_services",
  boatServiceSchema
);

export { BoatService, BoatServiceSchema };
