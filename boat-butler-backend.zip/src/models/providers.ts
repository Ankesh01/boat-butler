import mongoose, { Schema } from "mongoose";
import { ProviderSchema } from "../Interfaces/schemaInterfaces";

const providerSchema = new mongoose.Schema({
  user_id: {
    type: Schema.Types.ObjectId,
    ref: "users",
  },
  client_type: {
    type: String,
    required: true,
  },
  image: {
    type: String,
  },
  website: {
    type: String,
  },
  phone: {
    type: String,
    unique: true,
  },
  industry: {
    type: String,
  },
  description: {
    type: String,
  },
  established_in: {
    type: String,
  },
  registration_number: {
    type: String,
  },
  business_registration_number: {
    type: String,
  },
  questionnaires: {
    type: Object,
  },
});

providerSchema.set("toObject", { virtuals: true });
providerSchema.set("toJSON", { virtuals: true });

const Provider = mongoose.model<ProviderSchema>("providers", providerSchema);

export { Provider, ProviderSchema };
