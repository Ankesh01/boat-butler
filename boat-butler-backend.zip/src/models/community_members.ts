// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { CommunityMemberSchema } from "../Interfaces/communityInterface";

const communitiesMemberSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    community_id: {
      type: Schema.Types.ObjectId,
      ref: "communities",
    },
    status: {
      type: String,
      enum: ["Pending", "Accepted", "Rejected"],
      default: "Pending",
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

communitiesMemberSchema.set("toObject", { virtuals: true });
communitiesMemberSchema.set("toJSON", { virtuals: true });

const CommunityMembers = mongoose.model<CommunityMemberSchema>(
  "community_members",
  communitiesMemberSchema
);

export { CommunityMembers, communitiesMemberSchema };
