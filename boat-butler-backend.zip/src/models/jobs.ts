import mongoose, { Schema } from "mongoose";

interface JobSchema {
  owner_user_id: Schema.Types.ObjectId;
  form_id: string;
  title: string;
  contract_type: string;
  duration: {
    type: string;
    start_date: Date;
    end_date: Date;
  };
  shift: {
    template_name: string;
    start_time: Date;
    end_time: Date;
  };
  custom_schedule: string;
  supliment_pay_offer: string[];
  required_skills: string[];
  required_experience: {
    year: number;
    month: number;
  };
  location: {
    latitude: number;
    logitude: number;
    street: string;
    zip: number;
  };
  salary: {
    salary_type: string;
    amount: number;
  };
  documents: string[];
  status: string;
  number_of_positions: number;
  category_id: string;
}

const jobSchema = new mongoose.Schema(
  {
    owner_user_id: Schema.Types.ObjectId,

    form_id: {
      type: String,
    },
    title: {
      type: String,
      // required: true,
    },
    contract_type: {
      type: String,
      // required: true,
    },
    duration: {
      type: Object,
      // required: true,
    },
    shift: {
      type: Object,
      // required: true,
    },
    custom_schedule: {
      type: String,
      // required: true,
    },
    supliment_pay_offer: {
      type: Array,
    },
    required_skills: {
      type: Array,
      // required: true,
    },
    required_experience: {
      type: Object,
    },
    location: {
      type: Object,
      // required: true,
    },
    salary: {
      type: Object,
      // required: true,
    },
    documents: {
      type: Array,
    },
    status: {
      type: String,
      enum: ["pending", "active", "draft", "archived"],
      default: "pending",
    },

    number_of_positions: {
      type: Number,
      required: true,
    },
    category_id: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: {
      createdAt: "created_ts",
      updatedAt: "updated_ts",
    },
  }
);

jobSchema.set("toObject", { virtuals: true });
jobSchema.set("toJSON", { virtuals: true });

const Jobs = mongoose.model<JobSchema>("jobs", jobSchema);

export { Jobs, JobSchema };
