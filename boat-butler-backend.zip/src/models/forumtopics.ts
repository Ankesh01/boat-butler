import mongoose, { Schema } from "mongoose";
import { ForumTopicSchema } from "../Interfaces/schemaInterfaces";

const forumTopicSchema = new mongoose.Schema(
  {
    _id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    title: {
      type: String,
    },
    is_active: {
      type: Number,
    },
    user_id: {
      type: Array,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

forumTopicSchema.set("toObject", { virtuals: true });
forumTopicSchema.set("toJSON", { virtuals: true });

const ForumTopic = mongoose.model<ForumTopicSchema>(
  "forum_topics",
  forumTopicSchema
);

export { ForumTopic, ForumTopicSchema };
