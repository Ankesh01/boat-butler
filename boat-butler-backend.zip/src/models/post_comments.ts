// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { PostCommentSchema } from "../Interfaces/schemaInterfaces";

const postcommentsSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    comment: {
      type: String,
    },
    post_id: {
      type: Schema.Types.ObjectId,
      ref: "posts",
    },
    status: {
      type: String,
      enum: ["Active", "Archived", "Reported"],
      default: "Active",
    },
    total: {
      type: Object,
    },
    reported: {
      type: Object,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

postcommentsSchema.set("toObject", { virtuals: true });
postcommentsSchema.set("toJSON", { virtuals: true });

const PostComments = mongoose.model<PostCommentSchema>(
  "post_comments",
  postcommentsSchema
);

export { PostComments, PostCommentSchema };
