// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { CommunitiesSchema } from "../Interfaces/schemaInterfaces";

const communitiesSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    title: {
      type: String,
    },
    description: {
      type: String,
    },
    image: {
      type: String,
    },

    status: {
      type: String,
      enum: ["Active", "Archived", "Blocked", "Reported"],
      default: "Active",
    },
    reported: {
      type: Object, // { count , reportedBy: []}
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

communitiesSchema.set("toObject", { virtuals: true });
communitiesSchema.set("toJSON", { virtuals: true });

const Communities = mongoose.model<CommunitiesSchema>(
  "communities",
  communitiesSchema
);

export { Communities, CommunitiesSchema };
