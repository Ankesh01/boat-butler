import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage, deleteFileFromS3 } from "../utils/fileUpload";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { ICommunitiesData } from "../Interfaces/CommunitiesInterface";
import { Communities } from "../models/communities";
import { Post } from "../models/posts";
import { CommunityMembers } from "../models/community_members";
class CommunitiesServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data: ICommunitiesData) {
    let result;
    console.log("create community--> ", data);
    if (
      data.image &&
      data?.image?.data &&
      data?.image?.data.includes("base64")
    ) {
      let imageUrl = await uploadImage(
        data?.image?.data,
        "boat-buttler-media",
        `community/${Date.now()}`,
        data.image.format
      );
      data.image = imageUrl;
    } else {
      data.image = "";
    }

    if (data) {
      try {
        result = await Communities.create(data);
      } catch (err) {
        this.response = {
          success: false,
          message: "failed",
        };
        return this.response;
      }
      if (result) {
        this.response = {
          success: true,
          message: "community_added_succsessfully",
          data: result,
        };
      }
    } else {
      this.response = {
        success: false,
        message: "no_data",
      };
    }
    return this.response;
  }

  async editCommunity(body: ICommunitiesData, id: string) {
    let result;
    console.log("bodyy--->", body);
    if (
      body.image &&
      body?.image?.data &&
      body?.image?.data.includes("base64")
    ) {
      let imageUrl = await uploadImage(
        body?.image?.data,
        "boat-buttler-media",
        `community/${Date.now()}`,
        body.image.format
      );
      body.image.data = imageUrl;
      {
        body.oldImage.length > 0 && body.oldImage
          ? deleteFileFromS3(body.oldImage)
          : "";
      }
      // deleteFileFromS3(body.oldImage);
    }
    delete body.oldImage;
    body.image = body.image.data;
    try {
      console.log("Final body", body);
      result = await Communities.updateMany(
        {
          _id: id,
        },
        { $set: body }
      );
      console.log("result-------", result);
    } catch (err) {
      this.response = {
        success: false,
        message: "updation_failed",
      };
    }

    if (result) {
      this.response = {
        success: true,
        message: "community_updated_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  async getCommunityById(_id: string, user_id: string) {
    let res;
    let role = "";

    try {
      res = await Communities.findOne({ _id: _id, status: "Active" });

      console.log("------>", res);
      if (res.user_id.equals(new ObjectId(user_id))) {
        console.log("--Inside user_id-->", user_id);
        role = "admin";

        console.log("resss", res);
        this.response = {
          success: true,
          message: "community_found",
          data: { res, role },
        };
        return this.response;
      }

      let data = await CommunityMembers.aggregate([
        {
          $match: {
            $and: [
              { community_id: new ObjectId(_id) },
              { user_id: new ObjectId(user_id) },
            ],
          },
        },
      ]);
      console.log("Community----Membersdata---->", data);
      if (data.length > 0 && data[0].status === "Pending") {
        role = "requested";
      } else if (data.length > 0 && data[0].status === "Accepted") {
        role = "member";
      } else if (data.length > 0 && data[0].status === "Blocked") {
        role = "blocked";
      } else {
        role = "guest";
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "community_found",
        data: { res, role },
      };
    } else {
      this.response = {
        success: false,
        message: "community_not_found",
      };
    }

    return this.response;
  }

  async getCommunityDetails(
    _id: string,
    status: string,
    offset: number,
    query: string
  ) {
    let res;
    let count;
    let matchObject;
    let skip = isNaN(+offset) ? 0 : offset;
    console.log("getCommunityRequestStatus", _id);
    {
      query && query.length > 0
        ? (matchObject = {
            "community_user_details.name": { $regex: query, $options: "i" },
          })
        : (matchObject = {});
    }

    try {
      count = await CommunityMembers.find({
        community_id: _id,
        status: status,
      }).count();

      res = await CommunityMembers.aggregate([
        {
          $match: {
            community_id: new ObjectId(_id),
            status: status,
          },
        },

        // { $group: { role: "$user_role" } },
        {
          $lookup: {
            from: "users",
            let: { user_id: "$user_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
              { $project: { name: 1, image: 1 } },
            ],
            as: "community_user_details",
          },
        },
        { $unwind: "$community_user_details" },
        {
          $match: matchObject,
        },
        { $skip: skip },
        { $limit: 5 },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community_posts",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "community__found",
        data: { res, total_count: count },
      };
    } else {
      this.response = {
        success: false,
        message: "community__not_found",
      };
    }

    return this.response;
  }

  async getCommunityPosts(_id: string, offset: number, user_id: string) {
    let res;

    let skip = isNaN(+offset) ? 0 : offset;
    console.log("----Skip-", skip);
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      res = await Post.aggregate([
        {
          $match: {
            type: "community",
            type_item_id: _id,
            status: "Published",
          },
        },
        { $sort: { created_ts: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $lookup: {
            from: "post_comments",
            localField: "_id",
            foreignField: "post_id",
            pipeline: [
              {
                $match: {
                  status: "Active",
                },
              },
              {
                $count: "total",
              },
            ],
            as: "post_comments",
          },
        },

        {
          $lookup: {
            from: "posts",
            let: { shared_post_id: "$shared_post_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$_id", "$$shared_post_id"] } } },
              {
                $lookup: {
                  from: "users",
                  let: { user_id: "$user_id" },
                  pipeline: [
                    { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
                  ],
                  as: "post_creator_detail",
                },
              },
            ],
            as: "shared_post_detail",
          },
        },

        { $skip: skip },
        { $limit: 5 },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community_posts",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "community_posts_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "community_posts_not_found",
      };
    }

    return this.response;
  }

  async joinCommunity(data: { community_id: string; userId: string }) {
    let result;

    result = await CommunityMembers.create({
      user_id: data?.userId,
      community_id: data?.community_id,
      status: "Pending",
    });
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "request send Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
  async getCommunityList(user_id: string, offset: number, type: string) {
    let limit = isNaN(+offset) ? 0 : offset;
    let myCommunityList = [];
    let joinedCommunity = [];
    let suggestedCommunityList;
    console.log("Type is--->", type);
    try {
      switch (type) {
        case "Joined":
          console.log("Joined switch case");
          joinedCommunity = await CommunityMembers.aggregate([
            {
              $match: {
                user_id: new ObjectId(user_id),
                status: "Accepted",
              },
            },

            {
              $lookup: {
                from: "communities",
                foreignField: "_id",
                localField: "community_id",
                pipeline: [
                  {
                    $match: {
                      status: "Active",
                    },
                  },
                ],
                as: "community_detail",
              },
            },
            { $unwind: "$community_detail" },
          ])
            .skip(limit)
            .limit(5);
          break;
        case "Suggested":
          console.log("Suggested switch case");
          suggestedCommunityList = await Communities.aggregate([
            {
              $match: {
                user_id: { $ne: new ObjectId(user_id) },
                status: "Active",
              },
            },
            {
              $lookup: {
                from: "community_members",
                foreignField: "community_id",
                localField: "_id",
                as: "communityMember_detail",
              },
            },
            { $match: { communityMember_detail: [] } },
          ])

            .skip(limit)
            .limit(5);

          break;
        case "My":
          console.log("My switch case");
          myCommunityList = await Communities.aggregate([
            {
              $match: {
                user_id: new ObjectId(user_id),
                status: "Active",
              },
            },
          ])
            .skip(limit)
            .limit(5);

          break;
        case "All":
          console.log("All CommunityCase");
          myCommunityList = await Communities.aggregate([
            {
              $match: {
                user_id: new ObjectId(user_id),
                status: "Active",
              },
            },
          ])
            .skip(limit)
            .limit(5);
          joinedCommunity = await CommunityMembers.aggregate([
            {
              $match: {
                user_id: new ObjectId(user_id),
                status: "Accepted",
              },
            },

            {
              $lookup: {
                from: "communities",
                foreignField: "_id",
                localField: "community_id",
                pipeline: [
                  {
                    $match: {
                      status: "Active",
                    },
                  },
                ],
                as: "community_detail",
              },
            },
            { $unwind: "$community_detail" },
          ])
            .skip(limit)
            .limit(5);

          suggestedCommunityList = await Communities.aggregate([
            {
              $match: {
                user_id: { $ne: new ObjectId(user_id) },
              },
            },
            {
              $lookup: {
                from: "community_members",
                foreignField: "community_id",
                localField: "_id",
                as: "communityMember_detail",
              },
            },
            { $match: { communityMember_detail: [] } },
          ])
            .skip(limit)
            .limit(5);

          break;
        default:
          console.log("Default switch case");
          this.response = {
            success: false,
            message: "could_not_get_community",
          };
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_get_community",
      };

      return this.response;
    }
    this.response = {
      success: true,
      message: "community_found",
      data: { myCommunityList, joinedCommunity, suggestedCommunityList },
    };

    return this.response;
  }
  async communityRequest(
    user_id: string,
    status: string,
    community_id: string
  ) {
    let result;
    console.log("s C U ", status, community_id, user_id);
    console.log("  let status;", status);
    try {
      const query = {
        user_id: user_id,
        community_id: community_id,
      };
      const setQuery = {
        $set: {
          status: status,
        },
      };

      result = await CommunityMembers.updateOne(query, setQuery);

      console.log("  let afgter results-->;", result);
    } catch (err) {
      this.response = {
        success: false,
        message: "updation_failed",
      };
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "updated",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
  async communityReport(data) {
    console.log("communityReport data", data);

    try {
      if (data.type === "report") {
        await Communities.findByIdAndUpdate(
          data.type_id,
          {
            $set: {
              reported: {
                user_id: new ObjectId(data.userId),
                date: new Date(),
              },
              status: "Reported",
            },
          },
          { new: true }
        );
      } else {
        await CommunityMembers.findByIdAndUpdate(
          data._id,
          {
            $set: {
              reported: {
                user_id: new ObjectId(data.userId),
                date: new Date(),
              },
              status: "Reported",
            },
          },
          { new: true }
        );
      }
    } catch (error) {
      this.response = {
        success: false,
        message: "failed",
      };

      return this.response;
    }
    this.response = {
      success: true,
      message: "reported_successfully",
    };

    return this.response;
  }
  async deleteMember(user_id: string, community_id: string) {
    let result;

    try {
      const query = {
        user_id: user_id,
        community_id: community_id,
      };
      console.log("   query-->;", query);
      result = await CommunityMembers.deleteOne(query);

      console.log("   deleteOne-->;", result);
    } catch (err) {
      this.response = {
        success: false,
        message: "deletion_failed",
      };
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "deleted",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
}

export default new CommunitiesServices();
