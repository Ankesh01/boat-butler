import { ResponseObject } from "../Interfaces/commonInterfaces";
import { Forum } from "../models/forum";
import { ForumTopic } from "../models/forumtopics";
import { ForumMain } from "../models/forum_main";
import { ObjectId } from "mongodb";

class ForumService {
  private response: ResponseObject;

  // async getAllForum() {
  //   let result;
  //   try {
  //     result = await Forum.find();
  //   } catch (err) {
  //     this.response = {
  //       success: false,
  //       message: "Forum_data_failed",
  //     };
  //     return this.response;
  //   }
  //   if (result) {
  //     this.response = {
  //       success: true,
  //       data: result,
  //       message: "forum_data_fetched_successfully",
  //     };
  //   } else {
  //     this.response = {
  //       success: false,
  //       data: result,
  //       message: "could_not_fetch",
  //     };
  //   }

  //   return this.response;
  // }
  async getAllForum() {
    let result;
    try {
      result = await ForumTopic.find({ is_active: { $ne: false } });
    } catch (err) {
      this.response = {
        success: false,
        message: "Forum_data_failed",
      };
      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "forum_data_fetched_successfully",
      };
    } else {
      this.response = {
        success: false,
        data: result,
        message: "could_not_fetch",
      };
    }

    return this.response;
  }

  async addForumTopics(body) {
    console.log("add--------------?", body);
    console.log("body.forumSaveList", body.forumSaveList);
    let result;
    result = await ForumTopic.updateMany(
      { _id: { $in: body.forumSaveList } },
      { $push: { user_id: body.user_id } },
      { new: true }
    );
    /*body.forumSaveList.map(async (item) => {

    });*/

    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "Forum Topics Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
  async getUserForumTopicById(body) {
    console.log("getUserForumTopicsById body", body);
    let result;
    result = await ForumTopic.aggregate([
      {
        $match: {
          user_id: body._id,
          is_active: true,
        },
      },
      { $project: { _id: 1, title: 1 } },
    ]);

    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "user_forum_topic",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
}

export default new ForumService();
