import moment from "moment";
import { UserNotifications } from "../models/userNotifications";
import { ObjectId } from "mongodb";
import { sendNotification } from "../utils/fcmNotification";
const CronJob = require("cron").CronJob;
import Helper from "../utils/helper";
export const intializeCronJobs = () => {
  notificationCronJob();
};

const notificationCronJob = () => {
  const job = new CronJob(
    "*/1 * * * *",
    function () {
      console.log(
        `notificationCronJob started at : `,
        moment.utc().format("DD-MM-YYYY HH:mm:SS")
      );
      generateReminderNotification();
    },
    null,
    true,
    "America/Los_Angeles"
  );
  job.start();
};

const generateReminderNotification = async () => {
  const currentDateTime = new Date(moment.utc().format("MM-DD-YYYY HH:mm"));
  console.log(
    "checking for notifications at ",
    moment(currentDateTime).format("DD-MM-YYYY HH:mm:SS"),
    currentDateTime
  );
  const previousDate = new Date(currentDateTime);
  previousDate.setDate(currentDateTime.getDate() - 1);
  const nextDate = new Date(currentDateTime);
  nextDate.setDate(currentDateTime.getDate() + 1);
  console.log(
    "previousDate ",
    moment(previousDate).format("DD-MM-YYYY HH:mm:SS")
  );
  console.log("nextDate ", moment(nextDate).format("DD-MM-YYYY HH:mm:SS"));
  const result = await UserNotifications.aggregate([
    {
      $match: {
        due_date: { $gte: previousDate, $lt: nextDate },
        send_status: 0,
      },
    },
    {
      $lookup: {
        from: "users",
        localField: "user_id",
        foreignField: "_id",
        as: "userInfo",
      },
    },
  ]);

  // console.log("result UserNotifications", JSON.stringify(result));

  let updateSendStatusIdList = [];
  for (let data of result) {
    const timezone = data.userInfo[0]["timezone"];
    const convertedTime = await Helper.convertTZ(currentDateTime, timezone);
    if (
      data.due_date.getTime() === convertedTime.getTime() &&
      data.userInfo[0]?.fcm_token
    ) {
      console.log("time matched! now sending notification");
      await sendNotification(
        [data.userInfo[0]?.fcm_token],
        data.message.title,
        data.message.body
      );
      updateSendStatusIdList.push(data._id);
    }
  }

  if (updateSendStatusIdList.length > 0) {
    const updateResult = await UserNotifications.updateMany(
      {
        _id: {
          $in: updateSendStatusIdList.map((i) => new ObjectId(i)),
        },
      },
      {
        $set: {
          send_status: 1,
        },
      }
    );
  }
};
