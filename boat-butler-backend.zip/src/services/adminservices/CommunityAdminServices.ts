import bcrypt from "bcryptjs";
import { Types } from "mongoose";
import { Communities } from "../../models/communities";
import { Post } from "../../models/posts";
import { Users } from "../../models/users";
import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";

import { ObjectId } from "mongodb";
import { reported } from "../../controllers/PostsController";
import { pipeline } from "stream";
import { CommunityMembers } from "../../models/community_members";

class CommunityAdminServices {
  private response: ResponseObject;

  async getCommunityList(data: any) {
    const { offset } = data;
    const limit = Number(offset);
    let communityInfo;

    communityInfo = await Communities.aggregate([
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $lookup: {
          from: "community_members",
          pipeline: [
            {
              $match: {
                status: "Accepted",
              },
            },
            { $count: "id" },
          ],
          localField: "_id",
          foreignField: "community_id",
          as: "active_members",
        },
      },

      {
        $sort: {
          created_ts: -1,
        },
      },
    ])
      .skip(limit)
      .limit(10);
    if (communityInfo.length === 0) {
      this.response = {
        success: false,
        message: "no_community_exist",
        data: "",
      };
      return this.response;
    }

    const count = await Communities.find().count();

    const count_users = await CommunityMembers.aggregate([
      {
        $group: {
          _id: "$user_id",
          count: { $sum: 1 },
        },
      },
      { $count: "id" },
    ]);

    communityInfo = {
      communityInfo: communityInfo,
      count: count,
      count_users: count_users,
    };
    this.response = {
      success: true,
      message: "community_exist",
      data: communityInfo,
    };

    return this.response;
  }

  async searchCommunityList(data: any) {
    const { offset, search } = data;
    const limit = Number(offset);
    let communityInfo;

    if (search) {
      communityInfo = await Communities.aggregate([
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $match: {
            $or: [
              { title: { $regex: search, $options: "i" } },
              { status: { $regex: search, $options: "i" } },
            ],
          },
        },
        {
          $lookup: {
            from: "community_members",
            pipeline: [
              {
                $match: {
                  status: "Accepted",
                },
              },
              { $count: "id" },
            ],
            localField: "_id",
            foreignField: "community_id",
            as: "active_members",
          },
        },
      ])
        .limit(10)
        .skip(limit);
      const count = await Communities.find().count();
      const count_users = await CommunityMembers.aggregate([
        {
          $group: {
            _id: "$user_id",
            count: { $sum: 1 },
          },
        },
        { $count: "id" },
      ]);

      if (communityInfo.length > 0) {
        communityInfo = {
          communityInfo: communityInfo,
          count: count,
          count_users: count_users,
        };
        this.response = {
          success: true,
          data: communityInfo,
          message: "communities_found",
        };
      } else {
        this.response = {
          success: false,
          message: "communities_doesnt_exist",
          data: "",
        };
      }
    }

    return this.response;
  }

  async getCommunityDetail(_id: any, offset: any) {
    console.log("offset", offset);

    const limit = Number(offset);
    let resultData;
    const matchObject = {
      _id: new ObjectId(_id),
    };

    resultData = await Communities.aggregate([
      {
        $match: matchObject,
      },
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $lookup: {
          from: "posts",
          let: { reported: "$reported" },
          as: "reportedPosts",
          pipeline: [
            {
              $match: {
                type: "community",
                type_item_id: `${_id}`,
                status: "Reported",
              },
            },

            {
              $sort: {
                created_ts: -1,
              },
            },
            { $limit: 2 },
            {
              $lookup: {
                from: "users",
                localField: "reported.user_id",
                foreignField: "_id",
                as: "reported_by",
                pipeline: [
                  {
                    $project: { reported_by: "$name" },
                  },
                ],
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "posts",

          pipeline: [
            {
              $match: {
                type: "community",
                status: "Published",
                type_item_id: `${_id}`,
              },
            },

            {
              $lookup: {
                from: "posts",
                let: { shared_post_id: "$shared_post_id" },
                pipeline: [
                  { $match: { $expr: { $eq: ["$_id", "$$shared_post_id"] } } },
                  {
                    $lookup: {
                      from: "users",
                      let: { user_id: "$user_id" },
                      pipeline: [
                        { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
                      ],
                      as: "post_creator_detail",
                    },
                  },
                ],
                as: "shared_post_detail",
              },
            },

            {
              $lookup: {
                from: "post_comments",

                localField: "_id",
                foreignField: "post_id",
                as: "post_comments",
              },
            },
            {
              $lookup: {
                from: "users",
                localField: "user_id",
                foreignField: "_id",
                as: "post_info",
              },
            },

            {
              $sort: {
                created_ts: -1,
              },
            },
            { $limit: 3 },
          ],
          as: "allPosts",
        },
      },
    ]);

    if (resultData) {
      resultData = { communityData: resultData };
      this.response = {
        success: true,
        message: "found_communities",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_find_communities",
        data: "",
      };
    }

    return this.response;
  }

  async getCommunityDetailByType(_id: any, offset: any, type: any) {
    const limit = Number(offset);
    console.log("limit", limit);

    let resultData;
    const matchObject = {
      _id: new ObjectId(_id),
    };
    if (type === "allPosts") {
      resultData = await Communities.aggregate([
        {
          $match: matchObject,
        },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $lookup: {
            from: "posts",

            pipeline: [
              {
                $match: {
                  type: "community",
                  status: "Published",
                  type_item_id: `${_id}`,
                },
              },
              {
                $lookup: {
                  from: "posts",
                  let: { shared_post_id: "$shared_post_id" },
                  pipeline: [
                    {
                      $match: { $expr: { $eq: ["$_id", "$$shared_post_id"] } },
                    },
                    {
                      $lookup: {
                        from: "users",
                        let: { user_id: "$user_id" },
                        pipeline: [
                          { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
                        ],
                        as: "post_creator_detail",
                      },
                    },
                  ],
                  as: "shared_post_detail",
                },
              },
              {
                $lookup: {
                  from: "post_comments",

                  localField: "_id",
                  foreignField: "post_id",
                  as: "post_comments",
                },
              },
              {
                $lookup: {
                  from: "users",
                  localField: "user_id",
                  foreignField: "_id",
                  as: "post_info",
                },
              },

              {
                $sort: {
                  created_ts: -1,
                },
              },
            ],
            as: "allPosts",
          },
        },
      ])
        .skip(limit)
        .limit(6);
    } else if (type === "reportedPosts") {
      resultData = await Communities.aggregate([
        {
          $match: matchObject,
        },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $lookup: {
            from: "posts",

            pipeline: [
              {
                $match: {
                  type: "community",
                  status: "Reported",
                  type_item_id: `${_id}`,
                },
              },

              {
                $sort: {
                  created_ts: -1,
                },
              },
            ],
            as: "reportedPosts",
          },
        },
      ])
        .skip(limit)
        .limit(3);
    }

    if (resultData) {
      resultData = { communityData: resultData };
      this.response = {
        success: true,
        message: "found_communities",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_find_communities",
        data: "",
      };
    }

    return this.response;
  }

  async getReportedUser(_id: string, offset: string) {
    console.log("offset------", offset);
    const limit = Number(offset);
    console.log("_id--------", _id);
    let resultData;
    const matchObject = {
      _id: new ObjectId(_id),
    };
    console.log("matchObject", matchObject);
    resultData = await Communities.aggregate([
      // {
      //   $match: matchObject,
      // },

      {
        $lookup: {
          from: "posts",

          pipeline: [
            {
              $match: {
                type: "community",
                type_item_id: _id,
              },
            },
            {
              $lookup: {
                from: "post_comments",

                let: { post_id: "$_id" },
                pipeline: [
                  {
                    $match: {
                      status: "Reported",
                      // post_id: "62443c333adb6ccd9270321a",
                      $expr: { $eq: ["$post_id", "$$post_id"] },
                    },
                  },
                  {
                    $lookup: {
                      from: "users",
                      let: { user_id: "$user_id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: { $eq: ["$_id", "$$user_id"] },
                          },
                        },
                      ],
                      as: "report_user_info",
                    },
                  },

                  {
                    $sort: {
                      created_ts: -1,
                    },
                  },
                ],
                as: "reportedUser",
              },
            },
          ],

          as: "Post_Info",
        },
      },
    ])
      .skip(limit)
      .limit(5);

    // resultData = await Communities.aggregate([
    //   {
    //     $match: matchObject,
    //   },
    //   {
    //     $lookup: {
    //       from: "users",
    //       localField: "user_id",
    //       foreignField: "_id",
    //       as: "userInfo",
    //     },
    //   },
    // ]);

    // reportedUserInfo = await Users.aggregate([

    //         {
    //           $match: {
    //             is_reported: 1,
    //             account_type: "Member",

    //           },

    //         },
    //         { $lookup: {
    //           from: "users",
    //           localField: "reported_by",
    //           foreignField: "_id",
    //           as: "reportedByUser"
    //         }},
    //         {
    //         $sort: {
    //           created_ts: -1,
    //         },

    //   },
    // ])

    if (resultData) {
      resultData = { communityData: resultData };
      this.response = {
        success: true,
        message: "found_communities",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_find_communities",
        data: "",
      };
    }

    return this.response;
  }

  //  async getReportedUser(_id: any, offset: any) {
  //     console.log("offset------", offset);
  //     const limit = Number(offset);
  //     console.log("_id--------", _id);
  //     let resultData;
  //     const matchObject = {
  //       _id: new ObjectId(_id),
  //     };
  //     resultData = await Users.aggregate([
  //       // {
  //       //   $match: { user_id: new ObjectId(_id) },
  //       // },
  //       // let : { user_id: "$user_id" }
  //       // {
  //       //   $match: matchObject,
  //       // },
  //       {
  //         $lookup: {
  //           from: "post_comments",
  //           as: "post_comment_info",
  //           // let: { post_id: "$_id" },
  //           pipeline: [
  //             {
  //               $match: {
  //                 status: "Reported",
  //                 post_id: "624e78e98d68a92410a3f759",
  //                 // $expr: { $eq: ["$post_id", "$$post_id"] },
  //               },
  //             },
  //             {
  //               $lookup: {
  //                 from: "posts",
  //                 as: "post_info",
  //                 pipeline: [
  //                   {
  //                     $match: {
  //                       // user_id: new ObjectId("620b4a5f6aa32c6f14df7b50"),
  //                       // _id: new ObjectId("624e78e98d68a92410a3f759"),
  //                       type: "community",
  //                       type_item_id: _id,
  //                     },
  //                   },
  //                 ],
  //               },
  //             },
  //           ],
  //         },
  //       },

  //       {
  //         $match: matchObject,
  //       },

  //       // {
  //       //   $match: {
  //       //     post_info: { $ne: [] },
  //       //   },
  //       // },
  //     ])
  //       .skip(limit)
  //       .limit(5);

  //     if (resultData) {
  //       resultData = { communityData: resultData };
  //       this.response = {
  //         success: true,
  //         message: "found_communities",
  //         data: resultData,
  //       };
  //     } else {
  //       this.response = {
  //         success: false,
  //         message: "Could_not_find_communities",
  //         data: "",
  //       };
  //     }

  //     return this.response;
  //   }

  async blockUser(_id: any) {
    let resultData;

    resultData = await Users.updateOne(
      { _id: _id },
      {
        $set: {
          is_reported: 1,
        },
      }
    );

    if (resultData) {
      // resultData = { communityData: resultData };
      this.response = {
        success: true,
        message: "block_user",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_block_user",
        data: "",
      };
    }

    return this.response;
  }

  async deleteReportedPost(_id, type) {
    let response;
    console.log(
      "_id ************************************************type",
      _id,
      type
    );
    try {
      if (type === "unblock") {
        response = await Post.updateOne(
          { _id: _id },
          {
            $set: {
              status: "Published",
            },
          }
        );
        if (response) {
          this.response = {
            success: true,
            message: "post_updated_successfully",
          };
        }
      } else {
        response = await Post.deleteOne({ _id: _id });
        if (response) {
          this.response = {
            success: true,
            message: "post_deleted",
          };
        }
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_delete_post",
      };
    }

    return this.response;
  }

  async blockCommunity(_id, type) {
    let response;
    console.log(
      "_id ************************************************type",
      _id,
      type
    );
    try {
      if (type === "unblock") {
        response = await Communities.updateOne(
          { _id: _id },
          {
            $set: {
              status: "Active",
            },
          }
        );
        if (response) {
          this.response = {
            success: true,
            message: "community_updated_successfully",
          };
        }
      } else {
        response = await Communities.updateOne(
          { _id: _id },
          {
            $set: {
              status: "Blocked",
            },
          }
        );
        if (response) {
          this.response = {
            success: true,
            message: "community_blocked",
          };
        }
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_block_community",
      };
    }

    return this.response;
  }

  // async qwerty() {
  //   console.log("************************************************");

  //   await Post.updateOne(
  //     { _id: "62443da33adb6ccd9270323b" },
  //     {
  //       $set: {
  //         reported: [{ user_id: "621385b1071dbfeec8926753", time: new Date() }],
  //       },
  //     }
  //   );
  // }
}

export default new CommunityAdminServices();
