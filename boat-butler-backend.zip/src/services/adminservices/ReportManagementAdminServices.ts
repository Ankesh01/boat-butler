import { Communities } from "../../models/communities";
import { Pages } from "../../models/pages";
import { PostComments } from "../../models/post_comments";
import { Users } from "../../models/users";
class ReportManagementServices {
  private response: any;

  /**
   * @method to get all list of users
   * @param data
   * @param user_id
   * @returns
   */
  async getAllReportedUserList(data: any) {
    const { offset } = data;

    let offsets = isNaN(+offset) ? 0 : offset;

    let res;
    let count;

    try {
      res = await PostComments.aggregate([
        {
          $match: {
            status: "Reported",
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "reported.user_id",
            foreignField: "_id",
            as: "reported_by",

            pipeline: [
              {
                $project: { reported_by: "$name", reported_by_image: "$image" },
              },
            ],
          },
        },
        { $unwind: "$reported_by" },
        {
          $lookup: {
            from: "users",
            as: "user_info",
            localField: "user_id",
            foreignField: "_id",
          },
        },
        {
          $group: {
            _id: "$user_id",
            reported_by: { $push: "$reported_by" },
            comments: { $push: "$comment" },
            user_info: { $first: "$user_info" },

            reported_date: { $max: "$reported.date" },
          },
        },
      ])
        // .skip(offset)
        // .limit(5)

        .sort({ created_ts: -1 });
    } catch (e) {
      console.error(e);
      this.response = {
        success: false,
        message: "Could_not_find_reported_user",
      };

      return this.response;
    }
    if (res) {
      count = await Users.find({ is_reported: 1 }).count();
      res = { res: res, count: count };
      this.response = {
        success: true,
        message: "Reported_user_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "Reported_user_not_found",
      };
    }

    return this.response;
  }

  /**
   * @method to get all list of community
   * @param data
   * @param user_id
   * @returns
   */
  async getAllReportedCommunityList(data: any) {
    const { offset } = data;

    let res;
    let count;

    try {
      //   res = await Communities.find({ status: "Reported" })
      //     .skip(offset)
      //     .limit(5)
      //     .sort({ created_ts: -1 });

      res = await Communities.aggregate([
        {
          $match: {
            status: "Reported",
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "reported.user_id",
            foreignField: "_id",
            as: "reported_by",
            pipeline: [
              {
                $project: { reported_by: "$name" },
              },
            ],
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_reported_community",
      };

      return this.response;
    }
    if (res) {
      count = await Communities.find({
        status: "Reported",
      }).count();
      res = { res: res, count: count };
      this.response = {
        success: true,
        message: "Reported_community_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "Reported_community_not_found",
      };
    }

    return this.response;
  }

  async blockUser(_id, type) {
    let response;
    console.log(
      "_id ************************************************type",
      _id,
      type
    );
    try {
      if (type === "unblock") {
        response = await Users.updateOne(
          { _id: _id },
          {
            $set: {
              status: "Active",
            },
          }
        );
        if (response) {
          this.response = {
            success: true,
            message: "user_updated_successfully",
          };
        }
      } else {
        response = await PostComments.updateMany(
          { user_id: _id },
          {
            $set: {
              status: "Blocked",
            },
          }
        );

        // response = await Users.aggregate([
        //   {
        //     $match: {
        //       _id: _id,
        //     },
        //   },
        //   {
        //     $set: {
        //       status: "Blocked",
        //       is_reported: 1,
        //     },
        //   },
        //   {
        //     $lookup: {
        //       from: "post_comments",
        //       as: "block_comment",
        //       localField: "_id",
        //       foreignField: "user_id",

        //       pipeline: [
        //         {
        //           $set: {
        //             status: "Blocked",
        //           },
        //         },
        //       ],
        //     },
        //   },
        // ]);

        console.log("response", response);

        if (response) {
          this.response = {
            success: true,
            message: "user_blocked",
          };
        }
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_block_user",
      };
    }

    return this.response;
  }
}

export default new ReportManagementServices();
