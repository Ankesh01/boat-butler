import bcrypt from "bcryptjs";
import { Types } from "mongoose";
import { Boat } from "../../models/boat";
import { BoatService } from "../../models/boatServices";
import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";
import { ObjectId } from "mongodb";

interface UserDetail {
  userId: string;
}

class BoatAdminServices {
  private response: ResponseObject;

  async getboatlist(data: any) {
    const { offset } = data;
    const limit = Number(offset);
    const account_type = "Member";
    const query = { account_type };

    let BoatInfo: any = await Boat.aggregate([
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
    ])
      .skip(limit)
      .limit(10);

    // console.log("accountInfo------", accountInfo);
    if (BoatInfo.length === 0) {
      this.response = {
        success: false,
        message: "no_boat_exist",
        data: "",
      };
      return this.response;
    }

    if (BoatInfo) {
      const count = await Boat.find().count();
      const getBeginningOfTheWeek = (now) => {
        const days = (now.getDay() + 7 - 1) % 7;
        now.setDate(now.getDate() - days);
        now.setHours(0, 0, 0, 0);
        return now;
      };
      const result = await Boat.aggregate([
        {
          $match: {
            created_ts: {
              $gte: getBeginningOfTheWeek(new Date()),
              $lt: new Date(),
            },
          },
        },
        {
          $group: {
            _id: null,
            count: { $sum: 1 },
          },
        },
      ]);
      BoatInfo = { BoatInfo: BoatInfo, count: count, countInWeek: result };
      this.response = {
        success: true,
        message: "boat_exist",
        data: BoatInfo,
      };
    }
    return this.response;
  }

  async searchboatlist(data: any) {
    const { offset, search } = data;
    const limit = Number(offset);
    let BoatInfo;

    if (search) {
      BoatInfo = await Boat.aggregate([
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $match: {
            $or: [
              { title: { $regex: search, $options: "i" } },
              { Model: { $regex: search, $options: "i" } },
            ],
          },
        },
      ])
        .limit(10)
        .skip(limit);
      const count = await Boat.find().count();
      const getBeginningOfTheWeek = (now) => {
        const days = (now.getDay() + 7 - 1) % 7;
        now.setDate(now.getDate() - days);
        now.setHours(0, 0, 0, 0);
        return now;
      };
      const result = await Boat.aggregate([
        {
          $match: {
            created_ts: {
              $gte: getBeginningOfTheWeek(new Date()),
              $lt: new Date(),
            },
          },
        },
        {
          $group: {
            _id: null,
            count: { $sum: 1 },
          },
        },
      ]);

      if (BoatInfo.length > 0) {
        BoatInfo = { BoatInfo: BoatInfo, count: count, countInWeek: result };
        this.response = {
          success: true,
          data: BoatInfo,
          message: "Boat_found",
        };
      } else {
        this.response = {
          success: false,
          message: "Boat_doesnt_exist",
          data: BoatInfo,
        };
      }
    }

    return this.response;
  }

  async boatdetaillist(data: any) {
    const { _id } = data;
    console.log("_id", _id);
    let resultData;

    const matchObject = {
      boat_id: new ObjectId(_id),
    };

    const boatData = await Boat.aggregate([
      {
        $match: { _id: new ObjectId(_id) },
      },
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $sort: {
          due_date: -1,
        },
      },
    ]);

    if (boatData) {
      resultData = await BoatService.aggregate([
        {
          $match: matchObject,
        },
      ]);
      console.log("resultData", resultData);
      if (resultData) {
        resultData = { resultData: resultData, boatData: boatData };
        this.response = {
          success: true,
          message: "found_boatService",
          data: resultData,
        };
      } else {
        this.response = {
          success: false,
          message: "Could_not_find_boatService",
          data: resultData,
        };
      }
    } else {
      this.response = {
        success: false,
        message: "user_detail_not_found",
        data: "",
      };
    }

    return this.response;
  }
}

export default new BoatAdminServices();
