import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import { Types } from "mongoose";
import { Users } from "../../models/users";
import { SubscriptionPlans } from "../../models/subscription_plans";
import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";
import { sendMail } from "../../utils/emailService";
dotenv.config();
const homeUrl = process.env.REACT_APP_API_URL;

interface LoginData {
  email: string;
  password?: string;
}

interface ResetPasswordData {
  newPassword: string;
  confirmNewPassword?: string;
  resetKey: string;
}

class AuthAdminServices {
  private response: ResponseObject;

  async login(data: LoginData) {
    console.log("Login---------", data);
    const { email, password } = data;
    const account_type = "Admin";
      const query1 = { email, account_type };
      let userInfo: any = await Users.findOne(query1);
      if (userInfo) {
        if (
          await bcrypt.compare(password.trim(), userInfo.password as string)
        ) {
          delete userInfo.password;
          const token = await createToken(userInfo);
          console.log("token  =>", token);

          userInfo = { ...userInfo, token };

          console.log("useinfo", userInfo);
          this.response = {
            success: true,
            message: "login_successful",
            data: userInfo,
            isLoggedIn: true,
          };
        } else {
          this.response = {
            success: false,
            message: "credientials_not_match",
            isLoggedIn: false,
          };
        }
      } else {
        this.response = {
          success: false,
          message: "no_user_found",
          isLoggedIn: false,
        };
      }
    
    return this.response;
  }

  async forgotPassword(data: LoginData) {
    const { email } = data;
    const account_type = "Admin";
    const query = { account_type, email };
    let resetKey = await bcrypt.hash(`${email}${Date.now()}`, 8);
    resetKey = resetKey.replace(/\//g, "");
    let accountInfo: any = await Users.find(query);
    if (accountInfo.length === 0) {
      this.response = {
        success: false,
        message: "Email-ID is not registered.",
        isLoggedIn: false,
      };
      return this.response;
    }

    if (accountInfo) {
      const resultData = await Users.updateOne(
        { email },
        { $set: { resetKey: resetKey } }
      );

      if (resultData) {
        const msg = {
          subject: `Forgot Password`,
          text: `Click the link below to change the password \n${homeUrl}/reset-password?resetKey=${resetKey}`,
          html: `<div>
              <p>Click the link below to change the password<p> 
              <a href="${homeUrl}/reset-password?resetKey=${resetKey}">
                <h3>Change Password</h3>
              </a>
          </div>`,
        };
        sendMail(email.toLowerCase(), msg)
          .then(() => {
            console.log("email sent");
          })
          .catch((error: any) => {
            console.log("error", error);
          });

        this.response = {
          success: true,
          message: "Change password mail is sent on your given Email-ID.",
        };
      } else {
        this.response = {
          success: false,
          message: "Email-ID is not registered.",
        };
      }
    }
    return this.response;
  }

  async resetPassword(data: ResetPasswordData) {
    const { newPassword, resetKey } = data;
    const hashedPassword = await bcrypt.hash(newPassword, 8);
    console.log(data);
    const account_type = "Admin";
    
   
  
      const query = {resetKey, account_type}
      const checkPassword = await Users.findOne(query);
      console.log("checkPassword", checkPassword)
      if( await !bcrypt.compareSync(newPassword.trim(), checkPassword.password as string)) {
        const resultData = await Users.updateOne(
          { resetKey },
          { $set: { password: hashedPassword } }
        );
        if(resultData) {
          this.response = {
            success: true,
            message: "Password updated",
          }
      }
    }else {
        this.response = {
          success: false,
          message: "Password similar to old password, write a different passwordr",
        }
      }
    
    return this.response;
  
}
}

export default new AuthAdminServices();
