import { ResponseObject } from "../../Interfaces/commonInterfaces";
import { Businesses } from "../../models/businesses";
import { Request, Response } from "express";
import axios from "axios";
interface IBusinessesService {
  owner_name: string;
  business_name: string;
  registration_number: string;
  contact_number: string;
  email: string;
  location: Object;
  business_hours: Object;
  services: string;
  photos: [];
  status: string;
}

class BusinessesServices {
  private response: ResponseObject;

  async getServiceProvidersList(query: string) {
    let res;
    let count;
    let thisWeekCount;
    try {
      if (query) {
        query = query.toLowerCase().trim();
        count = await Businesses.find().count();
        let date: any = new Date();
        thisWeekCount = await Businesses.find({
          created_ts: {
            $gte: new Date(date - 7 * 60 * 60 * 24 * 1000),
          },
        }).count();
        res = await Businesses.aggregate([
          {
            $match: {
              business_name: { $regex: query, $options: "i" },
              owner_name: { $regex: query, $options: "i" },
            },
          },
        ]);
      } else {
        // const getBeginningOfTheWeek = (now) => {
        //   const days = (now.getDay() + 7 - 1) % 7;
        //   now.setDate(now.getDate() - days);
        //   now.setHours(0, 0, 0, 0);
        //   return now;
        // };
        let date: any = new Date();
        thisWeekCount = await Businesses.find({
          created_ts: {
            $gte: new Date(date - 7 * 60 * 60 * 24 * 1000),
          },
        }).count();

        res = await Businesses.find().sort({ created_ts: -1 });
        count = await Businesses.find().count();
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_business_service_provider",
      };

      return this.response;
    }
    if (res) {
      res = { res: res, totalCount: count, thisWeekCount: thisWeekCount };
      this.response = {
        success: true,
        message: "service_provider_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "service_provider_not_found",
      };
    }

    return this.response;
  }

  async getGooglePlaceDetail(placeId) {
    let res;
    res = await axios({
      method: "get",
      url: `https://maps.googleapis.com/maps/api/place/details/json?placeid=${placeId}&key=AIzaSyBn6w23qRD7HXgmen3WC-nOT4HSdrbzvq8`,
    });
    this.response = {
      success: false,
      message: "Could_not_find_business_service_provider",
      data: res.data.result,
    };
    return this.response;
  }
}

export default new BusinessesServices();
