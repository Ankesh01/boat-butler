import { Payments } from "../models/payments";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { IPaymentsInterface } from "../Interfaces/IPaymentsInterface";

import { SubscriptionPlans } from "../models/subscription_plans";
import { ObjectId } from "mongodb";
class PaymentServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  async create(data: IPaymentsInterface) {
    console.log("body", data);
    if (data) {
      console.log("CREATE PAYMENT API CALL ********************* ", JSON.stringify(data))
      const PaymentInfo = await Payments.create({
        user_id: data.user_id,
        plan_id: data?.product?.id,
        transaction_id: data?.product?.transaction?.id,
        amount: data?.product?.price,
        mode: data?.product?.transaction?.type,
        end_date: data?.product?.expiryDate,
      });
      if (PaymentInfo) {
        this.response = {
          success: true,
          data: PaymentInfo,
          message: "payment_created_successfully",
        };
      } else {
        this.response = {
          success: false,
          message: "failed",
        };
      }
    }
    return this.response;
  }
  async getPlanList() {
    const PaymentInfo = await SubscriptionPlans.find();

    if (PaymentInfo) {
      this.response = {
        success: true,
        data: PaymentInfo,
        message: "plan_found_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }
  async getPaymentHistory(userId: string,offset:number) {
    let skip = isNaN(+offset) ? 0 : offset;
    const payment = await Payments.aggregate([
      {
        $match: {
          user_id: new ObjectId(userId),
        },
      },
      { $sort: { created_ts: -1 } },
      {
        $lookup: {
          from: "subscription_plans",
          localField: "plan_id",
          foreignField: "_id",
          as: "plan_info",
        },
      },
      { $skip: skip },
      { $limit: 5 },
         
    ]);

    if (payment) {
      this.response = {
        success: true,
        data: payment,
        message: "plan_found_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }
}
export default new PaymentServices();
