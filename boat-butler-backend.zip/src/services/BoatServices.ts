import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage, deleteFileFromS3 } from "../utils/fileUpload";
import { Boat } from "../models/boat";
import { BoatService } from "../models/boatServices";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { Engines } from "../models/engines";

interface IEngine {
  number_of_engines?: number;
  make?: string;
  model?: string;
  hours?: number;
  year?: number;
  serial_number?: string;
  manuals?: string[];
  photos?: string[];
}
interface IBoatServices {
  user_id?: string;
  title?: string;
  type?: string[];
  due_date?: Date;
  status?: string[];
  completion_date?: Date;
  receipts?: { data: string; format: string }[];
  boat_id?: string;
}

interface IBoat {
  equip: any;
  user_id?: string | number;
  engine?: IEngine;
  title: string;
  date: Date;
  phone_number: string;
  RegId: string;
  vin: string;
  boat_make: string;
  boat_model: string;
  year_hull: Date;
  engine_no: string;
  engine_make: string;
  engine_model: string;
  engine_hp?: number;
  engine_dry_weight?: number;
  engine_start_type?: string;
  engine_tilt_trim?: string;
  engine_fuel_type?: string;
  engine_year_model?: number;
  engine_strock_series?: string;
  engine_hours: string;
  engine_year: string;
  engine_SN: string;
  otherEquip?: IOtherEquipment[];
  equip_make: string;
  equip_model: string;
  year_bought: string;
  equip_SN: string;
  boat_image?: { data: string; format: string }[];
  engine_image?: { data: string; format: string }[];
  engine_manual?: { data: string; format: string }[];
  equipmentImages?: { string: string[] }[];
  isOtherMake?: boolean;
  isOtherModel?: boolean;
}

interface IOtherEquipment {
  equip_make: string;
  equip_model: string;
  year_bought: string;
  equip_SN: string;
  img?: string[];
}

class BoatServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data: IBoat) {
    console.log("create Boat Service called !", data);
    let image = [];
    for (let img of data.boat_image) {
      if (img.data && img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/${Date.now()}`,
          img.format
        );
        image.push(imageUrl);
      }
    }

    let manualImages = [];
    for (let img of data.engine_manual) {
      if (img.data && img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/engine/manuals/${Date.now()}`,
          img.format
        );
        manualImages.push(imageUrl);
      } else {
        manualImages.push(img.data);
      }
    }
    data.engine_manual = manualImages;

    let engineImages = [];
    for (let img of data.engine_image) {
      if (img.data && img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/engine/photos/${Date.now()}`,
          img.format
        );
        engineImages.push(imageUrl);
        //deleteFileFromS3(oldImage);
      }
    }
    data.engine_image = engineImages;

    let otherEquip = [];
    let index = 0;
    for (let equipment of data.otherEquip) {
      let image = [];
      if (
        data.equipmentImages[index.toString()] &&
        data.equipmentImages[index.toString()].length > 0
      ) {
        for (let img of data.equipmentImages[index.toString()]) {
          if (img.data.includes("base64")) {
            let imageUrl = await uploadImage(
              img.data,
              "boat-buttler-media",
              `boat/equipment/${Date.now()}`,
              img.format
            );
            image.push(imageUrl as string);
          }
        }
        otherEquip.push({ ...equipment, img: image });
      }
      index++;
    }

    if (data.isOtherMake || data.isOtherModel) {
      const engine = {
        make: data.engine_make,
        model: data.engine_model,
        hp: data.engine_hp,
        dry_weight: data.engine_hp,
        start_type: data.engine_start_type,
        tilt_trim: data.engine_tilt_trim,
        fuel_type: data.engine_fuel_type,
        year: data.engine_year_model,
        strock_series: data.engine_strock_series,
      };
      await Engines.create(engine);
    }

    if (data) {
      const BoatInfo = await Boat.create({
        user_id: data.user_id,
        title: data.title,
        date_of_bought: data.date,
        seller_phone: data.phone_number,
        registration_id: data.RegId,
        vin: data.vin,
        make: data.boat_make,
        model: data.boat_model,
        year_of_hull: data.year_hull,
        engine: {
          number_of_engines: data.engine_no,
          make: data.engine_make,
          model: data.engine_model,
          hours: data.engine_hours,
          year: data.engine_year,
          serial_number: data.engine_SN,
          manual: data.engine_manual,
          photos: data.engine_image,
        },
        other_equipments: otherEquip,
        photos: image,
      });

      if (BoatInfo) {
        this.response = {
          success: true,
          data: BoatInfo,
          message: "Boat Added Successfully",
        };
      } else {
        this.response = {
          success: false,
          message: "Failed",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }

  async getEngineMakeList() {
    const makeList = await Engines.aggregate([
      {
        $group: {
          _id: "$make",
          models: { $push: "$model" },
        },
      },
    ]);
    this.response = {
      success: true,
      data: makeList,
      message: "engine_makes",
    };
    return this.response;
  }

  async getBoatDetail(id: string, query: any) {
    // let boatInfo;
    console.log("query----------->", query);
    let result = [];
    if (query) {
      console.log("inside query.length");
      result = await Boat.aggregate([
        {
          $match: {
            user_id: new ObjectId(id),
          },
        },
        {
          $match: {
            $or: [
              { title: { $regex: query, $options: "$i" } },
              { "engine.make": { $regex: query, $options: "$i" } },
            ],
          },
        },
      ]);

      if (result) {
        this.response = {
          success: true,
          data: result,
          message: "searched_Boat",
        };
      }
    } else {
      try {
        result = await Boat.find({ user_id: id });
      } catch (e) {
        this.response = {
          success: false,
          message: "Could_not_find_boat_with_particular_user",
        };
        return this.response;
      }
      if (result) {
        this.response = {
          success: true,
          data: result,
          message: "Boat Found Successfully",
        };
      } else {
        this.response = {
          success: false,
          message: "Could_not_find_boat_with_particular_user",
        };
      }
    }
    return this.response;
  }

  async getBoatCountByUserId(userId: string) {
    let result;

    try {
      result = await Boat.find({ user_id: userId }).count();
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_boat_with_particular_user",
      };
      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "Successfull",
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_find_boat_with_particular_user",
      };
    }

    return this.response;
  }
  async searchFilters(data: string) {
    // const { query } = data;
    console.log("searched Keyword--->", data);

    if (data) {
      const boats = await Boat.aggregate([
        {
          $match: {
            title: { $regex: data, $options: "i" },
          },
        },
      ]);

      if (boats.length > 0) {
        this.response = {
          success: true,
          data: boats,
          message: "boat_found",
        };
      } else {
        this.response = {
          success: false,
          message: "boat_doesnt_exist",
        };
      }
    }
    return this.response;
  }

  async getBoatDetailById(boatId: string) {
    const result = await Boat.findOne({ _id: boatId });
    this.response = {
      success: true,
      message: "boat found",
      data: result,
    };
    return this.response;
  }

  async editBoatById(boatId: string, data: IBoat) {
    let image = [];

    for (let img of data.boat_image) {
      if (img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/${Date.now()}`
        );
        image.push(imageUrl);
      } else {
        image.push(img.data);
      }
    }

    let manualImages = [];
    for (let img of data.engine_manual) {
      if (img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/engine/manuals/${Date.now()}`,
          img.format
        );
        manualImages.push(imageUrl);
      } else {
        manualImages.push(img.data);
      }
    }
    data.engine_manual = manualImages;

    let engineImages = [];
    for (let img of data.engine_image) {
      if (img.data.includes("base64")) {
        let imageUrl = await uploadImage(
          img.data,
          "boat-buttler-media",
          `boat/engine/photos/${Date.now()}`,
          img.format
        );
        img = imageUrl as any;
        engineImages.push(imageUrl);
        //deleteFileFromS3(oldImage);
      } else {
        engineImages.push(img.data);
      }
    }
    data.engine_image = engineImages;

    let otherEquip = [];
    let index = 0;
    for (let equipment of data.otherEquip) {
      console.log(": inside for loop equipment" + equipment);
      let image = [];
      if (
        data.equipmentImages[index.toString()] &&
        data.equipmentImages[index.toString()].length > 0
      ) {
        for (let img of data.equipmentImages[index.toString()]) {
          console.log("img ------------------- ", typeof img);

          if (img.data.includes("base64")) {
            let imageUrl = await uploadImage(
              img.data,
              "boat-buttler-media",
              `boat/equipment/${Date.now()}`,
              img.format
            );
            image.push(imageUrl as string);
          } else {
            image.push(img.data);
          }
        }
        otherEquip.push({ ...equipment, img: image });
      }
      index++;
    }

    if (data.isOtherMake || data.isOtherModel) {
      const engine = {
        make: data.engine_make,
        model: data.engine_model,
        hp: data.engine_hp,
        dry_weight: data.engine_hp,
        start_type: data.engine_start_type,
        tilt_trim: data.engine_tilt_trim,
        fuel_type: data.engine_fuel_type,
        year: data.engine_year_model,
        strock_series: data.engine_strock_series,
      };
      await Engines.create(engine);
    }

    if (data) {
      console.log("otherEquip-------", otherEquip);
      console.log("data ************************ ", {
        user_id: data.user_id,
        title: data.title,
        date_of_bought: data.date,
        seller_phone: data.phone_number,
        registration_id: data.RegId,
        vin: data.vin,
        make: data.boat_make,
        model: data.boat_model,
        year_of_hull: data.year_hull,
        engine: {
          number_of_engines: data.engine_no,
          make: data.engine_make,
          model: data.engine_model,
          hours: data.engine_hours,
          year: data.engine_year,
          serial_number: data.engine_SN,
          manual: data.engine_manual,
          photos: data.engine_image,
        },
        other_equipments: otherEquip,
        photos: image,
      });
      const BoatInfo = await Boat.update(
        {
          _id: boatId,
        },
        {
          user_id: data.user_id,
          title: data.title,
          date_of_bought: data.date,
          seller_phone: data.phone_number,
          registration_id: data.RegId,
          vin: data.vin,
          make: data.boat_make,
          model: data.boat_model,
          year_of_hull: data.year_hull,
          engine: {
            number_of_engines: data.engine_no,
            make: data.engine_make,
            model: data.engine_model,
            hours: data.engine_hours,
            year: data.engine_year,
            serial_number: data.engine_SN,
            manual: data.engine_manual,
            photos: data.engine_image,
          },
          other_equipments: otherEquip,
          photos: image,
        }
      );

      if (BoatInfo) {
        this.response = {
          success: true,
          data: BoatInfo,
          message: "Boat Added Successfully",
        };
      } else {
        this.response = {
          success: false,
          message: "Failed",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }

  async getBoatServices(userId: string, queryObject: any) {
    let boatServices;

    console.log("getBoatServices called ! ", userId, queryObject);
    const currentDate = new Date();
    currentDate.setHours(0);
    currentDate.setMinutes(0);
    currentDate.setSeconds(0);
    currentDate.setMilliseconds(0);
    const matchObject = {
      user_id: new ObjectId(userId),
      due_date: { $gte: currentDate },
      status: "Pending",
    };
    if (queryObject.boatId && queryObject.boatId.length > 0) {
      matchObject["boat_id"] = new ObjectId(queryObject.boatId);
    }

    console.log("matchObject : ", matchObject);

    try {
      boatServices = await BoatService.aggregate([
        {
          $match: matchObject,
        },
        {
          $lookup: {
            from: "boats",
            localField: "boat_id",
            foreignField: "_id",
            as: "boatInfo",
          },
        },
        {
          $sort: {
            due_date: 1,
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_boatService",
      };
      return this.response;
    }

    this.response = {
      success: true,
      message: "boatServices found",
      data: boatServices,
    };
    return this.response;
  }
}

export default new BoatServices();
