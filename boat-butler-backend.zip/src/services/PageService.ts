import { ResponseObject } from "../Interfaces/commonInterfaces";
import { Pages } from "../models/pages";
class PageServices {
  private response: ResponseObject;

  async getAllQuestionnaire(slug: string) {
    // console.log("slug---", slug);
    // if (slug && slug.length > 0) {
    //   const result = await Pages.find({ slug: slug });
    //   this.response = {
    //     success: true,
    //     data: result,
    //     message: "Slug",
    //   };
    // }
    let condition = {
      is_faq: 1,
    };

    if (slug) {
      condition.is_faq = 0;
      condition["slug"] = slug;
      const result = await Pages.findOne(condition);
      this.response = {
        success: true,
        data: result,
        message: "pages_data_fetched_successfully",
      };
    } else {
      console.log("condition", condition);
      const result = await Pages.find(condition).sort({ created_ts: -1 });
      this.response = {
        success: true,
        data: result,
        message: "pages_data_fetched_successfully",
      };
    }
    return this.response;
  }
}

export default new PageServices();
