import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage } from "../utils/fileUpload";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import {
  ICommentInterface,
  IPostActivityData,
} from "../Interfaces/PostsInterface";
import { PostComments } from "../models/post_comments";
import { Post } from "../models/posts";
import { UserPostActivities } from "../models/user_post_activities";
import { ForumTopic } from "../models/forumtopics";

class PostsServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data) {
    let result;
    console.log("Post data", data);

    if (data) {
      try {
        result = await Post.create({ ...data, status: "Published" });
      } catch (err) {
        this.response = {
          success: false,
          message: "failed",
        };
        return this.response;
      }
      if (result) {
        this.response = {
          success: true,
          message: "Post_added_succsessfully",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "no_data",
      };
    }
    return this.response;
  }

  async likeCommunityPost(data: IPostActivityData) {
    let response;
    console.log("Post new------- data", data);
    let key = data.type;
    if (data.type === "like") {
      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          { $addToSet: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "comment") {
      try {
        response = await PostComments.findByIdAndUpdate(
          data._id,
          { $addToSet: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "bookmarks") {
      console.log("BookmarkPostPost data", data);
      let date = new Date();
      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          {
            $addToSet: {
              "total.bookmarks": { user_id: data.userId, date: date },
            },
          },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }

      // this.response = {
      //   success: true,
      //   message: "successfully_bookmarked",
      //   data: response,
      // };
    }

    this.response = {
      success: true,
      message: "successfully_liked",
      data: response,
    };

    return this.response;
  }
  async unlikeCommunityPost(data: IPostActivityData) {
    let response;
    console.log("Post data", data);
    if (data.type === "like") {
      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          { $pull: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "comment") {
      try {
        response = await PostComments.findByIdAndUpdate(
          data._id,
          { $pull: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "bookmarks") {
      console.log("BookmarkPostPost data", data);

      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          { $pull: { "total.bookmarks": { user_id: data.userId } } },
          { new: true, multi: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    }
    this.response = {
      success: true,
      message: "successfully_unliked",
      data: response,
    };

    return this.response;
  }

  async reported(data: IPostActivityData) {
    console.log("reported data", data);

    try {
      if (data.type === "flag") {
        const res = await PostComments.findByIdAndUpdate(data._id, {
          $set: {
            reported: {
              user_id: new ObjectId(data.userId),
              date: new Date(),
            },
            status: "Reported",
          },
        });

        console.log("res---", res);
      } else {
        await Post.findByIdAndUpdate(
          data._id,
          // {
          //   $set: {
          //     reported: {
          //       user_id: new ObjectId(data.userId),
          //       date: new Date(),
          //     },
          //     status: "Reported",
          //   },
          // },

          {
            $addToSet: {
              reported: {
                user_id: new ObjectId(data.userId),
                date: new Date(),
              },
            },
          },
          { new: true }
        );
      }
    } catch (error) {
      this.response = {
        success: false,
        message: "failed",
      };

      return this.response;
    }
    this.response = {
      success: true,
      message: "reported_successfully",
    };

    return this.response;
  }

  async getpostDetailById(_id: string) {
    console.log("getpostDetailById", _id);
    let res;
    try {
      // res = await Post.find({ _id : new ObjectId(_id)}).populate('user_id', '_id name')
      res = await Post.aggregate([
        {
          $match: {
            _id: new ObjectId(_id),
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "user_info",
          },
        },
        {
          $lookup: {
            from: "post_comments",
            localField: "_id",
            foreignField: "post_id",
            pipeline: [
              {
                $match: {
                  status: "Active",
                },
              },
              {
                $count: "total",
              },
            ],
            as: "post_comments",
          },
        },

        {
          $lookup: {
            from: "posts",
            let: { shared_post_id: "$shared_post_id" },
            pipeline: [
              { $match: { $expr: { $eq: ["$_id", "$$shared_post_id"] } } },
              {
                $lookup: {
                  from: "users",
                  let: { user_id: "$user_id" },
                  pipeline: [
                    { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
                  ],
                  as: "post_creator_detail",
                },
              },
            ],
            as: "shared_post_detail",
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_the_post",
      };
      return this.response;
    }

    if (res) {
      this.response = {
        success: true,
        message: "post_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "post_not_found",
      };
    }
    return this.response;
  }

  async postComment(data: ICommentInterface) {
    let result;
    if (data?.comment) {
      result = await PostComments.create({
        user_id: data?.user_id,
        post_id: data?.post_id,
        comment: data?.comment,
        status: data?.status,
      });
    } else {
      this.response = {
        success: true,
        data: "",
        message: "Empty comment",
      };
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "comment Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  async getComment(post_id: string) {
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await PostComments.aggregate([
        {
          $match: {
            post_id: new ObjectId(post_id),
            status: "Active",
          },
        },
        { $sort: { created_ts: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community_posts",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "community_posts_found",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "community_posts_not_found",
      };
    }

    return this.response;
  }

  async deleteCommentById(data: IPostActivityData) {
    console.log("data", data);
    const comment_id = data._id;
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await PostComments.deleteOne({ _id: comment_id });
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_comment",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "comment_deleted_successfully",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "comment_not_found",
      };
    }

    return this.response;
  }
  async deletePostById(data) {
    const post_id = data._id;
    const user_id = data.userId;
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await Post.deleteOne({ _id: post_id, user_id: user_id });
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_comment",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "comment_deleted_successfully",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "comment_not_found",
      };
    }
  }

  async getPostList(userId: string, offset: number) {
    let postResult;
    const formResult = await ForumTopic.find({
      user_id: { $all: [userId] },
      is_active: { $ne: false },
    });
    const forumIdList = formResult.map((forum) => forum.id);
    console.log("forumIdList --------- ", forumIdList);
    console.log("offset --------- ", offset);
    let skip = isNaN(+offset) ? 0 : offset;

    postResult = await Post.aggregate([
      {
        $match: {
          status: "Published",
          type_item_id: { $in: forumIdList },

          // reported: {
          //   $elemMatch: { user_id: { $ne: userId } },
          // },
        },
      },
      { $sort: { created_ts: -1 } },

      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $lookup: {
          from: "post_comments",
          localField: "_id",
          foreignField: "post_id",
          pipeline: [
            {
              $match: {
                status: "Active",
              },
            },
            {
              $count: "total",
            },
          ],
          as: "post_comments",
        },
      },
      {
        $lookup: {
          from: "posts",
          let: { shared_post_id: "$shared_post_id" },
          pipeline: [
            { $match: { $expr: { $eq: ["$_id", "$$shared_post_id"] } } },
            {
              $lookup: {
                from: "users",
                let: { user_id: "$user_id" },
                pipeline: [
                  { $match: { $expr: { $eq: ["$_id", "$$user_id"] } } },
                ],
                as: "post_creator_detail",
              },
            },
          ],
          as: "shared_post_detail",
        },
      },

      { $skip: skip },
      { $limit: 10 },
    ]);
    if (postResult) {
      this.response = {
        success: true,
        message: "success",
        data: postResult,
      };
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }
  async getSavedPostList(userId: string, offset: number, query: string) {
    let result;
    let matchObject;
    console.log("getSavedPostList Api-----------", query);
    {
      query && query.length > 0
        ? (matchObject = {
            $or: [
              { title: { $regex: query, $options: "i" } },
              { description: { $regex: query, $options: "i" } },
            ],
          })
        : (matchObject = {});
    }

    let skip = isNaN(+offset) ? 0 : offset;

    result = await Post.aggregate([
      {
        $match: {
          "total.bookmarks.user_id": userId,
        },
      },

      {
        $match: matchObject,
      },

      {
        $lookup: {
          from: "post_comments",
          localField: "_id",
          foreignField: "post_id",
          pipeline: [
            {
              $match: {
                status: "Active",
              },
            },
            {
              $count: "total",
            },
          ],
          as: "post_comments",
        },
      },
      { $sort: { "total.bookmarks.date": -1 } },
      { $skip: skip },
      { $limit: 5 },
    ]);
    if (result) {
      this.response = {
        success: true,
        message: "success",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "failed",
      };
    }
    return this.response;
  }
}

export default new PostsServices();
