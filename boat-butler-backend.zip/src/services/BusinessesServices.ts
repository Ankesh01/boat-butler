import { ResponseObject } from "../Interfaces/commonInterfaces";
import { Businesses } from "../models/businesses";
import { Request, Response } from "express";
import axios from "axios";
import { ObjectId } from "mongodb";
// const request = require("request");
interface IBusinessesService {
  owner_name: string;
  business_name: string;
  registration_number: string;
  contact_number: string;
  email: string;
  location: Object;
  business_hours: Object;
  business_days: string[];
  services: string;
  photos: [];
  status: string;
}
interface ICoordinates {
  lat: string;
  lng: string;
}

class BusinessesServices {
  private response: ResponseObject;

  async getServiceProvidersList(data: ICoordinates) {
    console.log("Location--Coordinates", data);

    let res;
    try {
      // res = await Businesses.find();

      res = await Businesses.aggregate([
        {
          $geoNear: {
            near: {
              type: "Point",
              coordinates: [parseFloat(data.lng), parseFloat(data.lat)],
            },
            spherical: false,
            key: "location.coordinates",
            distanceField: "distance",
            distanceMultiplier: 0.001,
            maxDistance: 900000000, //in meters
          },
        },
        { $limit: 12 },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_business_service_provider",
      };

      return this.response;
    }
    if (res) {
      console.log("ServiceProviders Response", res);
      this.response = {
        success: true,
        message: "service_provider_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "service_provider_not_found",
      };
    }

    return this.response;
  }

  async getServiceProviderById(service_id: string) {
    let res;
    console.log("service_id", service_id);
    try {
      res = await Businesses.findOne({ _id: service_id });
      console.log("Businesses Response====", res);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_service",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "service_provider_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "service_provider_not_found",
      };
    }

    return this.response;
  }
  async create(body: IBusinessesService) {
    console.log("create--------------?", body);

    const result = await Businesses.create({
      owner_name: body?.owner_name,
      business_name: body?.business_name,
      registration_number: body?.registration_number,
      contact_number: body?.contact_number,
      email: body?.email,
      location: body?.location,
      business_hours: body?.business_hours,
      business_days: body?.business_days,
      photos: body?.photos,
    });
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "Business Directory Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  async update(body: IBusinessesService, _id: string) {
    console.log("update--------------?", body);
    let result;
    try {
      result = await Businesses.updateMany(
        {
          _id: _id,
        },
        { $set: body }
      );

      console.log("updated field ", result);
    } catch (err) {
      this.response = {
        success: false,
        message: "updation_failed",
      };
    }

    if (result) {
      this.response = {
        success: true,
        message: "business_directory_updated_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  async getGooglePlaceDetail(placeId) {
    let res;
    res = await axios({
      method: "get",
      url: `https://maps.googleapis.com/maps/api/place/details/json?placeid=${placeId}&key=AIzaSyBn6w23qRD7HXgmen3WC-nOT4HSdrbzvq8`,
    });
    console.log(
      "GooglePlacesAPI result---",
      res.data.result.address_components
    );
    console.log("Api-----", res.data.result.geometry.location);
    this.response = {
      success: true,
      message: "success",
      data: res.data.result.geometry.location,
    };

    return this.response;

    // return this.getServiceProvidersList(res.data.result.geometry.location);
  }
}

export default new BusinessesServices();
