import { ResponseObject } from "../Interfaces/commonInterfaces";
import { Reminders } from "../models/reminders";
import { UserNotifications } from "../models/userNotifications";
import moment from "moment";
import Helper from "../utils/helper";

interface IBodyReminder {
  userId: number;
  reminder: IReminder;
  timezone: string;
}

interface IReminder {
  title: string;
  notes: string;
  date: Date;
  start_time: Date;
  end_time: Date;
  repeat: number;
  priority: string;
  due_start_datetime: string;
  due_end_datetime: string;
}

interface IReminderNotification {
  reminder_id: string;
  send_status: number;
  status: string;
}

class ReminderServices {
  private response: ResponseObject;

  async create(body: IBodyReminder) {
    console.log("Create reminder Body", body);
    let dateTime = new Date(body?.reminder.due_start_datetime);
    let EndDateTime = new Date(body?.reminder.due_end_datetime);
    const result = await Reminders.create({
      user_id: body?.userId,
      title: body?.reminder.title,
      notes: body?.reminder.notes,
      due_start_datetime: body?.reminder.due_start_datetime,
      due_end_datetime: body?.reminder.due_end_datetime,
      repeat: body?.reminder.repeat,
      priority: body?.reminder.priority,
      status: "Pending",
      timezone: body.timezone,
    });
    const repeatIntervals = body?.reminder.repeat * 60000;

    let allSlots = [];

    while (dateTime.getTime() < EndDateTime.getTime()) {
      allSlots.push(moment(dateTime).format("MM-DD-YYYY HH:mm"));

      dateTime.setTime(dateTime.getTime() + repeatIntervals);
      if (dateTime.getTime() > EndDateTime.getTime()) {
        break;
      }
    }
    allSlots = allSlots.map((i: string) => new Date(i));

    const insertData = allSlots.map((d: Date) => ({
      user_id: body?.userId,
      type: "reminders",
      type_item_id: result.id,
      message: {
        title: body?.reminder.title,
        body: body?.reminder.notes,
        data: `/edit-reminder/${result.id}`,
      },
      send_status: 0,
      due_date: d,
    }));
    await UserNotifications.insertMany(insertData);
    this.response = {
      success: true,
      data: result,
      message: "New Reminder Added Successfully!",
    };
    return this.response;
  }

  async getReminderServicesbyUserId(user_id: string) {
    let res;
    try {
      res = await Reminders.find({ user_id: user_id }).sort({ created_ts: -1 });

      /*res = res.map((data) => {
        if (data.timezone) {
          data.due_start_datetime = Helper.convertTZ(
            data.due_start_datetime,
            data.timezone
          );
          data.due_end_datetime = Helper.convertTZ(
            data.due_end_datetime,
            data.timezone
          );
        }
        return data;
      });*/
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_reminder",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "Reminder_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "reminder_not_found",
      };
    }

    return this.response;
  }

  async deleteReminderById(_id: string[]) {
    let response;
    try {
      response = await Reminders.deleteMany({ _id: _id });
      if (response) {
        this.response = {
          success: true,
          message: "reminder_deleted",
        };
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_delete_reminder",
      };
    }

    return this.response;
  }

  async updateRemindersNotification(data: IReminderNotification) {
    let reminder_id = data.reminder_id as string;
    let send_status = data.send_status;

    let res;
    try {
      // res = await UserNotifications.findOne({
      //   type: "reminders",
      //   type_item_id: reminders_id,
      // });
      const updateResult = await UserNotifications.updateMany(
        {
          type_item_id: reminder_id,
          type: "reminders",
        },
        {
          $set: {
            send_status: send_status,
          },
        }
      );
      await Reminders.updateMany(
        { _id: reminder_id },
        { $set: { status: data.status } }
      );
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_reminder",
      };

      return this.response;
    }

    this.response = {
      success: true,
      message: "Updated_Successfully",
      data: res,
    };

    // else {
    //   this.response = {
    //     success: false,
    //     message: "reminder_not_found",
    //   };
    // }
    //  await Reminders.updateOne(
    //    {_id: rem_id },
    //    { $set: { status: "Completed" } }
    //  );
    return this.response;
  }
}

export default new ReminderServices();
