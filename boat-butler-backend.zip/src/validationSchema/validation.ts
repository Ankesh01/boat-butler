import { Request, Response, NextFunction } from "express";
import { body, validationResult } from "express-validator";

export const loginValidation = [
  body("email")
    .exists()
    .withMessage("Email is required.")
    .not()
    .isEmpty()
    .withMessage("Email field cannot be empty.")
    .isEmail()
    .withMessage("Email format is not valid."),
  body("password")
    .exists()
    .withMessage("password is required.")
    .not()
    .isEmpty()
    .withMessage("password field cannot be empty.")
    .matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/,
      "i"
    )
    .withMessage(
      "Password should be combination of one uppercase, one lower case, one special char, one digit and min 8 char long."
    ),
  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      email: [],
      password: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];

export const forgotPasswordValidation = [
  body("email")
    .exists()
    .withMessage("Email is required.")
    .not()
    .isEmpty()
    .withMessage("Email field cannot be empty.")
    .isEmail()
    .withMessage("Email format is not valid."),
  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      email: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];

export const signUpValidation = [
  body("name")
    .exists()
    .withMessage("Name is required.")
    .not()
    .isEmpty()
    .withMessage("Name field cannot be empty.")
    .isLength({ min: 1, max: 25 })
    .withMessage("Name should be at least 1 character but not more than 25."),
  body("email")
    .exists()
    .withMessage("Email is required.")
    .not()
    .isEmpty()
    .withMessage("Email field cannot be empty.")
    .isEmail()
    .withMessage("Email format is not valid."),
  // body("ssn")
  //   .exists()
  //   .withMessage("ssn is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("ssn field cannot be empty."),
  // body("branch")
  //   .exists()
  //   .withMessage("branch is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("Branch field cannot be empty."),
  // body("website")
  //   .exists()
  //   .withMessage("website is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("website field cannot be empty."),
  // body("clientType")
  //   .exists()
  //   .withMessage("clientType is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("clientType field cannot be empty."),
  body("password")
    .exists()
    .withMessage("password is required.")
    .not()
    .isEmpty()
    .withMessage("password field cannot be empty.")
    .matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/,
      "i"
    )
    .withMessage(
      "Password should be combination of one uppercase , one lower case, one special char, one digit and min 8 char long."
    ),

  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      name: [],
      email: [],
      // addressLine1: [],
      // city: [],
      // state: [],
      // zip: [],
      // country: [],
      // clientType: [], for provider
      // website: [], for provider
      // phone: [], for member
      // ssn: [], for member
      // branch: [],  for member
      password: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation---------- Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];
export const profileValidation = [
  body("name")
    .exists()
    .withMessage("Name is required.")
    .not()
    .isEmpty()
    .withMessage("Name field cannot be empty.")
    .isLength({ min: 1, max: 50 })
    .withMessage("Name should be at least 1 character but not more than 50."),
  body("email")
    .exists()
    .withMessage("Email is required.")
    .not()
    .isEmpty()
    .withMessage("Email field cannot be empty.")
    .isEmail()
    .withMessage("Email format is not valid."),
  body("phone")
    .exists()
    .withMessage("Phone Number is Required.")
    .not()
    .isEmpty()
    .withMessage("Phone Number Cannot be Empty.")
    .isLength({ min: 10, max: 10 })
    .matches(
      /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
      "i"
    )
    .withMessage("Phone Number Should be Correct."),
  body("address_line_1")
    .exists()
    .withMessage("Address is required.")
    .not()
    .isEmpty()
    .withMessage("Address field cannot be empty.")
    .isLength({ min: 1, max: 150 })
    .withMessage(
      "Address should be at least 1 character but not more than 150."
    ),
  body("state")
    .exists()
    .withMessage("State is required.")
    .not()
    .isEmpty()
    .withMessage("State field cannot be empty."),
  body("zipcode")
    .exists()
    .withMessage("Zipcode is Required.")
    .not()
    .isEmpty()
    .withMessage("Zpicode Cannot be Empty.")
    .isLength({ min: 5, max: 6 })
    .withMessage("Zipcode Should be Correct."),

  // body("ssn")
  //   .exists()
  //   .withMessage("ssn is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("ssn field cannot be empty."),
  // body("branch")
  //   .exists()
  //   .withMessage("branch is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("Branch field cannot be empty."),
  // body("website")
  //   .exists()
  //   .withMessage("website is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("website field cannot be empty."),
  // body("clientType")
  //   .exists()
  //   .withMessage("clientType is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("clientType field cannot be empty."),
  // body("password")
  //   .exists()
  //   .withMessage("password is required.")
  //   .not()
  //   .isEmpty()
  //   .withMessage("password field cannot be empty.")
  //   .matches(
  //     /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/,
  //     "i"
  //   )
  //   .withMessage(
  //     "Password should be combination of one uppercase , one lower case, one special char, one digit and min 8 char long."
  //   ),

  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      name: [],
      email: [],
      phone: [],
      gender: [],
      address_line_1: [],
      address_line_2: [],
      // city: [],
      state: [],
      zipcode: [],
      country: [],
      // clientType: [], for provider
      // website: [], for provider
      // phone: [], for member
      // ssn: [], for member
      // branch: [],  for member
      // password: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation---------- Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];
export const resetPasswordValidation = [
  body("email")
    .exists()
    .withMessage("Email is required.")
    .not()
    .isEmpty()
    .withMessage("Email field cannot be empty.")
    .isEmail()
    .withMessage("Email format is not valid."),
  body("password")
    .exists()
    .withMessage("password is required.")
    .not()
    .isEmpty()
    .withMessage("password field cannot be empty.")
    .matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/,
      "i"
    )
    .withMessage(
      "Password should be combination of one uppercase , one lower case, one special char, one digit and min 8 char long."
    ),
  body("confirmPassword")
    .exists()
    .withMessage("Confirm Password is required.")
    .not()
    .isEmpty()
    .withMessage("Confirm Password field cannot be empty.")
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error("Password does not match.");
      }
      return true;
    }),
  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      email: [],
      password: [],
      confirmPassword: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];

export const changePasswordValidation = [
  body("password")
    .exists()
    .withMessage("password is required.")
    .not()
    .isEmpty()
    .withMessage("password field cannot be empty."),
  body("newPassword")
    .exists()
    .withMessage("New Password is required.")
    .not()
    .isEmpty()
    .withMessage("New Password field cannot be empty.")
    .matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,16}$/,
      "i"
    )
    .withMessage(
      "Password should be combination of one uppercase , one lower case, one special char, one digit and min 8 char long."
    ),

  body("confirmNewPassword")
    .exists()
    .withMessage("Confirm Password is required.")
    .not()
    .isEmpty()
    .withMessage("Confirm Password field cannot be empty.")
    .custom((value, { req }) => {
      if (value !== req.body.newPassword) {
        throw new Error("Password does not match.");
      }
      return true;
    }),
  (req: Request, res: Response, next: NextFunction) => {
    const errors: any = validationResult(req);
    const error: any = {
      password: [],
      newPassword: [],
      confirmNewPassword: [],
    };
    if (errors.isEmpty() === false) {
      errors.array().forEach((e: any) => {
        error[e.param]?.push(e.msg);
      });

      const send_data = {
        error: "Input validation Error",
        errorData: error,
      };
      return res.status(400).json(send_data);
    } else {
      next();
    }
  },
];
