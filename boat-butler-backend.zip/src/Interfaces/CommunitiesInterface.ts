export interface ICommunitiesData {
  _id: string;
  title: string;
  description: string;
  user_id?: string;
  image?: any;
  oldImage?: string;
  type?: string;
}

export interface IPhotoInterface {
  data: string;
  format: string;
}
