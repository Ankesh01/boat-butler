export interface IPostActivityData {
  _id: string;
  userId: string;
  user_id?: string;
  type?: string;
}

export interface ICommentInterface {
  user_id: string;
  comment?: string;
  post_id?: string;
  status?: string;

  _id?: string;
}
