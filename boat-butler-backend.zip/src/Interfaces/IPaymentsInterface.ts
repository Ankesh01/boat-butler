export interface IPaymentsInterface {
  user_id: string;
  product: IAPProduct;
  end_date?:string;
}
export interface IAPProduct {
  id: string; //plan_id
  alias?: string;
  type: string;
  state: string;
  title: string;
  description: string;
  priceMicros: number;
  price: string;
  currency: string;
  loaded: boolean;
  valid: boolean;
  canPurchase: boolean;
  owned: boolean;
  downloading?: boolean;
  downloaded?: boolean;
  lastRenewalDate?: Date;
  expiryDate?: Date;
  introPrice?: string;
  introPriceMicros?: number;
  introPriceNumberOfPeriods?: number;
  introPriceSubscriptionPeriod?: string;
  introPricePaymentMode?: string;
  ineligibleForIntroPrice?: boolean;
  billingPeriod?: number;
  billingPeriodUnit?: string;
  trialPeriod?: number;
  trialPeriodUnit?: string;
  additionalData?: any;
  transaction?: PlayStoreReceipt | AppStoreReceipt;
  finish(): void;
  verify(): any;
  set(key: string, value: any): void;
  stateChanged(): void;
  on(event: string, callback: Function): void;
  once(event: string, callback: Function): void;
  off(callback: Function): void;
  trigger(action: string, args: any): void;
}
export interface PlayStoreReceipt {
  id: string;
  purchaseState: number;
  purchaseToken: string;
  receipt: string;
  signature: string;
  type: "android-playstore";
}
export interface AppStoreReceipt {
  id: string;
  appStoreReceipt: string;
  original_transaction_id: string;
  type: "ios-appstore";
}
