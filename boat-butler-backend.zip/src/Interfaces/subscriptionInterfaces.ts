export interface SubscriptionSchema {
    title: string;
    price: number;
    benefits: Object;
    slug: string;
  }