export interface CommunityMemberSchema {
    community_id: string;
    status: string;
    user_id: string;
    
  }
  