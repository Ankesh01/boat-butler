import { Method } from "axios";

export declare type Resolve = (value: string | PromiseLike<string>) => void;
export declare type Reject = (reason?: any) => void;

export declare interface ResponseObject {
  success: boolean;
  message: string;
  data?: unknown;
  type?: string;
  user?: any;
  isFound?: any;
  error?: string;
  paymentStatus?: string;
  isLoggedIn?: boolean;
}

export interface envData {
  env: string;
  port: number;
  apiUrl: string;
  jwtSecret: string;
  siteUrl: string;
  crypto_key: string;
  mongoUri: string;
  bucket: string;
  google_api_key: string;
  region: string;
}

export interface DataFromHeader {
  id?: string;
  token?: string;
}

export interface GoogleAPIParams {
  url: string;
  method: Method;
  params: any;
}
