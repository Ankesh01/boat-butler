export interface PagesSchema {
  title: string;
  slug: string;
  content: string;
  isFAQ: boolean;
  status: boolean;
}
