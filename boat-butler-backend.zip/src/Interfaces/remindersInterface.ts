export interface ReminderSchema {
  user_id: String;
  title: String;
  notes: String;
  due_start_datetime: Date;
  due_end_datetime: Date;
  repeat: Number;
  status: String;
  priority: string[];
}
