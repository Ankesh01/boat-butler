import { Schema } from "mongoose";
import { Interface } from "readline";

export interface UserSchema {
  account_type?: string;
  name: string;
  phone?: number;
  email?: string;
  password?: string;
  gender: string;
  address: {
    address_line_1: string;
    address_line_2?: string;
    city: string;
    state: string;
    zip: number;
    country: string;
  };
  image?: string;
  timezone?: string;
  reported_at?: Date;
  reported_by?: Object;
  encOtp?: string;
  is_active?: number;
  is_verified?: number;
  status?: string;
}
export interface EnginesSchema {
  make: string;
  model: string;
  hp?: number;
  dry_weight?: number;
  start_type?: string;
  tilt_trim?: string;
  fuel_type?: string;
  year?: number;
  strock_series?: string;
  maintenance_settings?: IMaintenance;
}

export interface IMaintenance {
  interval: { string: number };
}
export interface IEngine {
  number_of_engines?: number;
  make?: string;
  model?: string;
  hours?: number;
  year?: number;
  serial_number?: string;
  manuals?: [];
  photos?: [];
}

export interface BoatSchema {
  _id?: string;
  user_id?: Schema.Types.ObjectId;
  title?: string;
  date_of_bought: Date;
  seller_phone: string;
  registration_id: string;
  vin: string;
  make: string;
  model: string;
  year_of_hull: number;
  engine?: IEngine;
  other_equipments?: string[];
  photos?: [];
}

export interface BoatServiceSchema {
  user_id?: Schema.Types.ObjectId;
  boat_id?: Schema.Types.ObjectId;
  due_date: Date;
  items: { name: string; status: string }[];
  status: string[];
  completion_date: Date;
  receipts?: [];
}
export interface ProviderSchema {
  user_id?: Schema.Types.ObjectId;
  client_type?: string;
  website: string;
  industry: string;
  phone: string;
  description: string;
  established_in: string;
  registration_number: string;
  business_registration_number: string;
  questionnaires?: IQuestionnaires;
}

export interface PaymentSchema {
  user_id?: Schema.Types.ObjectId;
  subscription_id?: string;
  plan_id?: Schema.Types.ObjectId;
  transaction_id?: string;
  transaction_date?: Date;
  amount: Number;
  model?: string;
  status?: string[];
}

export interface IExhibitCForm {
  name: string;
  clientNumber: string;
  clientType: string;
  companyAddress: string;
  city: string;
  state: string;
  zip: number;
  contactNumber: number;
  industry: string;
  website: string;
  apContact: string;
  billingEmail: string;
  phone: string;
  billingAddress: string;
  billingCity: string;
  billingState: string;
  billingZip: number;
  bankReference: string;
  yearsInBusiness: number;
  invoiceBy: string;
  department: string;
  purchaseOrder: string;
  workSite: string;
  costCenter: string;
  timecardsAttached: boolean;
  invoiceRecipient: string;
  insuranceFile: string;
  hiringRequirements: {
    ppe?: boolean;
    finance?: boolean;
    testing?: boolean;
    bgChecks?: boolean;
    special?: boolean;
  };
  specialValues: string[];
  message: string;
  status: string;
}

export interface IUserNotificationSchema {
  _id?: Schema.Types.ObjectId;
  user_id: Schema.Types.ObjectId;
  type: string;
  type_item_id: string;
  message: any;
  read_status: number;
}

export interface ICommunicationTemplates {
  _id?: Schema.Types.ObjectId;
  provider_id: Schema.Types.ObjectId;
  title: string;
  description: string;
}
export interface Location {
  worksiteLocation?: string;
  nameOfLocation?: string;
  po?: number;
  timeZone?: number;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: number;
}
export interface IQuestionnaires {
  id: Schema.Types.ObjectId;
  selectIesOffice?: string;
  locations?: Location[];
  whatIndustriesWfmBelong?: any;
  distanceWfmPunchForShift?: string;
  afterMinutesWfmConsideredLate?: number;
  oftenYouPayEmployee?: number;
  lastDayOfWorkWeek?: string;
  daysYouProvideHolidayPay?: string;
  earliestTimeWfmCanPunch?: number;
}

export interface PostSchema {
  post_category_id?: string;
  user_id?: string;
  title?: string;
  description?: string;
  media_file?: Object;
  status?: string;
  total?: Object;
  community_id?: string;
  reported?: Object;
}
export interface PostCategoriesSchema {
  title?: string;
  is_active: Number;
}
export interface PostCommentSchema {
  user_id?: string;
  comment: string;
  post_id?: string;
  status?: string;
  total?: Object;
}

export interface CommunitiesSchema {
  user_id?: string;
  title?: string;
  description?: string;
  status?: string;
  reported?: Object;
}

export interface ForumSchema {
  user_id?: string;
  title?: string;
  description?: string;
  status?: string;
}

export interface UserPostActivitiesSchema {
  user_id?: string;
  saved_post_ids?: string;
  shared_post_ids?: string;
  replied_post_ids?: string;
  liked_post_ids?: string;
}

export interface ForumMainSchema {
  user_id?: string;
  saved_post_ids?: number[];
  shared_post_ids?: number[];
  replied_post_ids?: number[];
  liked_post_ids?: number[];
}

export interface ForumTopicSchema {
  id?: string;
  title: string;
  is_active: number;
  user_id: string[];
}
// export interface IOffices {
//   address: {
//     zip: string;
//     address_line1: string;
//     address_line2: string;
//   };
//   loc: {
//     coordinate: Array<number>;
//   };
//   name: {
//     type: string;
//   };
// }
