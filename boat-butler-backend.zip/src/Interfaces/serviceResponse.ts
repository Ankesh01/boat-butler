export interface Iresetpassword {
  success: boolean;
  message: string;
}

export interface Iforgetpassword {
  success: boolean;
  message: string;
  data?: string;
}

export interface IotpVerification {
  success: boolean;
  message: string;
}
