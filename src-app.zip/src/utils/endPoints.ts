import Reminders from "../pages/reminders/Reminders";
import Profile from "../pages/profile/Profile";

export const endpoint = {
  user: {
    login: "/api/v1/auth/login",
    signup: "/api/v1/auth/signup",
    password_reset: "/api/v1/auth/password-reset",
    verification: "/api/v1/auth/otp-verification",
    change_password: "/api/v1/auth/change-password",
    sociallogin: "/api/v1/auth/social-login",
    profile: "/api/v1/auth/profile",
    getUser: "/api/v1/auth/get-user",
    deleteUser: "/api/v1/auth",
    clearToken: "/api/v1/auth/:userId/clear-token",
    // reset_pass: "/api/v1/auth/password-reset",
  },

  Boat: {
    add: "/api/v1/boat/create",
    getEngineMake: "/api/v1/boat/get-engine-make",
    getEngineModel: "/api/v1/boat/get-engine-make",
    // getList: "/api/v1/boat/search",
    getBoatList: "/api/v1/boat/get-boat-list",
    getBoat: "/api/v1/boat/get-boat",
    getBoatServices: "/api/v1/boat/get-boat-services",
    editBoat: "/api/v1/boat/edit-boat",
  },

  BoatServices: {
    create: "/api/v1/boat-services/create",
    update: "/api/v1/boat-services/:serviceId/update",
    getAll: "/api/v1/boat-services/get-all",
    get: "/api/v1/boat-services",
  },

  Pages: {
    get_all: "/api/v1/pages/get-all",
  },

  Files: {
    get: "/api/v1/files/presignedurl",
    delete: "/api/v1/files/delete",
  },
  ProfileInner: {
    change_password: "/api/v1/profile-inner/change-password",
  },
  Reminders: {
    add: "/api/v1/reminders/add",
    getAllReminder: "/api/v1/reminders/get-reminder",
    deleteReminder: "/api/v1/reminders/delete",
    ReminderNotification: "/api/v1/reminders/notification/update",
  },
  BusinessDirectory: {
    get_service: "/api/v1/businesses/get-list",
    get_servicebyId: "/api/v1/businesses",
  },

  Forum: {
    getForum: "/api/v1/forum/get-all",
    // getBoatServices: "/api/v1/boat/get-boat-services",
    addForum: "/api/v1/boat/edit-boat",
  },
  Community: {
    create: "/api/v1/communities/create",
    get: "/api/v1/communities",
    getposts: "/api/v1/communities/posts",
    // getBoatServices: "/api/v1/boat/get-boat-services",
    // editBoat: "/api/v1/boat/edit-boat",
  },
  Post: {
    create: "/api/v1/posts/create",
    like_community: "/api/v1/posts/like-community",
    unlike_community: "/api/v1/posts/unlike-community",
    detail: "/api/v1/posts/post-detail",
    postcomment: "/api/v1/posts/post-comment",
    getcomment: "/api/v1/posts/get-comment",
  },
};
