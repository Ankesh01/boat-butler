import { Camera, CameraResultType } from "@capacitor/camera";
import imageCompression from "browser-image-compression";
import {
  getSignedUrl,
  pushFileToS3,
} from "../redux/action-creators/FileUpload";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
// import { File } from "@ionic-native/file";


const blobToBase64 = (blob: Blob) => {
  return new Promise((resolve, _) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.readAsDataURL(blob);
  });
};

const blobToFile = (blob: Blob) => {
  return new File([blob], `${Date.now()}`, {
    type: blob.type,
  });
};

export const base64ToFile = (base64String: string, fileName: string) => {
  let arr: any = base64String.split(","),
    mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]),
    n = bstr.length,
    u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], fileName, { type: mime });
};

export const getPicture = async (
  capture_type: string,
  return_type: string,
  limit: number = 5
) => {
  try {
    if (capture_type === "single") {
      const image: any = await Camera.getPhoto({
        quality: 50,
        resultType: CameraResultType.DataUrl,
      });
      console.log("image ---- ", { ...image });
      const options = {
        maxSizeMB: 3,
        maxWidthOrHeight: 1920,
        useWebWorker: true,
      };
      const compressedImage = await imageCompression(
        // base64ToFile(image.dataUrl, `${Date.now()}.${image.format}`),
        await imageCompression.getFilefromDataUrl(
          image.dataUrl,
          `${Date.now()}.${image.format}`
        ),
        options
      );
      return {
        data: await imageCompression.getDataUrlFromFile(compressedImage),
        format: image.format,
      };
      /*if (image.dataUrl) {
        if (return_type === "base64") {
          return image;
        } else if (return_type === "file") {
          return base64ToFile(image.dataUrl, `${Date.now()}.${image.format}`);
        }
      } else {
        return false;
      }*/
    } else if (capture_type === "multiple") {
      const { photos }: any = await Camera.pickImages({
        quality: 50,
        correctOrientation: true,
        presentationStyle: "popover",
        limit,
      });
      console.log("photos ---- ", photos);
      let imageArray: any[] = [];
      if (return_type === "base64") {
        for (const photo of photos) {
          let blob: Blob = await fetch(photo.webPath).then((r) => r.blob());
          let base64 = await blobToBase64(blob);
          imageArray.push({ data: base64, format: photo.format });
        }
      } else if (return_type === "file") {
        for (const photo of photos) {
          let blob: Blob = await fetch(photo.webPath).then((r) => r.blob());
          let file: File = blobToFile(blob);
          imageArray.push(file);
        }
      }
      return imageArray;
    }
  } catch (error) {
    console.error("Error while processing image", error);
  }
};

const formatTimestamp = (timestamp: string | number | Date) => {
  if (!timestamp) {
    return "-";
  }
  const date = new Date(timestamp);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};

export const formatDBTimestamp = (timestamp: string) => {
  const date = new Date(timestamp);
  return date.toISOString().split("T")[0];
};

const getDaysDifferenceFromToday = (fromDate: Date) => {
  const date1 = new Date(fromDate);
  const milliSec = Math.abs(date1.getTime() - Date.now());
  return Math.floor(milliSec / (24 * 60 * 60 * 1000));
};

const calculateProgress = (fromDate: Date) => {
  const date1 = new Date(fromDate);
  const milliSec = Math.abs(date1.getTime() - Date.now());
  const days = Math.floor(milliSec / (24 * 60 * 60 * 1000));
  return days / 30;
};

const newDateWithoutTime = () => {
  const date = new Date();
  date.setHours(0);
  date.setMinutes(0);
  date.setSeconds(0);
  date.setMilliseconds(0);
  return date;
};

const formatDate = (date: string | Date) => {
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-");
};



const uploadFileOnS3 = async (files: File[], filePath: string) => {
  let body: { filePath: string; fileFormat: string }[] = [];
  for (let file of files) {
    body.push({
      filePath: `${filePath}/${file.name}`,
      fileFormat: file.type.split("/")[1] as string,
    });
  }
  let signedUrlList: string[] = [];
  const resp = await getSignedUrl(body);
  if (resp?.data?.data) {
    let index = 0;
    for (let signUrl of resp?.data?.data) {
      const file = files[index];
      const response = await pushFileToS3(signUrl, file);
      if (response?.url) {
        signedUrlList.push(response?.url.split("?Content")?.[0]);
      }
    }
  }
  return signedUrlList;
};

const downloadFile = async (url: string) => {
  // const {File} = require("@ionic-native/file")
  let fileNameArray = url.split("/");
  let fileName = fileNameArray[fileNameArray.length - 1];
  const response = await fetch(url);
  // convert to a Blob
  const blob = await response.blob();
  // convert to base64 data, which the Filesystem plugin requires
  const base64Data = (await convertBlobToBase64(blob)) as string;
  console.log("fileName --------- ", fileName);
  // const directory = File.externalRootDirectory + "Download/";
  // const savedFile = File.writeFile(directory, fileName, blob);
  const savedFile = await Filesystem.writeFile({
    path: fileName,
    data: base64Data,
    directory: Directory.External,
    recursive: true,
  });
  return savedFile.uri;
  console.log("savedFile --------- ", savedFile);
};

const convertBlobToBase64 = (blob: Blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      resolve(reader.result);
    };
    reader.readAsDataURL(blob);
  });

export {
  formatTimestamp,
  getDaysDifferenceFromToday,
  calculateProgress,
  newDateWithoutTime,
  formatDate,
  uploadFileOnS3,
  downloadFile,
};
