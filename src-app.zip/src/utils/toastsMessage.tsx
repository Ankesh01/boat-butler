import { useIonToast  ,IonToast} from "@ionic/react";
import React, { useState } from 'react';

// const [present, dismiss] = useIonToast();

  
  export const success = (message: string) => {
   console.log(message);
    // present({  
    //   buttons: [{ text: 'hide', handler: () => dismiss() }],
    //   message: message,
    //   position:"middle",
    //   onDidDismiss: () => console.log('dismissed'),
    //   onWillDismiss: () => console.log('will dismiss'),
    // });
  };

 

  export const error = (message: string) => {
    // const [present, dismiss] = useIonToast();
    // present({
    //   buttons: [{ text: 'hide', handler: () => dismiss() }],
    //   message: 'toast from hook, click hide to dismiss',
    //   onDidDismiss: () => console.log('dismissed'),
    //   onWillDismiss: () => console.log('will dismiss'),
    // });
  //  cogoToast.error(message, options);
  };
