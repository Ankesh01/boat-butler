// const {File} = require("@ionic-native/file")

export const downloadFile = async (url: string) => {
    let fileNameArray = url.split("/");
  //   let fileName = fileNameArray[fileNameArray.length - 1];
  //   const response = await fetch(url);
  //   // convert to a Blob
  //   const blob = await response.blob();
  //   // convert to base64 data, which the Filesystem plugin requires
  //   // const base64Data = (await convertBlobToBase64(blob)) as string;
  //   console.log("fileName --------- ", fileName);
  //   const directory = File.externalRootDirectory + "Download/";
  //   const savedFile = File.writeFile(directory, fileName, blob);/*
  // const savedFile = await File.writeFile({
  //   path: fileName,
  //   data: base64Data,
  //   directory: Directory.Data,
  //   recursive : true
  // });*/
  //   console.log("savedFile --------- ", savedFile);
};