
import { Storage } from '@capacitor/storage';

const ACCESS_TOKEN_KEY = "__ATK__";

export const getAccessToken = async () => {
    const { value } = await Storage.get({ key : ACCESS_TOKEN_KEY }).then( (token)=> token);
    return value as string
}

export const setAccessToken = (accessToken: string) =>
    Storage.set({
        key: ACCESS_TOKEN_KEY,
        value: accessToken,
    });

