import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const postCommentAction = (data: any): any => {
//   console.log("createPostAction", data);

  return http.post(`${endpoint.Post.postcomment}`, data);
};

export const getCommentAction = (data: any): any => {
    console.log("createPostAction", data);
  
    return http.get(`${endpoint.Post.getcomment}/${data.post_id}`);
  };





