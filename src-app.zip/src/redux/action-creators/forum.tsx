import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const getForumListAction = (): Promise<ApiResponse> => {
  return http.get(endpoint.Forum.getForum);
};

export const getForumByIdAction = (ForumId: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Forum.getForum}/${ForumId}`);
};

export const addNewForumAction = (user_id: any): Promise<ApiResponse> => {
  console.log("user_id", user_id);

  return http.post(`${endpoint.Forum.addForum}`, user_id);
};

// export const getEngineModelListAction = (): Promise<ApiResponse> => {
//   return http.get(endpoint.Forum.getEngineMake);
// };
