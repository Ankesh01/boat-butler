import { Dispatch } from "react";
import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { ActionType } from "../action-types";
import { http } from "./http";
import { Storage } from '@capacitor/storage';
interface ILoginActionData {
  email: string;
  password: string;
  fcmToken: string;
}

export const SignUpAction = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.user.signup}`, data);
};

export const LoginAction = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.user.login}`, data);
};

export const ResetPasswordAction = (data: any): Promise<ApiResponse> => {
  console.log("login data", data);
  return http.put(`${endpoint.user.password_reset}`, data);
};

export const VerificationAction = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.user.verification}`, data);
};
export const ChangePasswordAction = (data: any): Promise<ApiResponse> => {
  return http.patch(`${endpoint.user.change_password}`, data);
};
export const ProfileAction = (data: any): Promise<ApiResponse> => {
  console.log("ProfileAction ", data);
  return http.post(`${endpoint.user.profile}`, data);
};
export const getUserAction = (id: any): Promise<ApiResponse> => {
  // console.log("data------GETUSERACTION", data);
  return http.get(`${endpoint.user.getUser}/${id}`);
};

export const socialLogin = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.user.sociallogin}`, data);
};
export const deleteUserAction = (id: string): Promise<ApiResponse> => {
  return http.delete(`${endpoint.user.deleteUser}/${id}/delete`);
};

export const LogoutAction = (userId : string) => async (dispatch: any) => {
  try {
    await http.get(endpoint.user.clearToken.replace(":userId", userId))
    await dispatch({ type: ActionType.LOGOUTUSER });
    await localStorage.clear();
    await Storage.remove({ key: "__ATK__" });
  } catch (err) {
    dispatch({
      type: ActionType.FAILURE,
    });
  }
};

// export const socialLogin = (data: ILoginState) => async (
//   dispatch: Dispatch<Action>
// ) => {
//   try {
//     await axios
//       .post(`${URL}/api/v1/users/sociallogin`, data)
//       .then((res: any) => {
//         dispatch({
//           type: ActionType.SOCIALLOGIN,
//           payload: res,
//         });
//       });
//   } catch (err) {
//     dispatch({
//       type: ActionType.FAILURE,
//     });
//   }
// };
