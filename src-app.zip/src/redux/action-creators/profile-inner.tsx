import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const ChangePasswordAction = (data: any): Promise<ApiResponse> => {
  console.log("ChangePassword data", data);
  return http.patch(`${endpoint.user.change_password}`, data);
};
