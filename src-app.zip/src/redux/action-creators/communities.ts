import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const createCommunityAction = (data: any): any => {
  console.log("createCommunityAction", data);

  return http.post(`${endpoint.Community.create}`, data);
};
export const getCommunityById = (_id: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Community.get}/${_id}`);
};

export const getCommunityPosts = (_id: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Community.getposts}/${_id}`);
};
