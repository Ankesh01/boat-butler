import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import {IPostActivityData} from "../../interfaceModules/IPostInterface";
import { http } from "./http";


export const createPostAction = (data: any):  Promise<ApiResponse> => {
  console.log("createPostAction", data);

  return http.post(`${endpoint.Post.create}`, data);
};

export const likePostAction = (data:IPostActivityData): Promise<ApiResponse> => {
  console.log("likePostAction", data);
  return http.put(`${endpoint.Post.like_community}`, data);
};

export const unlikePostAction = (data: IPostActivityData): Promise<ApiResponse> => {
  console.log("unlikePostAction", data);
  return http.put(`${endpoint.Post.unlike_community}`, data);
};
export const getPostById = (userId: string): Promise<ApiResponse> => {
  console.log("createPostAction", userId);

  return http.get(`${endpoint.Post.detail}/${userId}`);
};
