import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const getSignedUrl = (data: {filePath : string; fileFormat : string;}[]): Promise<ApiResponse> => {
    return http.post(endpoint.Files.get, {files : data});

};

export const pushFileToS3 = async (signedUrl : string, file : Blob) => {
    const myHeaders = new Headers({
        'Content-Type': file.type
    });
    return fetch(signedUrl, {
        method: 'PUT',
        headers: myHeaders,
        body: file
    });
};

export const deleteFile = async(data : string[]) => {
    return http.post(endpoint.Files.delete, data)
}