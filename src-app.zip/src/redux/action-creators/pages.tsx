import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const getAllQuestionnaireAction = (
  slug?: string
): Promise<ApiResponse> => {
  return http.get(`${endpoint.Pages.get_all}${slug ? `?slug=${slug}` : ""}`);
};

// export const getPageBySlugAction = (slug?: string): Promise<ApiResponse> => {
//   return http.get(`${endpoint.Pages.get_all}`);
// };
