import { ActionType } from "../action-types/index";

export const initialState = {
  user: localStorage.getItem("userData")
    ? JSON.parse(localStorage.getItem("userData") as string)
    : undefined,
  loginType: "",
  isLoggedIn: false,
  isFound: "",

  authData: localStorage.getItem("userData")
    ? JSON.parse(localStorage.getItem("userData") as string)
    : undefined,
};

// user information stored in global state of redux
export const authReducer = (state: object = initialState, action: any) => {
  switch (action.type) {
    case ActionType.LOGIN:
      return {
        ...state,
        isLoggedIn: true,
        user: action.payload,
        authData: action.payload,
      };
    case ActionType.FAILURE:
      return {
        ...state,
        user: action.type,
      };
    case ActionType.LOGOUTUSER:
      localStorage.clear();
      return {
        payload: "Data Cleared",
      };

    default:
      return state;
  }
};
