import { combineReducers } from "redux";
import { authReducer } from "./authReducer";

/**
 * All the reducers will connect with react app and manages the global state
 */
const appReducer = combineReducers({
  authReducer,
});

export default appReducer;
