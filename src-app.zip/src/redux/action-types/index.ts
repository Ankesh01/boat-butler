export enum ActionType {
  FAILURE = "failure",
  LOGIN = "login",
  SIGNUP = "signup",
  ERROR = "error",
  LOGOUTUSER = "logout_user"
}
