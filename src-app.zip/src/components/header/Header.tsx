import {
  IonButton,
  IonButtons,
  IonHeader,
  IonIcon,
  IonImg,
  IonMenuButton,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { Link, useHistory, useLocation } from "react-router-dom";

import "./Header.scss";

import toolbarIconImg from "../../images/100-X-100.png";
import { useEffect, useState } from "react";
import { arrowBack, trashOutline } from "ionicons/icons";

const Header = (props: any) => {
  const history = useHistory();
  const location = useLocation();
  const [isMainPage, setIsMainPage] = useState(false);

  const mainPageList = ["/", "/reminders", "/home", "/profile-inner"];

  useEffect(() => {
    setIsMainPage(mainPageList.includes(location.pathname));
  }, [location.pathname]);

  return (
    <IonHeader className="common-header">
      <div className="main-container">
        <IonToolbar>
          {isMainPage ? (
            <IonButtons slot="start" className="toolbar-btn">
              <IonMenuButton>
                <IonImg src={toolbarIconImg} />
              </IonMenuButton>
            </IonButtons>
          ) : (
            <IonButton
              slot="start"
              className="icon-btn dark-icon-btn"
              onClick={() => history.goBack()}
            >
              <IonIcon icon={arrowBack} />
            </IonButton>
          )}

          <IonTitle className="text-center">{props?.title}</IonTitle>

          {/*<div className="header-btn" slot="end">
            <Link to="/" className="link-btn tertiary-link-btn">
              Skip
            </Link>
          </div>*/}
        </IonToolbar>
      </div>
    </IonHeader>
  );
};

export default Header;
