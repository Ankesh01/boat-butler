import React, { useState } from "react";
import Calendar from "react-calendar";

import "react-calendar/dist/Calendar.css";
import "./ThemeCalendar.scss";

const ThemeCalendar = (props : any) => {
  return (
    <>
      <Calendar
      {...props}
      />
    </>
  );
};
export default ThemeCalendar;
