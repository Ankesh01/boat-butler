import { IonButton, IonIcon, IonImg } from "@ionic/react";
import {
  arrowRedoOutline,
  bookmarkOutline,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  thumbsUpOutline,
  thumbsUpSharp,
} from "ionicons/icons";
import React, { useEffect, useState, useCallback } from "react";
import { formatDBTimestamp } from "../utils/Helper";
import { Link } from "react-router-dom";
import topicImg from "../images/topic-img.jpg";
import userPlaceholder from "../images/user-placeholder.jpg";
import { post } from "../redux/action-creators/http";
import {
  IPostInterface,
  IPropsInterface,
} from "../interfaceModules/ICommunityInterface";
import moment from "moment";
import {
  likePostAction,
  unlikePostAction,
} from "../redux/action-creators/postsAction";
import { RootStateOrAny, useSelector } from "react-redux";
const PostsCard = (props: IPropsInterface) => {
  const [postLike, setPostLike] = useState<any>();

  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  useEffect(() => {
    setPostLike(props?.post?.total);
  }, [props]);

  const handleUnLike = async (_id: string) => {
    console.log("handleUnLike--_id", _id);
    let response = await unlikePostAction({
      _id: _id,
      userId: authData._id,
      type: "post",
    });
    console.log("response unlikePostAction", response);
    setPostLike(response?.data?.data?.total);
  };

  const handleLike = async (_id: string) => {
    console.log("handleLike--_id", _id);
    let response = await likePostAction({
      _id: _id,
      userId: authData._id,
      type: "post",
    });
    setPostLike(response?.data?.data?.total);
  };
  return (
    <div>
      {/* topic-card start */}
      <div className="topic-card topic-card-border" key={props.index}>
        <div className="card-head">
          <div className="heading">
            <div className="user-img">
              {/* <IonImg
                src={
                  props?.post?.userInfo[0] && props?.post?.userInfo[0]["image"]
                    ? props?.post?.userInfo[0]["image"]
                    : userPlaceholder
                }
              /> */}
            </div>
            <div className="heading-inner">
              <h5>
                Post by: <span>{props?.post?.userInfo[0]["name"]}</span>
              </h5>
              <p>
                {/* {moment(posts.created_ts, "MMM Do YYYY")} */}
                {/* Jan 12, 2021 */}
                {/* at {moment(posts.created_ts, "hh:mm A")} 10:30 AM */}
              </p>
              <p>
                {"   "}
                {moment(props?.post?.created_ts).format("MMM DD, YYYY")} at{" "}
                {moment(props?.post?.created_ts).format("hh:m A")}
              </p>
            </div>
          </div>

          <div className="card-head-btn">
            <Link to="/" className="link-icon-btn tertiary-btn">
              <IonIcon icon={ellipsisHorizontalCircleOutline} />
            </Link>
          </div>
        </div>

        <div className="card-mid">
          <div className="content">
            <p>{props?.post?.description ? props?.post?.description : ""}</p>
          </div>
          {props?.post?.media_file ? (
            <div className="topic-img">
              <IonImg src={props?.post?.media_file} />
            </div>
          ) : (
            ""
          )}
        </div>

        <div className="card-bottom">
          <div className="links">
            <ul>
              <li>
                <Link to="/">
                  <IonIcon icon={chatboxOutline} /> 0
                </Link>
              </li>
              <li>
                {postLike?.like?.includes(authData._id) ? (
                  <IonButton
                    className="icon-btn primary-icon-btn"
                    type="button"
                    onClick={() => handleUnLike(props?.post?._id)}
                  >
                    <IonIcon icon={thumbsUpSharp} />
                  </IonButton>
                ) : (
                  <IonButton
                    className="icon-btn primary-icon-btn"
                    type="button"
                    onClick={() => handleLike(props?.post?._id)}
                  >
                    <IonIcon icon={thumbsUpOutline} />
                  </IonButton>
                )}
                {postLike?.like?.length}

                {/* <Link to="/">
                  <IonIcon icon={thumbsUpOutline} />0
                </Link> */}
              </li>
              <li>
                <Link to="/">
                  <IonIcon icon={bookmarkOutline} />0
                </Link>
              </li>
              <li>
                <Link to="/">
                  <IonIcon icon={arrowRedoOutline} />0
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* topic-card start */}
    </div>
  );
};

export default PostsCard;
