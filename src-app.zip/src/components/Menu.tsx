import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonMenu,
  IonMenuToggle,
  IonNote,
  useIonToast,
} from "@ionic/react";
import { useTranslation } from "react-i18next";
import { Link, useHistory, useLocation } from "react-router-dom";

import "./Menu.scss";
import menuUser from "../images/menu-user.png";
import sidebarImg from "../images/sidebar-img.png";
import { RootStateOrAny, useDispatch, useSelector } from "react-redux";
import { useState } from "react";
import { LogoutAction } from "../redux/action-creators";

interface AppPage {
  url: string;
  iosIcon: string;
  mdIcon: string;
  title: string;
}

const Menu: React.FC = () => {
  const location = useLocation();
  const dispatch = useDispatch();
  const { t: translation } = useTranslation();
  const history = useHistory();
  const [logoutMessage, setLogoutMessage] = useState(false);
  const [present, dismiss] = useIonToast();

  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  /**
   * @method to logout user's account
   */
  const handleLogout = async () => {
    await dispatch(LogoutAction(authData._id));
    setLogoutMessage(true);
    present("Logout Successfully !!!", 2000);
    history.push("/");
    // setTimeout(()=>{
    //   history.push("/");
    // },500)
  };

  return (
    <IonMenu className="sidebar" contentId="main" type="overlay">
      <IonContent style={{ backgroundImage: `url(${sidebarImg})` }}>
        <div className="sidebar-inner">
          <div className="sidebar-close">
            <IonMenuToggle>
              <IonButton type="button" className="icon-btn white-icon-btn">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24.057"
                  height="24"
                  viewBox="0 0 24.057 24"
                >
                  <path
                    id="np_close_801635_000000"
                    d="M25.192,7.312a7.333,7.333,0,0,0-4.116-4.99,23.582,23.582,0,0,0-7.26-.924,24.5,24.5,0,0,0-7.26.9,7.333,7.333,0,0,0-4.116,4.99,25.216,25.216,0,0,0-.649,6.087,24.008,24.008,0,0,0,.649,6.112,7.333,7.333,0,0,0,4.116,4.99,24.359,24.359,0,0,0,7.26.923,23.587,23.587,0,0,0,7.26-.923,7.333,7.333,0,0,0,4.116-4.99,25.216,25.216,0,0,0,.649-6.087,23.932,23.932,0,0,0-.649-6.087Zm-7.185,8.806-1.522,1.522-2.719-2.719-2.744,2.719L9.5,16.118,12.218,13.4,9.524,10.681l1.522-1.522,2.719,2.719,2.719-2.719,1.522,1.522L15.262,13.4Z"
                    transform="translate(-1.786 -1.399)"
                  />
                </svg>
              </IonButton>
            </IonMenuToggle>
          </div>

          <div className="menu-user">
            <IonMenuToggle>
              <div className="user-img">
                <IonImg src={authData?.image ? authData.image : menuUser} />
              </div>
              <div className="name">
                <span>{translation("hello")}</span>
                <h3>{authData?.name}</h3>
              </div>
            </IonMenuToggle>
          </div>

          <div className="sidebar-menu">
            <Link to="/new-services" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="21.927"
                  height="24"
                  viewBox="0 0 21.927 24"
                >
                  <path
                    id="np_add_760869_000000"
                    d="M36.888,19.7a3.451,3.451,0,0,0-.16-1.1,4.242,4.242,0,0,0-1.9-2.47q-3.392-1.96-6.78-3.922a4.291,4.291,0,0,0-4.159-.042c-2.277,1.321-4.568,2.62-6.835,3.959a4.018,4.018,0,0,0-2.079,3.594c-.028,2.623-.006,5.246-.009,7.868a3.507,3.507,0,0,0,.183,1.179,4.263,4.263,0,0,0,1.886,2.4q3.366,1.938,6.723,3.889a4.114,4.114,0,0,0,1.881.582,4.068,4.068,0,0,0,2.334-.511q3.394-1.969,6.793-3.923a4.087,4.087,0,0,0,1.494-1.475,3.809,3.809,0,0,0,.617-1.936c.011-1.381,0-2.763,0-4.145h0c0-1.315,0-2.63,0-3.946Zm-6.065,4.415H26.394v4.429a.469.469,0,1,1-.939,0V24.117H21.026a.469.469,0,1,1,0-.939h4.429V18.749a.469.469,0,0,1,.939,0v4.429h4.429a.469.469,0,1,1,0,.939Z"
                    transform="translate(-14.961 -11.647)"
                  />
                </svg>
                {translation("add_services")}
              </IonMenuToggle>
            </Link>
            <Link to="/" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="23.084"
                  height="24"
                  viewBox="0 0 23.084 24"
                >
                  <path
                    id="np_badge_813559_000000"
                    d="M15.187,14.5h0a2.467,2.467,0,0,0,0-2.942A2.468,2.468,0,0,1,16.43,7.725a2.468,2.468,0,0,0,1.733-2.383,2.465,2.465,0,0,1,3.259-2.357,2.465,2.465,0,0,0,2.8-.909,2.469,2.469,0,0,1,4.028,0,2.465,2.465,0,0,0,2.8.909,2.465,2.465,0,0,1,3.269,2.366,2.468,2.468,0,0,0,1.723,2.374,2.469,2.469,0,0,1,1.243,3.829,2.467,2.467,0,0,0,0,2.942,2.468,2.468,0,0,1-1.243,3.835,2.467,2.467,0,0,0-1.733,2.383,2.465,2.465,0,0,1-3.269,2.366,2.469,2.469,0,0,0-2.8.913,2.469,2.469,0,0,1-4.028,0,2.468,2.468,0,0,0-2.8-.913,2.466,2.466,0,0,1-3.269-2.366,2.465,2.465,0,0,0-1.713-2.383A2.469,2.469,0,0,1,15.187,14.5Zm7.924-.461.511.521.886.886a1.255,1.255,0,0,0,1.775,0l3.064-3.064a1.256,1.256,0,0,0-1.776-1.775l-2.163,2.184-.52-.52a1.255,1.255,0,0,0-1.775,1.775Z"
                    transform="translate(-14.695 -1.035)"
                  />
                </svg>
                {translation("upgrade_membership")}
              </IonMenuToggle>
            </Link>
            <Link to="/" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    id="np_history_2712044_000000"
                    d="M18.25,6.25a12,12,0,1,0,8.486,3.514A12.005,12.005,0,0,0,18.25,6.25Zm4.037,16.037a.858.858,0,0,1-1.209,0L17.65,18.859a.857.857,0,0,1-.257-.609V13.107a.857.857,0,1,1,1.714,0V17.9l3.18,3.18a.857.857,0,0,1,0,1.209Z"
                    transform="translate(-6.25 -6.25)"
                  />
                </svg>
                {translation("payment_history")}
              </IonMenuToggle>
            </Link>
            <Link to="/business-directory" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="23.516"
                  height="24"
                  viewBox="0 0 23.516 24"
                >
                  <path
                    id="np_company_4449720_000000"
                    d="M27.193,26.325h-.728v-8.4a1.2,1.2,0,0,0-1.2-1.2v-.4a1.2,1.2,0,0,0-1.2-1.2h-4.8a1.2,1.2,0,0,0-1.2,1.2v.4a1.2,1.2,0,0,0-1.2,1.2v8.4h-2.8v-4.8a.8.8,0,0,1,.8-.8h1.2v-2.8h-3.2a.4.4,0,1,1,0-.8h3.2a.439.439,0,0,1,.16.032,1.99,1.99,0,0,1,1.056-1.072,1.871,1.871,0,0,1,.188-.624.412.412,0,0,1-.2.064h-4.4a.4.4,0,0,1,0-.8h4.4a.395.395,0,0,1,.4.412,2,2,0,0,1,1.6-.812h2.8v-8.4a1.2,1.2,0,0,0-1.2-1.2v-.4a1.2,1.2,0,0,0-1.2-1.2h-6.4a1.2,1.2,0,0,0-1.2,1.2v.4a1.2,1.2,0,0,0-1.2,1.2v20.4h-.8V12.573L6.773,10.157a1.2,1.2,0,0,0-1.908.968v15.2h-.4a.4.4,0,0,0,0,.8H27.193a.4.4,0,0,0,0-.8Zm-8.328-10a.4.4,0,0,1,.4-.4h4.8a.4.4,0,0,1,.4.4v.4h-5.6Zm0,2.8h5.6a.4.4,0,0,1,0,.8h-5.6a.4.4,0,0,1,0-.8Zm0,2.4h5.6a.4.4,0,0,1,0,.8h-5.6a.4.4,0,0,1,0-.8Zm0,2.4h5.6a.4.4,0,0,1,0,.8h-5.6a.4.4,0,0,1,0-.8Zm-12.406-9.2h2.8a.4.4,0,0,1,0,.8h-2.8a.4.4,0,0,1,0-.8Zm0,2.4h2.8a.4.4,0,0,1,0,.8h-2.8a.4.4,0,0,1,0-.8Zm0,2.4h2.8a.4.4,0,0,1,0,.8h-2.8a.4.4,0,0,1,0-.8Zm0,2.4h2.8a.4.4,0,0,1,0,.8h-2.8a.4.4,0,0,1,0-.8Zm13.606-8.8h-7.2a.4.4,0,0,1,0-.8h7.2a.4.4,0,0,1,0,.8Zm0-2.4h-7.2a.4.4,0,0,1,0-.8h7.2a.4.4,0,0,1,0,.8Zm0-2.4h-7.2a.4.4,0,0,1,0-.8h7.2a.4.4,0,0,1,0,.8Zm-7.2-4a.4.4,0,0,1,.4-.4h6.4a.4.4,0,0,1,.4.4v.4h-7.2Z"
                    transform="translate(-4.071 -3.125)"
                  />
                </svg>
                {translation("business_directory")}
              </IonMenuToggle>
            </Link>
            <Link to="/receipts" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="23.875"
                  height="24"
                  viewBox="0 0 23.875 24"
                >
                  <path
                    id="Union_38"
                    data-name="Union 38"
                    d="M23747.152,12082a2.973,2.973,0,0,1-2.969-2.973v-14.264h-.73a2.461,2.461,0,0,1-2.453-2.459v-1.857a2.455,2.455,0,0,1,2.453-2.447h18.969a2.459,2.459,0,0,1,2.453,2.447v1.857a2.461,2.461,0,0,1-2.453,2.459h-.732v14.264a2.971,2.971,0,0,1-2.967,2.973Zm-1.377-2.973a1.378,1.378,0,0,0,1.377,1.377h11.57a1.382,1.382,0,0,0,.973-.4,1.406,1.406,0,0,0,.4-.979v-16.984h-14.324v16.984Zm15.914-18.58v2.721h.732a.861.861,0,0,0,.857-.863v-1.857a.864.864,0,0,0-.857-.858h-18.969a.873.873,0,0,0-.863.858v1.857a.862.862,0,0,0,.863.863h.73v-2.721Zm-11.937,14.69a.855.855,0,0,1-.8-.8.8.8,0,0,1,.8-.793h6.365a.851.851,0,0,1,.8.793.794.794,0,0,1-.8.8Zm0-3.611a.86.86,0,0,1-.8-.8.8.8,0,0,1,.8-.8h6.365a.855.855,0,0,1,.8.8.8.8,0,0,1-.8.8Zm0-3.61a.861.861,0,0,1-.8-.8.8.8,0,0,1,.8-.8h6.365a.855.855,0,0,1,.8.8.8.8,0,0,1-.8.8Z"
                    transform="translate(-23741 -12058.002)"
                  />
                </svg>
                {translation("view_receipts")}
              </IonMenuToggle>
            </Link>
            <Link
              to="/post-detail/623d58a4c4d7809692de455d"
              className="menu-item"
            >
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    id="Union_5"
                    data-name="Union 5"
                    d="M19789,12951a11.961,11.961,0,1,1,.078,0Zm-10.574-12a10.574,10.574,0,1,0,10.574-10.574A10.592,10.592,0,0,0,19778.426,12939Zm9.84,5.266v-4.489h-4.488a.733.733,0,1,1,0-1.466h4.486l0-4.49a.733.733,0,1,1,1.467,0v4.49h4.49a.721.721,0,0,1,.734.689.758.758,0,0,1-.734.733h-4.49v4.532a.733.733,0,1,1-1.467,0Z"
                    transform="translate(-19777 -12927.001)"
                  />
                </svg>
                {translation("community_forum")}
              </IonMenuToggle>
            </Link>

            <Link to="/forum" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    id="Union_5"
                    data-name="Union 5"
                    d="M19789,12951a11.961,11.961,0,1,1,.078,0Zm-10.574-12a10.574,10.574,0,1,0,10.574-10.574A10.592,10.592,0,0,0,19778.426,12939Zm9.84,5.266v-4.489h-4.488a.733.733,0,1,1,0-1.466h4.486l0-4.49a.733.733,0,1,1,1.467,0v4.49h4.49a.721.721,0,0,1,.734.689.758.758,0,0,1-.734.733h-4.49v4.532a.733.733,0,1,1-1.467,0Z"
                    transform="translate(-19777 -12927.001)"
                  />
                </svg>
                Forum
              </IonMenuToggle>
            </Link>
            <Link to="/" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    id="Union_28"
                    data-name="Union 28"
                    d="M0,12A12,12,0,1,1,12,24,12.011,12.011,0,0,1,0,12Zm17.145,5.15a.48.48,0,0,0,0,.677l.921.921a.473.473,0,0,0,.662.01c.013-.015.028-.034.043-.048h0A9.37,9.37,0,0,0,21.52,12a9.517,9.517,0,0,0-2.779-6.719s-.01-.019-.015-.024a.089.089,0,0,0-.024-.015,9.514,9.514,0,0,0-13.439,0s-.019.01-.024.015a.079.079,0,0,0-.015.024A9.52,9.52,0,0,0,5.2,18.7c.013.015.028.034.043.048a.491.491,0,0,0,.341.139.473.473,0,0,0,.341-.139l.921-.921a.479.479,0,1,0-.677-.677l-.566.566a8.508,8.508,0,0,1-2.164-5.237h.8a.48.48,0,1,0,0-.961h-.8a8.562,8.562,0,0,1,2.17-5.227l.561.561a.491.491,0,0,0,.341.139.472.472,0,0,0,.341-.139.479.479,0,0,0,0-.677l-.561-.561a8.529,8.529,0,0,1,5.227-2.17v.8a.48.48,0,0,0,.961,0v-.8A8.561,8.561,0,0,1,17.7,5.614l-.561.561a.48.48,0,0,0,0,.677.491.491,0,0,0,.341.139.472.472,0,0,0,.341-.139l.561-.561a8.528,8.528,0,0,1,2.17,5.227h-.8a.48.48,0,1,0,0,.961h.8a8.527,8.527,0,0,1-2.164,5.237l-.566-.566a.479.479,0,0,0-.677,0ZM10.2,12a1.8,1.8,0,1,0,3.369-.887L16.33,8.347a.479.479,0,1,0-.677-.677l-2.765,2.765A1.8,1.8,0,0,0,10.2,12Zm.955,0a.845.845,0,0,1,1.444-.6.817.817,0,0,1,.245.6.845.845,0,1,1-1.69,0Z"
                  />
                </svg>
                {translation("buy_hour_meter")}
              </IonMenuToggle>
            </Link>
          </div>

          <div className="sidebar-menu-bottom">
            <Link to="/help-and-support" className="menu-item">
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="23.329"
                  height="24"
                  viewBox="0 0 23.329 24"
                >
                  <path
                    id="Union_29"
                    data-name="Union 29"
                    d="M.49,24A.49.49,0,0,1,0,23.51V21.759a.489.489,0,0,1,.149-.352A16.717,16.717,0,0,1,7.93,17.1a.5.5,0,0,1,.113-.013h.186c.01,0,.018,0,.028,0l-1.18,2.564L9.446,24Zm13.332,0,2.415-4.4L15.079,17.09l.021,0h.256a.482.482,0,0,1,.234.059,16.744,16.744,0,0,1,7.589,4.259.49.49,0,0,1,.148.352v1.75a.489.489,0,0,1-.49.49Zm.663-9.667a6.061,6.061,0,0,0,1.771-3.794h.016a.93.93,0,0,0,.9-.955.959.959,0,0,0-.533-.873c0-.01,0-.019.008-.028C9.359,7.819,8.723,2.85,8.723,2.85a27.269,27.269,0,0,1-2.038,5.86.96.96,0,0,0-.534.872.93.93,0,0,0,.9.955h.016a4.634,4.634,0,0,0,3.8,2.8.72.72,0,0,1,.634-.381h0a.725.725,0,1,1-.669,1,5.054,5.054,0,0,1-3.317-1.6A5.989,5.989,0,0,0,8.8,14.291v1.248A12.59,12.59,0,0,1,2.931,13.78c3.309-2.023.468-8.824,4.118-12S11.664.656,11.664.656s.965-2.06,4.616,1.12.808,9.982,4.117,12a12.6,12.6,0,0,1-5.911,1.76Z"
                  />
                </svg>
                {translation("help_and_support")}
              </IonMenuToggle>
            </Link>
            <Link to="/" className="menu-item" onClick={handleLogout}>
              <IonMenuToggle>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    id="np_reset_3320950_000000"
                    d="M25.281,37.281a12.013,12.013,0,1,1,8.481-3.518A12,12,0,0,1,25.281,37.281ZM26.047,18.9a.766.766,0,1,0-1.532,0v6.638a.766.766,0,1,0,1.532,0Zm3.222,1.195a.8.8,0,0,0-.454-.148.766.766,0,0,0-.454,1.384,5.163,5.163,0,1,1-6.158,0,.767.767,0,0,0-.909-1.236,6.695,6.695,0,1,0,7.976,0Z"
                    transform="translate(-13.281 -13.281)"
                  />
                </svg>
                {translation("logout")}
              </IonMenuToggle>
            </Link>
            {logoutMessage}
          </div>
        </div>
      </IonContent>
    </IonMenu>
  );
};

export default Menu;
