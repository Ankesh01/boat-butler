export interface IForumInterface {
  _id: string;
  title: string;
  description: string;
  status: string;
  created_ts?: string;
  updated_ts?: string;
}
