export interface IServiceInterface{
    boatInfo : any[];
    boat_id : string;
    created_ts?:string;
    due_date : string | Date;
    items : {
        name : string;
        status : string;
    }[];
    photos? : string[];
    receipts : string[];
    status : string;
    updated_ts ?: string;
    user_id : string;
    _id? : string

}