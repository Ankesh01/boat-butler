export interface IServiceProviderInterface {
  _id?: string;
  owner_name?: string;
  business_name?: string;
  registration_number?: string;
  contact_number: string;
  email?: string;
  distance?: Number;
  location: ILocation;
  business_hours: [];
  services?: string;
  photos: string[];
  status?: string;
  updated_ts?: string;
  user_id: string;
  __v?: 0;
}

export interface ILocation {
  address_line1: string;
  address_line2: string;
  country: string;
  city: string;
  state: string;
  zip: string;
  latitude: string;
  longitude: string;
  coordinates: number[];
}
