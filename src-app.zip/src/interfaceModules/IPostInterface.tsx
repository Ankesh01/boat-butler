export interface IPostActivityData {
  _id: string;
  userId?: string;
  user_id?: string;
 type?: string;
}
