export interface IPagesInterface {
  _id: string;
  title: string;
  slug: string;
  content: string;
  created_ts: string;
  updated_ts: string;
  open?: boolean;
}
export interface ISlugInterface {
  _id: string;
  title?: string;
  slug?: string;
  content?: string;
  created_ts?: string;
  updated_ts?: string;
  is_faq?: number;
}
