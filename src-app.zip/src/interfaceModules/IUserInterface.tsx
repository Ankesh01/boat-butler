export interface ISignUpState {
  name: string;
  email: string;
  password: string;
}

export interface ILoginState {
  // id: number;
  email: string;
  password: string;
}

export interface IResetPassState {
  email: string;
}
export interface IVerification {
  otp: number;
}
export interface INewPassword {
  password: string;
  confirm_password: string;
}
export interface IProfileState {
  id: number;
  name: string;
  email: string;
  phone: number;
  gender: string;
  address_line_1: string;
  address_line_2: string;
  state: string;
  city: string;
  zipcode: number;
  image?: string;
  oldImage?: string;
  imageType?: string;
}
