export interface IChangePasswordState {
  // id: number;
  password: string;
  newpassword: string;
  confirm_password: string;
}
