export interface ICommunityInterface {
  _id: string;
  user_id: string;
  title: string;
  description?: string;
  status: string;
  image?: { data: string; format: string };
  reported: { count: number; reported_by: Array<string[]> };
  created_ts: string;
  updated_ts: string;
}

export interface ICommunityDetailInterface {
  _id: string;
  user_id: string;
  title: string;
  description?: string;
  status: string;
  image?: string;
  reported: { count: number; reported_by: Array<string[]> };
  created_ts: string;
  updated_ts: string;
}
export interface IPhotoInterface {
  image?: { data: string; format: string };
}

export interface IPostInterface {
  _id: string;
  user_id: string;
  type: string;
  description?: string;
  type_item_id: string;
  media_file?: string;
  total: any;
  userInfo?: any;
  created_ts: string;
  updated_ts: string;
}
export interface IPropsInterface {
  post: IPostInterface;
  index: number;
}
