import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonSpinner,
  IonTextarea,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  arrowRedoOutline,
  bookmarkOutline,
  calendarClearOutline,
  cameraOutline,
  chatboxOutline,
  closeCircleOutline,
  ellipsisHorizontalCircleOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
  thumbsUpOutline,
} from "ionicons/icons";
import { useState, useEffect } from "react";
import "./Community.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import topicImg from "../../images/topic-img.jpg";
import userPlaceholder from "../../images/user-placeholder.jpeg";
import { CommunityValidationSchema } from "../../utils/validationschema";
import {
  ICommunityDetailInterface,
  IPhotoInterface,
} from "../../interfaceModules/ICommunityInterface";
import {
  getCommunityById,
  getCommunityPosts,
} from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { getPicture, uploadFileOnS3 } from "../../utils/Helper";
import { createPostAction } from "../../redux/action-creators/postsAction";
import { useLocation } from "react-router";
import { RootStateOrAny, useSelector } from "react-redux";
import { deleteFile } from "../../redux/action-creators/FileUpload";
import PostsCard from "../../components/PostsCard";
const Community: React.FC = () => {
  const [communityDetail, setCommunityDetail] =
    useState<ICommunityDetailInterface>();
  const [buttonDisable, setButtonDisable] = useState(false);
  const [postList, setPostList] = useState([]);
  const [spin, setSpin] = useState(false);
  const [postspinner, setPostSpinner] = useState(false);
  const location = useLocation();
  const community_id = location.pathname.includes("/community")
    ? location.pathname.split("/")?.[2]
    : "";
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [image, setImage] = useState<string[]>([]);

  const [present, dismiss] = useIonToast();
  console.log("community_id", community_id);
  useEffect(() => {
    fetchCommunity(community_id);
    fetchCommunityPosts(community_id);
  }, [PostsCard]);

  const fetchCommunity = async (community_id: string) => {
    const response = await getCommunityById(community_id);
    console.log("community by id", response);
    setCommunityDetail(response?.data?.data ? response?.data?.data : []);
  };

  const fetchCommunityPosts = async (community_id: string) => {
    const response = await getCommunityPosts(community_id);
    console.log("setPostList", response);
    setPostList(response?.data?.data ? response?.data?.data : []);
  };
  console.log("PostState", postList);

  const handleUpload = async (event: any) => {
    setSpin(true);
    const { files } = event.target;
    console.log("files.", files);
    const fileUrlList = await uploadFileOnS3(files, "handleUpload");
    console.log("fileUrlList.", fileUrlList);
    //  let state = { ...selectedService } as any;

    //  state.receipts = [
    //    ...state.receipts,
    //    ...fileUrlList.map((i: string) => ({ data: i, format: "" })),
    //  ];

    //  setSelectedService({ ...state });
    setImage(fileUrlList);
    setSpin(false);
    //  setUpdateService(true);
  };

  const handleRemoveImage = () => {
    // let state = { ...selectedService } as any;
    setSpin(true);
    const file: any = [...image];
    setImage([]);
    // state.receipts.splice(index,  1);
    // setSelectedService({ ...state });
    // setUpdateService(true);

    deleteFile([file]);
    setSpin(false);
  };

  console.log("images---", image);
  const {
    control,
    resetField,
    handleSubmit,
    reset,

    clearErrors,
    formState: { errors },
  } = useForm<ICommunityDetailInterface>({
    resolver: yupResolver(CommunityValidationSchema()),
  });
  const onSubmit = async (data: ICommunityDetailInterface) => {
    setPostSpinner(true);
    setButtonDisable(true);
    let response;
    console.log("onSubmit", data);
    console.log("Photo", image);
 
    response = await createPostAction({
      ...data,
      user_id: authData._id,
      image: image,
      type: "community",
      type_item_id: community_id,
    });
    console.log("createPostAction response", response);
    if (response?.data?.message && response?.data?.success) {
      clearErrors('description');
      reset();
      
      setImage([]);
      // resetField("description", { keepTouched: true });
      // reset({ description: " " });
      // reset(
      //   {
      //     description: "",
      //   },
      //   {
      //     keepErrors: false, // keepDefaultValues: true,

      //     keepIsValid: false,
      //   }
      // );

      // clearErrors(errors);
      // reset(
      //   {
      //     description: "",
      //   },
      //   {
      //     keepErrors: false, // keepDefaultValues: true,

      //     keepIsValid: false,
      //   }
      // );

      present(response?.data?.message, 2000);
      fetchCommunityPosts(community_id);
    } else {
      present(response?.data?.message, 2000);
    }
    setPostSpinner(false);
    setButtonDisable(false);
  };

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="community-page community-dashboard-page">
          {/* community-dashboard-head start */}
          <div className="community-dashboard-head">
            <div className="main-container">
              <div className="head-inner">
                <div className="name">
                  <div className="circle-img">
                    <IonImg
                      src={
                        communityDetail?.image &&
                        communityDetail?.image.length > 0
                          ? communityDetail?.image
                          : userProfileImg
                      }
                    />
                  </div>
                  <h2>{communityDetail?.title}</h2>
                </div>
                {communityDetail?.user_id !== authData._id ? (
                  <div className="inline-btn">
                    <IonButton
                      type="button"
                      className="theme-button white-btn btn-sm"
                    >
                      Join
                    </IonButton>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>

          <div className="main-container">
            {/* post-input-card start */}

            <div className="post-input-card">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="post-input">
                  <Controller
                    render={({ field }) => (
                      <IonTextarea
                        {...field}
                        rows={6}
                        className="form-control"
                        placeholder="Lorem Ipsum is simply"
                        onIonChange={field.onChange}
                      />
                    )}
                    name="description"
                    control={control}
                    rules={{ required: true }}
                    defaultValue=""
                  />
                  {/* <div className="message error">
                    {errors && errors.description && (
                      <p>{errors?.description?.message}</p>
                    )}
                  </div> */}
                </div>

                <div className="card-bottom">
                  <div className="form-group mb-0">
                    <div className="file-upload-btn d-inline-block">
                      <input
                        className="file-input"
                        accept="image/*"
                        type="file"
                        onChange={handleUpload}
                      />

                      {/* <IonButton
                        expand="block"
                        className="icon-btn tertiary-icon-btn"
                        onClick={() =>
                          handleImages("single", "base64", "boat_image")
                        }
                      > */}
                      <IonIcon icon={cameraOutline} />
                      {/* </IonButton> */}
                    </div>
                  </div>

                  <div className="inline-btn">
                    <IonButton
                      type="button"
                      className="theme-button dark-outline-btn btn-sm"
                      onClick={handleSubmit(onSubmit)}
                      disabled={buttonDisable}
                    >
                      Post
                      {postspinner && (
                        <span>
                          <IonSpinner />
                        </span>
                      )}
                    </IonButton>
                  </div>
                </div>
              </form>
            </div>

            <div className="file-upload-btn">
              {spin && (
                <span>
                  <IonSpinner />
                </span>
              )}
              {image && image?.length > 0 ? (
                <div className="card-head">
                  <IonImg src={image[0]} />
                  <div className="action-btn">
                    <IonButton
                      type="button"
                      className="icon-btn primary-icon-btn "
                      onClick={() => handleRemoveImage()}
                    >
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>

                  {/* <IonIcon
                              icon={fileTrayStackedSharp}
                            />*/}
                </div>
              ) : (
                ""
              )}
            </div>
            {/* <IonImg src={image[0]} /> */}
            {/* <IonButton
              type="button"
              className="icon-btn primary-icon-btn "
              onClick={() => handleRemoveImage()}
            >
              <IonIcon icon={closeCircleOutline} />
            </IonButton> */}
            {/* post-input-card end */}

            <div>
              {/* topic-card start */}

              {postList && postList.length > 0
                ? postList.map((post: any, index: number) => {
                    return (
                      <>
                        <PostsCard post={post} index={index} />
                      </>
                    );
                  })
                : "No Posts Found."}
              {/* topic-card start */}
            </div>

            <div>
              {/* <IonButton expand="block" className="theme-button primary-btn">
                Create
              </IonButton> */}
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};
export default Community;
