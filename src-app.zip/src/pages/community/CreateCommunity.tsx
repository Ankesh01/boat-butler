import {
  InputChangeEventDetail,
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonTextarea,
  useIonToast,
  IonSpinner,
  TextareaChangeEventDetail,
} from "@ionic/react";
import { closeCircleOutline } from "ionicons/icons";
import { Link } from "react-router-dom";

import { useState, useEffect } from "react";
import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  calendarClearOutline,
  cameraOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Community.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import { ICommunityInterface } from "../../interfaceModules/ICommunityInterface";
import { createCommunityAction } from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { useHistory } from "react-router-dom";
import {
  downloadFile,
  formatDate,
  formatDBTimestamp,
  getPicture,
  uploadFileOnS3,
} from "../../utils/Helper";
import { RootStateOrAny, useSelector } from "react-redux";

const CreateCommunity: React.FC = () => {
  const [community, setCommunity] = useState<ICommunityInterface>();
  const [showloader, setshowLoader] = useState(false);
  const [spin, setSpin] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const history = useHistory();
  let [errorMessage, setErrorMessage] = useState({
    title: "",
    description: "",
  });
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  const [present, dismiss] = useIonToast();
  const handleChange = (
    event:
      | CustomEvent<InputChangeEventDetail>
      | CustomEvent<TextareaChangeEventDetail>,
    name: string
  ) => {
    let target = event.target as HTMLSelectElement;

    setErrorMessage((prevState) => ({
      ...prevState,
      [name]: undefined,
    }));

    setCommunity((prevState: any) => ({
      ...prevState,
      [name]: target.value,
    }));
  };
  const handleImages = async (
    number: string,
    type: string,
    name: string,
    index?: string
  ) => {
    let images: any = await getPicture(number, type);

    console.log("images", images);
    setCommunity((prevState: any) => ({
      ...prevState,
      ["image"]: images,
    }));
  };

  console.log("community", community);

  const validateUserInfo = () => {
    let isFormValid = true;

    if (community?.title == null || community?.title == "") {
      isFormValid = false;
      errorMessage.title = "Title is required";
    }

    if (community?.description == null || community?.description == "") {
      isFormValid = false;
      errorMessage.description = "description is required";
    }
    setCommunity((prevState: any) => ({
      ...prevState,
    }));
    return isFormValid;
  };

  const handleSubmit = async () => {
    setshowLoader(true);
    setButtonDisable(true);

    setCommunity((prevState: any) => ({
      ...prevState,
    }));

    if (validateUserInfo()) {
      let response: any;

      response = await createCommunityAction({
        ...community,
        user_id: authData._id,
      });
      console.log("response", response);
      if (response?.data?.message && response?.data?.success) {
        console.log("Created_community_iddddddd", response?.data?.data?._id);
        present(response?.data?.message, 1000);

        setTimeout(
          () => history.push(`/community/${response?.data?.data?._id}`),
          2000
        );
      } else {
        present(response?.data?.message, 1000);
      }
      // setTimeout(() => history.push("/home"), 3000);
    }

    setshowLoader(false);
    setButtonDisable(false);
  };

  return (
    <>
      <Header title={"Create a community"} />
      <IonContent fullscreen>
        <div className="community-page">
          <div className="main-container">
            <div className="form-group input-label">
              <IonLabel>Community Name</IonLabel>
              <IonInput
                type="text"
                className="form-control"
                placeholder="Lorem Ipsum is simply"
                onIonChange={(e) => {
                  handleChange(e, "title");
                }}
              ></IonInput>
              <div className="message info-message">
                <p className="opacity-3">
                  Community names including capitalisation cannot be changed.
                </p>
              </div>
              <div className="message error">
                {errorMessage && errorMessage?.title && (
                  <p>{errorMessage?.title}</p>
                )}
              </div>
            </div>

            <div className="conditions-info">
              <div className="heading">
                <h2>Conditions</h2>
              </div>
              <div className="conditions-inner">
                <div className="form-group input-label">
                  <IonTextarea
                    // type="text"
                    rows={6}
                    className="form-control"
                    placeholder="Lorem Ipsum is simply"
                    onIonChange={(e) => handleChange(e, "description")}
                  ></IonTextarea>
                  <div className="message error">
                    {errorMessage && errorMessage?.description && (
                      <p>{errorMessage?.description}</p>
                    )}
                  </div>
                </div>

                {/* <h3>Why do we use it?</h3>
                <p>
                  It is a long established fact that a reader will be distracted
                  by the readable content of a page when looking at its layout.
                  The point of using Lorem Ipsum is that it has a more-or-less
                  normal distribution of letters, as opposed to using ‘Content
                  here, content here’, making it look like readable English.
                </p> */}
              </div>
              <div>
                <IonButton
                  expand="block"
                  className="theme-button dark-outline-btn"
                  onClick={() => handleImages("single", "base64", "boat_image")}
                >
                  Add Photo
                </IonButton>

                {community?.image?.data ? (
                  <div>
                    <IonImg
                      src={
                        community?.image?.data
                        // ? community?.image?.data
                        // : userProfileImg
                      }
                      alt=""
                    />
                    <IonButton
                      className="icon-btn primary-icon-btn"
                      type="button"
                      onClick={() =>
                        setCommunity((prevState: any) => ({
                          ...prevState,
                          image: Object.assign({}),
                        }))
                      }
                    >
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>
                ) : (
                  ""
                )}
              </div>
            </div>

            <div>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit}
                disabled={buttonDisable}
              >
                Create
                {showloader ? <IonSpinner /> : null}
              </IonButton>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                // onClick={handleSubmit}
                // disabled={buttonDisable}
                onClick={() =>
                  history.push("/community/623c702124a72c785890f981")
                }
              >
                Goto_Community
                {showloader ? <IonSpinner /> : null}
              </IonButton>
            </div>
            {/* <IonButton
              expand="block"
              className="theme-button primary-btn"
              onClick={() =>
                history.push("/community/623bfa1a74a799c0c7b33e8f")
              }
            >
              Community
            </IonButton> */}
          </div>
        </div>
      </IonContent>
    </>
  );
};
export default CreateCommunity;
