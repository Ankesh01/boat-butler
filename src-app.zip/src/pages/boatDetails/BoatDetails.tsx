import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
} from "@ionic/react";
import { Link, useHistory } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { getBoatByIdAction } from "../../redux/action-creators/boat";
import { RootStateOrAny, useSelector } from "react-redux";
import { BoatDb } from "../../interfaceModules/IBoatInterface";
import { formatTimestamp } from "../../utils/Helper";
import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./BoatDetails.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { title } from "process";
import {
  getBoatServicesByUserId,
  getServicesHistory,
} from "../../redux/action-creators/boatServices";
import ServiceCard from "../../components/ServiceCard";

const BoatDetails: React.FC = (props: any) => {
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  const [upcomingService, setUpcomingService] = useState([]);
  const [serviceHistory, setServiceHistory] = useState([]);
  const [boatState, setBoatState] = useState<BoatDb>({
    user_id: "",
    title: "",
    date_of_bought: new Date(),
    seller_phone: "",
    registration_id: "",
    vin: "",
    make: "",
    model: "",
    year_of_hull: 0,
    engine: {},
    other_equipments: [],
    photos: [],
  });
  const boatId = props.location.pathname.split("/")[2];
  console.log("Props-", boatId);

  useEffect(() => {
    fetchBoat();
    fetchBoatServices();
    fetchBoatServicesHistory();
  }, []);

  const fetchBoatServices = async () => {
    const response = await getBoatServicesByUserId(authData._id, { boatId });
    setUpcomingService(response?.data?.data ? response?.data?.data : []);
  };
  const fetchBoatServicesHistory = async () => {
    const response = await getServicesHistory(authData._id, { boatId });
    setServiceHistory(response?.data?.data ? response?.data?.data : []);
  };
  const fetchBoat = async () => {
    const res = await getBoatByIdAction(boatId);
    setBoatState(res?.data?.data);
  };
  return (
    <>
      <Header title={"Boat Details"} />
      <IonContent fullscreen>
        <div className="boat-details-page">
          <div className="main-container">
            {/* detail-section start */}
            <div className="detail-section">
              <IonGrid className="p-0">
                <IonRow>
                  <IonCol size="4">
                    <div className="my-boats-box">
                      <div className="box-inner">
                        <div className="boats-img">
                          <IonImg
                            className="m-auto w-100"
                            src={
                              boatState.photos && boatState.photos[0]
                                ? boatState.photos[0]
                                : boatImg
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </IonCol>
                  <IonCol size="8">
                    <div className="boat-info">
                      <div className="heading">
                        <h4>{boatState.title}</h4>
                        <span>
                          {boatState.engine?.number_of_engines} Engine
                        </span>
                      </div>
                      <div className="boat-info-detail">
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Model</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Reg. ID</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.registration_id}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>VIN</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.vin}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Make</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Hull</p>
                          </div>
                          <div className="item-contnet">
                            <p>
                              {boatState.year_of_hull
                                ? formatTimestamp(boatState.year_of_hull)
                                : `-`}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </IonCol>
                  <IonCol size="12">
                    <div className="boat-info mb-30">
                      <div className="boat-info-detail">
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine Number</p>
                          </div>
                          <div className="item-contnet">
                            <p>Double</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine Make</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine Model</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine Hours</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.hours}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine Year</p>
                          </div>
                          <div className="item-contnet">
                            <p>2003</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Engine S/N#</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.serial_number}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Equipment Make</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState?.other_equipments[0]?.equip_make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Equipment Model</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState?.other_equipments[0]?.equip_model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>Installed</p>
                          </div>
                          <div className="item-contnet">
                            {/* <p>{boatState?.other_equipments}</p> */}
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>S/N#</p>
                          </div>
                          <div className="item-contnet">
                            <p>YU786-7676777</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </IonCol>
                </IonRow>
              </IonGrid>
            </div>
            {/* detail-section end */}

            {/* boat gallery section start */}
            <div className="boat-gallery-section">
              <IonGrid className="p-0">
                <IonRow>
                  {boatState?.photos?.map((photo: any, index: number) => {
                    return (
                      <IonCol size="4" key={index}>
                        <div className="gallery-card">
                          <IonImg src={photo ? photo : boatGalleryImg} />
                          {/* <Link to="/" className="edit-icon"> */}
                          <div
                            className="edit-icon"
                            onClick={() => history.push(`/edit-boat/${boatId}`)}
                          >
                            <IonIcon icon={pencilOutline} />
                          </div>
                          {/* </Link> */}
                        </div>
                      </IonCol>
                    );
                  })}

                  {/* <IonCol size="4">
                    <div className="gallery-card">
                      <IonImg src={boatGalleryImg} />
                      <Link to="/" className="edit-icon">
                        <IonIcon icon={pencilOutline} />
                      </Link>
                    </div>
                  </IonCol> */}
                </IonRow>
              </IonGrid>
            </div>
            {/* boat gallery section end */}
          </div>

          {/* Upcoming Services start */}
          <div className="upcoming-services mb-30">
            <div className="main-container">
              <div className="common-heading">
                <div className="heading">
                  <h2>Upcoming Services</h2>
                </div>
              </div>
              <div className="upcoming-services-inner mb-30">
                {/* card start */}
                {upcomingService && upcomingService.length > 0
                  ? upcomingService.map((service: any, Bindex: number) => {
                      return <ServiceCard serviceData={service} key={Bindex} />;
                    })
                  : "No Upcoming Services Found."}

                {/* card end */}
              </div>
              <div>
                <IonButton
                  expand="block"
                  className="theme-button primary-btn"
                  onClick={() => history.push(`/new-services/${boatState._id}`)}
                >
                  Create Service List
                </IonButton>
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}

          {/* Upcoming Services start */}
          <div className="upcoming-services">
            <div className="main-container">
              <div className="common-heading">
                <div className="heading">
                  <h2>Services History</h2>
                </div>
                {/* <div className="btn-inline">
                  <Link className="link-btn dark-link-btn" to="/">
                    View All
                  </Link>
                </div> */}
              </div>
              <div className="upcoming-services-inner">
                {/* card start */}
                {serviceHistory && serviceHistory.length > 0
                  ? serviceHistory.map((service: any, Bindex: number) => {
                      return <ServiceCard serviceData={service} key={Bindex} />;
                    })
                  : "No Service History Found."}
                {/* card end */}
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}
        </div>
      </IonContent>
    </>
  );
};

export default BoatDetails;
