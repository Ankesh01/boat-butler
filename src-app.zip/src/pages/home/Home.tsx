import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonSpinner,
} from "@ionic/react";
import { Link, useHistory } from "react-router-dom";
import { RootStateOrAny, useSelector, useDispatch } from "react-redux";
import {
  addCircleOutline,
  arrowForwardOutline,
  boat,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";
import { add_Boat } from "../../interfaceModules/IBoatInterface";
import "./Home.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import {
  calculateProgress,
  formatTimestamp,
  getDaysDifferenceFromToday,
} from "../../utils/Helper";
import Header from "../../components/header/Header";
import React, { useEffect, useState } from "react";
import { getBoatListAction } from "../../redux/action-creators/boat";
import ServiceCard from "../../components/ServiceCard";
import { getBoatServicesByUserId } from "../../redux/action-creators/boatServices";
import { useTranslation } from "react-i18next";
const Home: React.FC = () => {
  const history = useHistory();
  const { t: translation } = useTranslation();
  const [boatState, setBoatState] = useState([]);
  const [upcomingService, setUpcomingService] = useState([]);
  const [searchKeyword, setsearchKeyword] = useState();
  const [loadingBoat, setLoadingBoat] = useState(true);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  useEffect(() => {
    fetchBoatList();
    fetchBoatServices();
  }, [searchKeyword]);

  const fetchBoatList = async () => {
    setLoadingBoat(true);
    setBoatState([]);
    const res = await getBoatListAction(authData._id, searchKeyword);
    setBoatState(res?.data?.data ? res?.data?.data : []);
    setLoadingBoat(false);
  };

  const fetchBoatServices = async () => {
    const response = await getBoatServicesByUserId(authData._id);
    setUpcomingService(response?.data?.data ? response?.data?.data : []);
  };

  const myBoatsSlideOpts = {
    initialSlide: 1,
    slidesPerView: 2,
    speed: 400,
    spaceBetween: 10,
  };

  const handleSearch = (e: any) => {
    e.preventDefault();
    setTimeout(() => setsearchKeyword(e.target.value), 300);
  };
  return (
    <>
      <Header title={""} />
      <IonContent fullscreen>
        <div className="home-page-inner">
          <div className="main-container">
            {/* home-search start */}
            <div className="home-search">
              <div className="form-group">
                <div className="right-icon-input">
                  <IonInput
                    className="form-control"
                    placeholder="Search Boat"
                    onIonChange={(e) => handleSearch(e)}
                  />
                  <Link to="/">
                    <IonIcon icon={searchOutline} />
                  </Link>
                </div>
              </div>
            </div>
            {/* home-search end */}

            {/* my-boats start */}
            <div className="my-boats">
              <div className="common-heading">
                <div className="heading">
                  <h2> {translation("my_boats")}</h2>
                </div>
                <div className="btn-inline">
                  <IonButton
                    className="icon-btn primary-icon-btn"
                    onClick={() => history.push("/add-boat")}
                  >
                    <IonIcon icon={addCircleOutline} />
                  </IonButton>
                </div>
              </div>

              {loadingBoat ? (
                <IonSpinner />
              ) : boatState.length > 0 ? (
                <div className="my-boats-slider">
                  <IonSlides pager={false} options={myBoatsSlideOpts}>
                    {boatState.map((boat: any, index: number) => {
                      return (
                        <IonSlide key={index}>
                          <div className="my-boats-box">
                            <div className="box-inner">
                              <div className="box-top">
                                <div className="heading">
                                  <h2>{boat.title}</h2>
                                  <p>{boat?.engine?.number_of_engines}</p>
                                </div>
                                <div className="btn-inline">
                                  <IonButton
                                    className="icon-btn grey-icon-btn"
                                    onClick={() =>
                                      history.push(`/edit-boat/${boat._id}`)
                                    }
                                  >
                                    <IonIcon icon={pencilOutline} />
                                  </IonButton>
                                </div>
                              </div>
                              <div
                                className="boats-img"
                                onClick={() =>
                                  history.push(`/boat-details/${boat._id}`)
                                }
                              >
                                <IonImg
                                  src={
                                    boat.photos && boat.photos[0]
                                      ? boat.photos[0]
                                      : boatImg
                                  }
                                />
                              </div>
                            </div>
                          </div>
                        </IonSlide>
                      );
                    })}
                  </IonSlides>
                </div>
              ) : (
                <p>{translation("no_boat_found")}</p>
              )}
            </div>
            {/* my-boats end */}

            {/* Upcoming Services start */}
            <div className="upcoming-services">
              <div className="common-heading">
                <div className="heading">
                  <h2> {translation("upcoming_services")}</h2>
                </div>
                <div className="btn-inline">
                  <Link
                    className="link-btn dark-link-btn"
                    to="/upcoming-services"
                  >
                    {translation("view_all")}
                  </Link>
                </div>
              </div>

              <div className="upcoming-services-inner">
                {upcomingService.map((service: any, Bindex: number) => {
                  return <ServiceCard serviceData={service} key={Bindex} />;
                })}
              </div>
            </div>
            {/* Upcoming Services end */}
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Home;
