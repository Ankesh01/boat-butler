import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonSpinner, useIonToast,
} from "@ionic/react";

import "./AddBoat.scss";
import Header from "../../components/header/Header";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { AddBoatSchema } from "../../utils/validationschema";
import { add_Boat, IEquipment } from "../../interfaceModules/IBoatInterface";
import {
  downloadFile,
  formatDate,
  formatDBTimestamp,
  getPicture,
  uploadFileOnS3,
} from "../../utils/Helper";
import React, { useEffect, useRef, useState } from "react";
import {
  Engine_hp_option,
  Engine_option,
  Engine_year_option,
} from "../../utils/constants";
import {
  addBoatAction,
  editBoatAction,
  getBoatByIdAction,
  getEngineMakeListAction,
} from "../../redux/action-creators/boat";
import {
  addCircleOutline,
  closeCircleOutline,
  downloadOutline,
} from "ionicons/icons";
import { useHistory, useLocation } from "react-router";
import { RootStateOrAny, useSelector } from "react-redux";
import {deleteFile} from "../../redux/action-creators/FileUpload";

interface ImgeInterface {
  data: string;
  format: string;
}

const AddBoat: React.FC = () => {
  const history = useHistory();
  const location = useLocation();
  const boatId = location.pathname.includes("/edit-boat")
    ? location.pathname.split("/")?.[2]
    : undefined;
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [present, dismiss] = useIonToast();
  const [Img, setImg] = React.useState<any>({
    boat_image: [],
    engine_image: [],
    engine_manual: [],
    equipmentImages: {},
  });
  const [engineMakeList, setEngineMakeList] = useState<
    { _id: string; models?: string[] }[]
  >([]);
  const [engineModalList, setEngineModalList] = useState<string[]>([]);
  const [isOtherMake, setIsOtherMake] = useState(false);
  const [isOtherModel, setIsOtherModel] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const [deletedFiles, setDeletedFile] = useState<string[]>([]);

  const {
    
    control,
    resetField,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<add_Boat>({
    mode: "onChange",
    resolver: yupResolver(AddBoatSchema(isOtherMake, isOtherModel)),
  });
  const inputRef: any = useRef();
  const { fields, append, remove } = useFieldArray({
    control,
    name: "otherEquip",
  });
  const [spin, setSpin] = useState(false);

  useEffect(() => {
    if (boatId) {
      fetchBoatDetail();
    }
    fetchEngineModelData();
  }, []);

  const fetchBoatDetail = async () => {
    const response = await getBoatByIdAction(boatId as string);
    if (response?.data?.data) {
      const boatData = response.data.data;
      let equipmentImages: { string: string[] } | {} = {};
      boatData.other_equipments.map((equipment: IEquipment, index: number) => {
        let newObj = {
          [index]: equipment.img?.map((i: string) => ({ data: i, format: "" })),
        };
        equipmentImages = { ...equipmentImages, ...newObj };
      });
      setImg({
        boat_image: boatData.photos.map((i: string) => ({
          data: i,
          format: "",
        })),
        engine_image: boatData.engine.photos.map((i: string) => ({
          data: i,
          format: "",
        })),
        engine_manual: boatData.engine.manual.map((i: string) => ({
          data: i,
          format: "",
        })),
        equipmentImages: equipmentImages,
      });
      reset({
        title: boatData.title,
        date: formatDBTimestamp(boatData.date_of_bought),
        phone_number: boatData.seller_phone,
        RegId: boatData.registration_id,
        vin: boatData.vin,
        boat_make: boatData.make,
        boat_model: boatData.model,
        year_hull: formatDBTimestamp(boatData.year_of_hull),
        engine_no: boatData.engine.number_of_engines,
        engine_make: boatData.engine.make,
        engine_model: boatData.engine.model,
        engine_hours: boatData.engine.hours,
        engine_year: boatData.engine.year,
        engine_SN: boatData.engine.serial_number,
        otherEquip: boatData.other_equipments,
      });
    }
  };

  const fetchEngineModelData = async () => {
    const response = await getEngineMakeListAction();
    setEngineMakeList([...response?.data?.data, { _id: "other" }]);
  };

  const handleImages = async (
    number: string,
    type: string,
    name: string,
    index?: string
  ) => {
    let images = await getPicture(number, type);
    const temp = { ...Img };
    if (name === "equipmentImages") {
      index = index ? index : "0";
      let indexItems = temp[name][index] ? temp[name][index] : [];
      temp[name] = {
        ...temp[name],
        [index]: [...indexItems, images],
      };
    } else {
      temp[name] = [...temp[name], images];
    }
    setImg(temp);
  };

  const onSubmit = async (data: add_Boat) => {
    let response;
    setButtonDisable(true);
    if (boatId) {
      response = await editBoatAction(boatId as string, {
        ...data,
        ...Img,
        isOtherMake,
        isOtherModel,
        user_id: authData._id,
      });
    } else {
      response = await addBoatAction({
        ...data,
        ...Img,
        isOtherMake,
        isOtherModel,
        user_id: authData._id,
      });
    }

    if (response?.data?.success) {
      if(deletedFiles.length > 0){
        deleteFile(deletedFiles);
      }
      history.goBack();
    }
    setButtonDisable(false);
  };

  const addEquipment = () => {
    append({
      equip_make: "",
      equip_model: "",
      year_bought: "",
      equip_SN: "",
      img: [],
    });
  };

  const removeImageFile = (index: number, name: string) => {
    const img = Img[name];
    let galleryImages = [...img];
    if(name === "engine_manual"){
      let deletedFile = [...galleryImages][index]
      setDeletedFile((prevState) => ([...prevState, deletedFile?.data as string]))
    }
    galleryImages.splice(index, 1);
    setImg((prevState: any) => ({
      ...prevState,
      [name]: galleryImages,
    }));
  };

  const removeEquipmentImage = (imageIndex: number, index: number) => {
    const img = Img.equipmentImages;
    let galleryImages = [img];
    galleryImages[0][index].splice(imageIndex, 1);
    setImg((prevState: any) => ({
      ...prevState,
      equipmentImages: Object.assign(galleryImages[0]),
    }));
  };

  const handleEngineMakeChange = (event: any) => {
    const { value } = event.detail;
    if (value === "other") {
      setIsOtherMake(true);
      setIsOtherModel(true);
      resetField("engine_make");
    } else {
      let modalList = engineMakeList.filter((modal) => modal._id === value)[0];
      setEngineModalList(
        modalList["models"] ? [...modalList["models"], "other"] : ["other"]
      );
    }
  };

  const handleModelChange = (event: any) => {
    const { value } = event.detail;
    if (value === "other") {
      setIsOtherModel(true);
      resetField("engine_model");
    }
  };

  const handleFileUpload = async (event: any) => {
    let { files } = event.target;
    setSpin(true);
    const fileUrlList = await uploadFileOnS3(files, "engine_manual");
    let state = { ...Img };
    state.engine_manual = [
      ...state.engine_manual,
      ...fileUrlList.map((i: string) => ({ data: i, format: "" })),
    ];
    setImg({ ...state });
    setSpin(false);
  };

  const handleDownloadClick = async (data : string) => {
    const fileUri = await downloadFile(data);
    present(`File Downloaded ${fileUri ? `in ${fileUri?.toString()}` : ""}`, 3000)
  }

  return (
    <>
      <Header title={boatId ? "Edit Boat" : "Add New Boat"} />
      <IonContent fullscreen>
        <div className="addboat-page-inner">
          <div className="main-container">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-inner">
                <div className="mb-30">
                  <div className="inner-heading">
                    <h3>{boatId ? "Edit" : "Add New"} Boat Information</h3>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Title</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Title"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="title"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors.title && (
                        <p>{errors?.title?.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>Date Bought</IonLabel>
                    <div className="right-icon-input">
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type="date"
                            className="form-control"
                            placeholder="DD - MM - YYYY"
                            max={formatDate(new Date())}
                            onIonChange={(e) => {
                              field.onChange(e);
                            }}
                          />
                        )}
                        name="date"
                        control={control}
                      />

                      <div className="message error">
                        {errors && errors.date && (
                          <p>{errors?.date?.message}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>Seller’s Phone Number</IonLabel>
                    <Controller
                      render={({ field }) => (
                      
                        <IonInput
                          {...field}
                          type="number"
                          className="form-control"
                          placeholder="Seller’s Phone Number"
                          onIonChange={field.onChange}
                        />
                    
                      )}
                      name="phone_number"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.phone_number && (
                        <p>{errors?.phone_number?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Reg. ID#</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Registration ID"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="RegId"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.RegId && (
                        <p>{errors?.RegId?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>VIN</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="VIN"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="vin"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.vin && <p>{errors?.vin?.message}</p>}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Boat Make</IonLabel>

                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Boat Make"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="boat_make"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.boat_make && (
                        <p>{errors?.boat_make?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Boat Model</IonLabel>

                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Boat Model"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="boat_model"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.boat_model && (
                        <p>{errors?.boat_model?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Year of The Hull</IonLabel>
                    <div className="right-icon-input">
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type="date"
                            className="form-control"
                            placeholder="DD - MM - YYYY"
                            onIonChange={field.onChange}
                            max={formatDate(new Date())}
                          />
                        )}
                        name="year_hull"
                        control={control}
                      />

                      <div className="message error">
                        {errors && errors.year_hull && (
                          <p>{errors?.year_hull?.message}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="form-group">
                    {Img.boat_image.length > 0 &&
                      Img.boat_image.map((i: any, index: number) => (
                        <div key={index} className="upload-image">
                          <IonImg src={i?.data} alt="" />
                          <IonButton
                            className="icon-btn primary-icon-btn"
                            type="button"
                            onClick={() => removeImageFile(index, "boat_image")}
                          >
                            <IonIcon icon={closeCircleOutline} />
                          </IonButton>
                        </div>
                      ))}
                    <div className="file-upload-btn">
                      <IonButton
                        expand="block"
                        className="theme-button dark-outline-btn"
                        onClick={() =>
                          handleImages("single", "base64", "boat_image")
                        }
                      >
                        Add Photos of Boat
                      </IonButton>
                    </div>
                  </div>
                </div>

                <div className="mb-30">
                  <div className="inner-heading">
                    <h3>Add Engine(s)</h3>
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>Type Engine Number</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Type Engine Number"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="engine_no"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.engine_no && (
                        <p>{errors?.engine_no?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Engine Make</IonLabel>
                    {isOtherMake ? (
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type="text"
                            className="form-control"
                            placeholder="Type Engine Make"
                            onIonChange={field.onChange}
                          />
                        )}
                        name="engine_make"
                        control={control}
                      />
                    ) : (
                      <Controller
                        render={({ field }) => (
                          <IonSelect
                            {...field}
                            placeholder="— Select —"
                            className="form-control"
                            onIonChange={(e) => {
                              field.onChange(e);
                              handleEngineMakeChange(e);
                            }}
                            value={field.value}
                          >
                            {engineMakeList.length > 0 &&
                              engineMakeList?.map((engine_make, index) => {
                                return (
                                  <IonSelectOption
                                    key={index}
                                    value={engine_make._id}
                                  >
                                    {engine_make._id}
                                  </IonSelectOption>
                                );
                              })}
                          </IonSelect>
                        )}
                        name={"engine_make"}
                        control={control}
                      />
                    )}

                    {errors && errors.engine_make && (
                      <div className="message error">
                        <p> {errors?.engine_make?.message}</p>
                      </div>
                    )}
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>Engine Model</IonLabel>
                    {isOtherMake || isOtherModel ? (
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type="text"
                            className="form-control"
                            placeholder="Type Engine Model"
                            onIonChange={field.onChange}
                          />
                        )}
                        name="engine_model"
                        control={control}
                      />
                    ) : (
                      <Controller
                        render={({ field }) => (
                          <IonSelect
                            {...field}
                            placeholder="— Select —"
                            className="form-control"
                            onIonChange={(e) => {
                              field.onChange(e);
                              handleModelChange(e);
                            }}
                            value={field.value}
                          >
                            {engineModalList.length > 0 &&
                              engineModalList?.map((engine_model, index) => {
                                return (
                                  <IonSelectOption
                                    key={index}
                                    value={engine_model}
                                  >
                                    {engine_model}
                                  </IonSelectOption>
                                );
                              })}
                          </IonSelect>
                        )}
                        name={"engine_model"}
                        control={control}
                      />
                    )}

                    {errors && errors.engine_model && (
                      <div className="message error">
                        <p> {errors?.engine_model?.message}</p>
                      </div>
                    )}
                  </div>
                  {isOtherModel && (
                    <div>
                      <div className="form-group input-label">
                        <IonLabel>Engine HP</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_hp_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_hp"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_hp && (
                            <p>{errors?.engine_hp?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Engine Dry Weight</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type="text"
                              className="form-control"
                              placeholder="Add Engine Dry Weight"
                              onIonChange={field.onChange}
                            />
                          )}
                          name="engine_dry_weight"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_dry_weight && (
                            <p>{errors?.engine_dry_weight?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Engine Start Type</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_start_type"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_start_type && (
                            <p>{errors?.engine_start_type?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Engine Tilt/Trim</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_tilt_trim"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_tilt_trim && (
                            <p>{errors?.engine_tilt_trim?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Engine Fuel Type</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_fuel_type"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_fuel_type && (
                            <p>{errors?.engine_fuel_type?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Year</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_year_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_year_model"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_year_model && (
                            <p>{errors?.engine_year_model?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-group input-label">
                        <IonLabel>Engine Strock Series</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder="— Select —"
                              className="form-control"
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name="engine_strock_series"
                          control={control}
                        />

                        <div className="message error">
                          {errors && errors.engine_strock_series && (
                            <p>{errors?.engine_strock_series?.message}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  <div className="form-group input-label">
                    <IonLabel>Engine Hours</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Add Hours"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="engine_hours"
                      control={control}
                    />

                    <div className="message error">
                      {errors && errors.engine_hours && (
                        <p>{errors?.engine_hours?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>Engine Year</IonLabel>
                    <div className="right-icon-input">
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type="date"
                            className="form-control"
                            placeholder="DD - MM - YYYY"
                            onIonChange={field.onChange}
                            max={formatDate(new Date())}
                          />
                        )}
                        name="engine_year"
                        control={control}
                      />

                      <div className="message error">
                        {errors && errors.engine_year && (
                          <p>{errors?.engine_year?.message}</p>
                        )}
                      </div>
                      {/* <IonInput
                        type="text"
                        className="form-control"
                        placeholder="DD - MM - YYYY"
                      ></IonInput> */}
                      {/* <a>
                        <IonIcon icon={calendarClearOutline} />
                      </a> */}
                    </div>
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>S/N#</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder="Engine Number"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="engine_SN"
                      control={control}
                    />

                    {errors && errors.engine_SN && (
                      <div className="message error">
                        <p>{errors?.engine_SN?.message}</p>
                      </div>
                    )}

                    {/* <IonInput
                      type="text"
                      className="form-control"
                      placeholder="Engine Number"
                    ></IonInput> */}
                  </div>
                  <div className="form-group">
                    {Img.engine_manual.length > 0 &&
                      Img.engine_manual.map((i: any, index: number) => (
                        <div key={index}>
                          <div className="file-card">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="19.43"
                              height="24"
                              viewBox="0 0 19.43 24"
                            >
                              <path
                                id="Union_22"
                                data-name="Union 22"
                                d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                                transform="translate(-23740.998 -12058.001)"
                              />
                            </svg>

                            <div className="action-btn">
                              <IonButton
                                type="button"
                                className="icon-btn primary-icon-btn "
                                onClick={() => handleDownloadClick(i.data)}
                              >
                                <IonIcon icon={downloadOutline} />
                              </IonButton>
                              <IonButton
                                type="button"
                                className="icon-btn primary-icon-btn "
                                onClick={() =>
                                  removeImageFile(index, "engine_manual")
                                }
                              >
                                <IonIcon icon={closeCircleOutline} />
                              </IonButton>
                            </div>
                          </div>
                        </div>
                        // <div key={index} className="upload-image">
                        //   <div className="file-card">
                        //     <svg
                        //       xmlns="http://www.w3.org/2000/svg"
                        //       width="19.43"
                        //       height="24"
                        //       viewBox="0 0 19.43 24"
                        //     >
                        //       <path
                        //         id="Union_22"
                        //         data-name="Union 22"
                        //         d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                        //         transform="translate(-23740.998 -12058.001)"
                        //       />
                        //     </svg>

                        //     <div className="action-btn">
                        //       <IonButton
                        //         type="button"
                        //         className="icon-btn primary-icon-btn "
                        //         onClick={() => downloadFile(i.data)}
                        //       >
                        //         {/* <IonIcon icon={downloadOutline} /> */}
                        //       </IonButton>
                        //       <IonButton
                        //         type="button"
                        //         className="icon-btn primary-icon-btn "
                        //         onClick={() =>
                        //           removeImageFile(index, "engine_manual")
                        //         }
                        //       >
                        //         <IonIcon icon={closeCircleOutline} />
                        //       </IonButton>
                        //     </div>
                        //   </div>

                        //   {/* <IonImg src={i.data} alt="" /> */}
                        //   {/* <IonButton
                        //     className="icon-btn primary-icon-btn"
                        //     type="button"
                        //     onClick={() =>
                        //       removeImageFile(index, "engine_manual")
                        //     }
                        //   >
                        //     <IonIcon icon={closeCircleOutline} />
                        //   </IonButton> */}
                        // </div>
                      ))}

                    <div className="file-upload-btn">
                      <input
                        type="file"
                        style={{ display: "none" }}
                        ref={inputRef}
                        onChange={handleFileUpload}
                      />
                      <IonButton
                        expand="block"
                        className="theme-button dark-outline-btn"
                        onClick={() => inputRef.current.click()}
                      >
                        Upload Engine Manual
                        {spin && (
                          <span>
                            <IonSpinner />
                          </span>
                        )}
                      </IonButton>
                    </div>
                  </div>
                  <div className="form-group">
                    {Img.engine_image.length > 0 &&
                      Img.engine_image.map((i: any, index: number) => (
                        <div key={index} className="upload-image">
                          <IonImg src={i.data} alt="" />
                          <IonButton
                            className="icon-btn primary-icon-btn"
                            type="button"
                            onClick={() =>
                              removeImageFile(index, "engine_image")
                            }
                          >
                            <IonIcon icon={closeCircleOutline} />
                          </IonButton>
                        </div>
                      ))}
                    <div className="file-upload-btn">
                      <IonButton
                        expand="block"
                        className="theme-button dark-outline-btn"
                        onClick={() =>
                          handleImages("single", "base64", "engine_image")
                        }
                      >
                        Add Photos of Engine
                      </IonButton>
                    </div>
                  </div>
                </div>

                {/* {equip.map((equipment, index) => ( */}
                <div className="mb-30">
                  <div className="inner-heading">
                    <h3>Other Equipment</h3>
                    <IonButton
                      expand="block"
                      className="icon-btn primary-icon-btn"
                      onClick={() => addEquipment()}
                    >
                      <IonIcon icon={addCircleOutline} />
                    </IonButton>
                  </div>

                  {/* <button onClick={() => addEquipment()}>Add</button> */}

                  {fields.map((equipment, index) => (
                    <div key={index}>
                      <div className="form-group input-label">
                        <IonLabel>Equipment Make</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type="text"
                              className="form-control"
                              placeholder="Company Name"
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_make`}
                          control={control}
                        />

                        <div className="message error">
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_make"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_make?.message}
                              </p>
                            )}
                        </div>
                      </div>

                      <div className="form-group input-label">
                        <IonLabel>Equipment Model</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type="text"
                              className="form-control"
                              placeholder="Model Number"
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_model`}
                          control={control}
                        />

                        <div className="message error">
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_model"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_model?.message}
                              </p>
                            )}
                        </div>
                      </div>

                      <div className="form-group input-label">
                        <IonLabel>Year Bought/ Installed</IonLabel>
                        <div className="right-icon-input">
                          <Controller
                            render={({ field }) => (
                              <IonInput
                                {...field}
                                type="date"
                                className="form-control"
                                placeholder="DD - MM - YYYY"
                                onIonChange={field.onChange}
                                max={formatDate(new Date())}
                              />
                            )}
                            name={`otherEquip.${index}.year_bought`}
                            control={control}
                          />
                          {/*     <a>*/}
                          {/*  <IonIcon icon={calendarClearOutline} />*/}
                          {/*</a>*/}
                        </div>
                      </div>

                      <div className="form-group input-label">
                        <IonLabel>S/N#</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type="text"
                              className="form-control"
                              placeholder="Serial Number"
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_SN`}
                          control={control}
                        />

                        <div className="message error">
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_SN"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_SN?.message}
                              </p>
                            )}
                        </div>
                        <div className="form-group">
                          {Img.equipmentImages?.[index.toString()]?.map(
                            (i: any, imageIndex: number) => (
                              <div key={imageIndex} className="upload-image">
                                <IonImg src={i.data} alt="" />
                                <IonButton
                                  className="icon-btn primary-icon-btn"
                                  onClick={() =>
                                    removeEquipmentImage(imageIndex, index)
                                  }
                                >
                                  <IonIcon icon={closeCircleOutline} />
                                </IonButton>
                              </div>
                            )
                          )}
                          <div className="file-upload-btn">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn"
                              onClick={() =>
                                handleImages(
                                  "single",
                                  "base64",
                                  "equipmentImages",
                                  index.toString()
                                )
                              }
                            >
                              Add Equipment Photos
                            </IonButton>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* ))} */}

                  <div className="profile-btn">
                    <IonButton
                      expand="block"
                      className="theme-button primary-btn"
                      onClick={handleSubmit(onSubmit)}
                      disabled={buttonDisable}
                    >
                      Save Boat
                    </IonButton>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default AddBoat;
