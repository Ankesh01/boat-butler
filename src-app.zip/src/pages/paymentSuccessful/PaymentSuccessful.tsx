import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonRow,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";

import "./PaymentSuccessful.scss";
import logo from "../../images/logo.png";

const PaymentSuccessful: React.FC = () => {
  return (
    <IonContent fullscreen>
      <div className="payment-successful-page">
        <div className="main-container">
          <div className="payment-successful-inner">
            <div className="payment-heading">
              <h2>Payment Successful</h2>
              <p>
                Lorem Ipsum has been the industry’s standard dummy text ever
                since the 1500s.
              </p>
            </div>

            <div className="pricing-bottom-btn">
              <IonButton
                expand="block"
                className="theme-button primary-outline-btn right-icon-btn"
              >
                Continue <IonIcon icon={arrowForwardOutline} />
              </IonButton>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default PaymentSuccessful;
