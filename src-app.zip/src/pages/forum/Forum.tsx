import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { IForumInterface } from "../../interfaceModules/IForumInterface";
import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import {
  addNewForumAction,
  getForumListAction,
} from "../../redux/action-creators/forum";
import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";

const Forum: React.FC = () => {
  const { t: translation } = useTranslation();
  const [present, dismiss] = useIonToast();
  const history = useHistory();

  const [forumList, setForumList] = useState<any>([]);
  const [activeId, setActiveId] = useState();
  const [showLoader, setShowLoader] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  let forumArr: any = [];

  useEffect(() => {
    fetchForum();
  }, []);


  const fetchForum = async () => {
    const res = await getForumListAction();
    console.log("res", res);
    setForumList(res?.data?.data);
  };

  const handleForum = (_id: string) => {
    console.log("handle", _id);
    if (!forumArr) {
      forumArr = [];
    }
    if (forumArr.includes(_id)) {
      forumArr.splice(forumArr.indexOf(_id), 1);
    } else {
      forumArr.push(_id);
    }

    console.log("forumArr", forumArr);
  };

  const onSubmit = async () => {
    setShowLoader(true);
    setButtonDisable(true);

    await setForumList((prevState: any) => ({
      ...prevState,
    }));
    const res = await addNewForumAction({
      user_id: authData._id,
    });
    setForumList(res);
    // if (res?.data?.success) {
    //   present(translation("forum_added_successfully"), 2000);
    // }
    // setTimeout(() => history.push("/forum-main"), 2000);

    setShowLoader(false);
    setButtonDisable(false);
  }

    return (
      <>
        <Header />
        <IonContent fullscreen>
          <div className="forum-page">
            <div className="main-container">
              <div className="forum-card">
                <div className="heading">
                  <h4>Please select minimum 3 topic</h4>
                </div>
                <div className="item-list">
                  <ul>
                    {forumList.map((forum: IForumInterface, index: number) => {
                      return (
                        <li key={index}>
                          <a
                            // className="active"
                            className={
                              forumArr.includes(forum._id) ? "active" : ""
                            }
                            // href="javascript:;"
                            onClick={() => {
                              handleForum(forum._id);
                            }}
                          >
                            {forum.title}
                          </a>
                        </li>
                      );
                    })}
                    {/* <li>
                    <a href="javascript:;">News</a>
                  </li>
                  <li>
                    <a href="javascript:;">IT</a>
                  </li> */}
                    {/* <li>
                    <a href="javascript:;">Boat</a>
                  </li>
                  <li>
                    <a href="javascript:;">Yamaha Boat EX56</a>
                  </li>
                  <li>
                    <a href="javascript:;">Boat 2021</a>
                  </li>
                  <li>
                    <a href="javascript:;">Boat MK2YU</a>
                  </li>
                  <li>
                    <a href="javascript:;">Suzuki H6</a>
                  </li>
                  <li>
                    <a href="javascript:;">Engine Master</a>
                  </li>
                  <li>
                    <a href="javascript:;">Music</a>
                  </li> */}
                  </ul>
                </div>
              </div>
              <div>
                <IonButton
                  expand="block"
                  className="theme-button primary-btn"
                  onClick={onSubmit}
                >
                  Save
                </IonButton>
              </div>
            </div>
          </div>
        </IonContent>
      </>
    );
  };


export default Forum;
