import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonTextarea,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  arrowRedoOutline,
  bookmarkOutline,
  calendarClearOutline,
  cameraOutline,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
  thumbsUpOutline,
} from "ionicons/icons";

import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import topicImg from "../../images/topic-img.jpg";
import userPlaceholder from "../../images/user-placeholder.jpeg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const PostShare: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            {/* post-input start */}
            <div className="post-input mb-30">
              <div className="form-group input-label">
                <IonLabel>Title</IonLabel>
                <IonTextarea
                  rows={18}
                  className="form-control"
                  placeholder="Add your text here…"
                ></IonTextarea>
              </div>
              {/* topic-card start */}
              <div className="topic-card topic-card-border">
                <div className="card-head">
                  <div className="heading">
                    <div className="user-img">
                      <IonImg src={userPlaceholder} />
                    </div>
                    <div className="heading-inner">
                      <h5>
                        Post by: <span>Lori H. Flores</span>
                      </h5>
                      <p>Jan 12, 2021 at 10:30 AM</p>
                    </div>
                  </div>
                </div>

                <div className="card-mid">
                  <div className="content">
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry.
                    </p>
                  </div>
                  <div className="topic-img">
                    <IonImg src={topicImg} />
                  </div>
                </div>

                <div className="card-bottom">
                  <div className="links">
                    <ul className="justify-content-start">
                      <li>
                        <Link to="/">
                          <IonIcon icon={chatboxOutline} /> 7.9K
                        </Link>
                      </li>
                      <li>
                        <Link to="/">
                          <IonIcon icon={thumbsUpOutline} />
                          7.9K
                        </Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              {/* topic-card end */}
            </div>
            {/* post-input end */}
            <div>
              <IonButton expand="block" className="theme-button primary-btn">
                Share
              </IonButton>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default PostShare;
