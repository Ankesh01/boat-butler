import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonTextarea,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  arrowRedoOutline,
  bookmark,
  bookmarkOutline,
  calendarClearOutline,
  cameraOutline,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
  thumbsUpOutline,
} from "ionicons/icons";

import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import topicImg from "../../images/topic-img.jpg";
import userPlaceholder from "../../images/user-placeholder.jpeg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const SavedPost: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            {/* post-card */}
            <div className="post-card">
              <div className="card-inner">
                <IonGrid>
                  <IonRow>
                    <IonCol size="7">
                      <div className="post-detail">
                        <div className="time">
                          <span>
                            <IonIcon icon={bookmark} /> Jan 29, 2021
                          </span>
                        </div>
                        <div className="brif">
                          <h3>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry.
                          </h3>
                          <p>
                            The point of using Lorem Ipsum is that it has a
                            more-or-less normal distribution of letters, as
                            opposed to using ‘Content here, content here’…
                          </p>
                        </div>
                      </div>
                    </IonCol>
                    <IonCol size="5">
                      <div className="post-img">
                        <IonImg src={topicImg} />
                      </div>
                    </IonCol>

                    <IonCol size="6">
                      <div className="status-info">
                        <p>
                          Comments: <span>7.9K</span>
                        </p>
                        <p>
                          Likes: <span>27.3K</span>
                        </p>
                      </div>
                    </IonCol>
                    <IonCol size="6">
                      <div className="post-time">
                        <p>Post: Jan 12, 2021 at 10:30 AM</p>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>

            {/* post-card */}
            <div className="post-card">
              <div className="card-inner">
                <IonGrid>
                  <IonRow>
                    <IonCol size="7">
                      <div className="post-detail">
                        <div className="time">
                          <span>
                            <IonIcon icon={bookmark} /> Jan 29, 2021
                          </span>
                        </div>
                        <div className="brif">
                          <h3>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry.
                          </h3>
                          <p>
                            The point of using Lorem Ipsum is that it has a
                            more-or-less normal distribution of letters, as
                            opposed to using ‘Content here, content here’…
                          </p>
                        </div>
                      </div>
                    </IonCol>
                    <IonCol size="5">
                      <div className="post-img">
                        <IonImg src={topicImg} />
                      </div>
                    </IonCol>

                    <IonCol size="6">
                      <div className="status-info">
                        <p>
                          Comments: <span>7.9K</span>
                        </p>
                        <p>
                          Likes: <span>27.3K</span>
                        </p>
                      </div>
                    </IonCol>
                    <IonCol size="6">
                      <div className="post-time">
                        <p>Post: Jan 12, 2021 at 10:30 AM</p>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>

            {/* post-card */}
            <div className="post-card">
              <div className="card-inner">
                <IonGrid>
                  <IonRow>
                    <IonCol size="7">
                      <div className="post-detail">
                        <div className="time">
                          <span>
                            <IonIcon icon={bookmark} /> Jan 29, 2021
                          </span>
                        </div>
                        <div className="brif">
                          <h3>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry.
                          </h3>
                          <p>
                            The point of using Lorem Ipsum is that it has a
                            more-or-less normal distribution of letters, as
                            opposed to using ‘Content here, content here’…
                          </p>
                        </div>
                      </div>
                    </IonCol>
                    <IonCol size="5">
                      <div className="post-img">
                        <IonImg src={topicImg} />
                      </div>
                    </IonCol>

                    <IonCol size="6">
                      <div className="status-info">
                        <p>
                          Comments: <span>7.9K</span>
                        </p>
                        <p>
                          Likes: <span>27.3K</span>
                        </p>
                      </div>
                    </IonCol>
                    <IonCol size="6">
                      <div className="post-time">
                        <p>Post: Jan 12, 2021 at 10:30 AM</p>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default SavedPost;
