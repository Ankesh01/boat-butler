import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const ForumMain: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            <form>
              <div className="form-group">
                <IonSelect
                  className="form-control primary-control"
                  interface="popover"
                  placeholder="— Select —"
                >
                  <IonSelectOption value="Loream Ipusme">
                    Loream Ipusme
                  </IonSelectOption>
                  <IonSelectOption value="Loream Ipusme">
                    Loream Ipusme
                  </IonSelectOption>
                </IonSelect>
              </div>

              <div>
                {/* news-card start */}
                <div className="news-card">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="7">
                        <div className="content">
                          <div className="date">
                            <span>Post: Jan 12, 2021 at 10:30 AM</span>
                          </div>
                          <div className="brif">
                            <p>
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry.
                            </p>
                          </div>
                          <div className="status">
                            <p>
                              Comment:
                              <span>7.9K</span>
                            </p>
                            <p>
                              Like:
                              <span>27.3K</span>
                            </p>
                          </div>
                        </div>
                      </IonCol>
                      <IonCol size="5">
                        <div className="card-img">
                          <IonImg src={boatGalleryImg} />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>
                {/* news-card end */}
                {/* news-card start */}
                <div className="news-card">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="7">
                        <div className="content">
                          <div className="date">
                            <span>Post: Jan 12, 2021 at 10:30 AM</span>
                          </div>
                          <div className="brif">
                            <p>
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry.
                            </p>
                          </div>
                          <div className="status">
                            <p>
                              Comment:
                              <span>7.9K</span>
                            </p>
                            <p>
                              Like:
                              <span>27.3K</span>
                            </p>
                          </div>
                        </div>
                      </IonCol>
                      <IonCol size="5">
                        <div className="card-img">
                          <IonImg src={boatGalleryImg} />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>
                {/* news-card end */}
                {/* news-card start */}
                <div className="news-card">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="7">
                        <div className="content">
                          <div className="date">
                            <span>Post: Jan 12, 2021 at 10:30 AM</span>
                          </div>
                          <div className="brif">
                            <p>
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry.
                            </p>
                          </div>
                          <div className="status">
                            <p>
                              Comment:
                              <span>7.9K</span>
                            </p>
                            <p>
                              Like:
                              <span>27.3K</span>
                            </p>
                          </div>
                        </div>
                      </IonCol>
                      <IonCol size="5">
                        <div className="card-img">
                          <IonImg src={boatGalleryImg} />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>
                {/* news-card end */}
                {/* news-card start */}
                <div className="news-card">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="7">
                        <div className="content">
                          <div className="date">
                            <span>Post: Jan 12, 2021 at 10:30 AM</span>
                          </div>
                          <div className="brif">
                            <p>
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry.
                            </p>
                          </div>
                          <div className="status">
                            <p>
                              Comment:
                              <span>7.9K</span>
                            </p>
                            <p>
                              Like:
                              <span>27.3K</span>
                            </p>
                          </div>
                        </div>
                      </IonCol>
                      <IonCol size="5">
                        <div className="card-img">
                          <IonImg src={boatGalleryImg} />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>
                {/* news-card end */}
              </div>
            </form>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ForumMain;
