import {
  InputChangeEventDetail,
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonTextarea,
  TextareaChangeEventDetail,
} from "@ionic/react";
import { Link } from "react-router-dom";
import {
  likePostAction,
  unlikePostAction,
} from "../../redux/action-creators/postsAction";
import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  arrowRedoOutline,
  bookmarkOutline,
  bookmarkSharp,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  flagOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
  thumbsUpOutline,
  thumbsUpSharp,
  sendOutline,
} from "ionicons/icons";
import React, { useEffect, useRef, useState } from "react";
import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";
import topicImg from "../../images/topic-img.jpg";
import userPlaceholder from "../../images/user-placeholder.jpeg";
import { getPostById } from "../../redux/action-creators/postsAction";
import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { useHistory, useLocation } from "react-router";
import moment from "moment";
import { RootStateOrAny, useSelector, useDispatch } from "react-redux";
import {
  postCommentAction,
  getCommentAction,
} from "../../redux/action-creators/comment";

interface IUserinfo {
  account_type?: string;
  address_line_1?: string;
  address_line_2?: string;
  city?: string;
  country?: string;
  created_ts: Date;
  email?: string;
  encOtp?: string;
  fcm_token?: string;
  gender?: string;
  image?: string;
  is_active?: number;
  is_verified?: number;
  name: string;
  password?: string;
  phone?: number;
  state?: string;
  timezone?: string;
  updated_ts?: string;
  zipcode?: number;
}

interface IPostInfo {
  created_ts?: string;
  _id: string;
  description?: string;
  status?: string;
  title?: string;
  type?: string;
  post_comments?:any;
  type_item_id?: string;
  media_file?: string;
  total?: any;
  user_id?:string
}

interface ICommentInterface {
  user_id?: string;
  comment?: string;
  post_id?: string;
  status?: string;
  total?: { like: string; reported: string };
  _id: string;
}

export interface IGetCommentInterface {
  _id: string;
  user_id: string;
  comment: string;
  post_id: string;
  status: string;
  total: any;
  userInfo?: any;
  created_ts: Date;
  updated_ts: string;
}

const ForumTopic: React.FC = () => {
  const now = moment();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  console.log("authData", authData);
  const location = useLocation();
  const postId = location.pathname.includes("/post-detail")
    ? location.pathname.split("/")?.[2]
    : undefined;

  const [comment, setComment] = useState<string>();
  const [postInfo, setPostInfo] = useState<IPostInfo[]>([]);
  const [userInfo, setUserInfo] = useState<IUserinfo[]>([]);
  const [data, setData] = useState<ICommentInterface[]>([]);
  const [postCommentInfo, setPostCommentInfo] = useState<
    IGetCommentInterface[]
  >([]);
  let [errorMessage, setErrorMessage] = useState({
    comment: "",
  });


  useEffect(() => {
    if (postId) {
      fetchPostDetail();
    }
    getComment();
  }, []);

  const getDaysDifferenceFromToday = (fromDate: Date) => {
    const date1 = new Date(fromDate);
    const milliSec = Math.abs(date1.getTime() - Date.now());
    return Math.floor(milliSec / (24 * 60 * 60 * 1000));
  };

  const fetchPostDetail = async () => {
    const response = await getPostById(postId as string);
    if (response?.data?.data.length > 0) {
      setPostInfo(response?.data?.data);
      setUserInfo(response?.data?.data[0]?.userInfo);
    }
  };

  // const handleChange = (
  //   event:
  //     | CustomEvent<InputChangeEventDetail>
  //     | CustomEvent<TextareaChangeEventDetail>,

  // ) => {
  //   let target = event.target as HTMLSelectElement;

  //   setErrorMessage((prevState) => ({
  //     ...prevState,
  //      undefined,
  //   }));

  //   setComment(target.value);

  // };

  const handleChange = async (event: CustomEvent<InputChangeEventDetail>) => {
    event.preventDefault();
    let target = event.target as HTMLSelectElement;

    setComment(target.value);
  };

  const postComment = async () => {
    const response = await postCommentAction({
      ...data,
      user_id: authData._id,
      post_id: postId,
      comment: comment,
      status: "Active",
    });
    getComment();
    setComment("");
    fetchPostDetail();
   
  };

  const getComment = async () => {
    const result = await getCommentAction({ ...data, post_id: postId });
    console.log(result);
    if (result?.data?.data.length > 0) {
      setPostCommentInfo(result?.data?.data);
    }
  };
  const handleUnLike = async (_id: string, type: string) => {
    console.log("handleUnLike--_id", _id);
    console.log("handleUnLike--type", type);
    if(type === "post" || type==="bookmark"){
  let response = await unlikePostAction({
      _id: _id,
      userId: authData._id,
      type,
    });
    console.log("response unlikePostAction", response);
    fetchPostDetail();
      // setPostInfo((prevState:any) => ([...prevState, {total:response?.data?.data?.total}]))
     //  setPostInfo((prevState:any)=>{...prevState,response?.data?.data?.total});
   }
   else if(type ==="comment"){
     let response = await unlikePostAction({
      _id: _id,
      userId: authData._id,
      type,
    });
    console.log("response unlikePostAction", response);
    getComment()
   }

  };

  const handleLike = async (_id: string, type: string) => {
    
    console.log("handleLike--_id", _id);
    console.log("handleLike--type", type);
    if(type === "post" || type==="bookmark"){
       let response = await likePostAction({ _id: _id, userId: authData._id,type });
       fetchPostDetail();
      //  setPostInfo((prevState:any) => ([...prevState, {total:response?.data?.data?.total}]))
      
    }
    else if(type ==="comment"){
    let response = await likePostAction({ _id: _id, userId: authData._id,type });
    // setPostLike(response?.data?.data?.total);
    getComment()
    }
  };
  return (
    <>
      <Header />
      <IonContent fullscreen>
        {console.log("postResponse", postCommentInfo)}
        <div className="forum-page">
          <div className="main-container">
            {/* topic-card start */}
            <div className="topic-card">
              <div className="card-head">
                {userInfo.length > 0
                  ? userInfo.map((item: any, index) => (
                      <div className="heading">
                        <h5>
                          Post by: <span>{item?.name ? item?.name : ""}</span>
                        </h5>
                        <p>
                          {"   "}
                          {moment(postInfo[0].created_ts).format(
                            "MMM DD, YYYY"
                          )}{" "}
                          at {moment(postInfo[0].created_ts).format("hh:m A")}
                        </p>
                      </div>
                    ))
                  : ""}

                <div className="card-head-btn">
                  <Link to="/" className="link-icon-btn tertiary-btn">
                    <IonIcon icon={ellipsisHorizontalCircleOutline} />
                    
                  </Link>
                  {postInfo[0]?.user_id === authData._id ? 
                      <IonButton
                      className="icon-btn primary-icon-btn"
                      type="button"
                      // onClick={() => handleUnLike(postInfo[0]._id, "post")}
                    >
                      <IonIcon icon={pencilOutline} />
                      Edit
                    </IonButton>
                  :
                  <IonButton
                  className="icon-btn primary-icon-btn"
                  type="button"
                  // onClick={() => handleUnLike(postInfo[0]._id, "post")}
                >
                  <IonIcon icon={flagOutline} />
                  Report
                </IonButton>
                  }
                </div>
              </div>

              <div className="card-mid">
                <div className="content">
                  <p>
                    {postInfo[0]?.description ? postInfo[0]?.description : ""}
                  </p>
                </div>
                <div className="topic-img">
                  <IonImg
                    src={postInfo[0]?.media_file ? postInfo[0]?.media_file : ""}
                  />
                </div>
              </div>

              <div className="card-bottom">
                <div className="links">
                  <ul>
                    <li>
                      <Link to="/">
                        <IonIcon icon={chatboxOutline} /> 
                        {postInfo[0]?.post_comments?.length}
                      </Link>
                    </li>
                    {/* <li>
                      <Link to="/">
                        <IonIcon icon={thumbsUpOutline} />0
                      </Link>
                    </li> */}
                    {console.log("PostInfo---", postInfo)}
                    <li>
                      {postInfo[0]?.total?.like?.includes(authData._id) ? (
                        <IonButton
                          className="icon-btn primary-icon-btn"
                          type="button"
                          onClick={() => handleUnLike(postInfo[0]._id, "post")}
                        >
                          <IonIcon icon={thumbsUpSharp} />
                        </IonButton>
                      ) : (
                        <IonButton
                          className="icon-btn primary-icon-btn"
                          type="button"
                          onClick={() => handleLike(postInfo[0]._id, "post")}
                        >
                          <IonIcon icon={thumbsUpOutline} />
                        </IonButton>
                      )}
                      {postInfo[0]?.total?.like?.length}
                    </li>
                    <li>
                      {postInfo[0]?.total?.bookmarks?.includes(authData._id) ? (
                        <IonButton
                          className="icon-btn primary-icon-btn"
                          type="button"
                          onClick={() => handleUnLike(postInfo[0]._id, "bookmark")}
                        >
                          <IonIcon icon={bookmarkSharp} />
                        </IonButton>
                      ) : (
                        <IonButton
                          className="icon-btn primary-icon-btn"
                          type="button"
                          onClick={() => handleLike(postInfo[0]._id, "bookmark")}
                        >
                          <IonIcon icon={bookmarkOutline} />
                        </IonButton>
                      )}
                     
                    </li>
                    {/* <li>
                      <Link to="/">
                        <IonIcon icon={bookmarkOutline} />
                        7.9K
                      </Link>
                    </li> */}
                    <li>
                      <Link to="/">
                        <IonIcon icon={arrowRedoOutline} />
                        7.9K
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            {/* topic-card end */}

            {/* Comment start */}
            <div className="comment-section">
              {/* comment-input */}
              <div className="form-group comment-input">
                <IonLabel>
                  Comment as <span>{authData?.name ? authData?.name : ""}</span>
                </IonLabel>
                <div className="comment-input-control">
                  <IonInput
                    className="form-control"
                    placeholder="What are you thoughts?"
                    value={comment}
                    onIonChange={(e) => handleChange(e)}
                  ></IonInput>
                  <IonButton
                    type="button"
                    className="send-btn theme-button dark-btn"
                    onClick={() => postComment()}
                  >
                    <IonIcon icon={sendOutline} />
                  </IonButton>
                </div>
              </div>
              {console.log("postCommentInfo", postCommentInfo)}
              <div className="comment-list">
                {/* comment-item */}
                {postCommentInfo.length > 0 ? (
                  postCommentInfo.map((comment, index) =>
                    now.isAfter(comment.created_ts) ? (
                      <div className="comment-item">
                        <div className="user-img">
                          <IonImg src={comment?.userInfo[0]?.image} />
                        </div>
                        <div className="comment-detail">
                          <div className="name">
                            <h5>
                              {comment?.userInfo[0]?.name}
                              <span className="date">
                                {getDaysDifferenceFromToday(comment.created_ts) ==
                                0 ? (
                                  "today"
                                ) : (
                                  <>
                                    {getDaysDifferenceFromToday(
                                      comment.created_ts
                                    )}{" "}
                                    <span>days ago</span>
                                  </>
                                )}{" "}
                              </span>
                            </h5>
                          </div>
                          <div className="brif">
                            <p>{comment?.comment}</p>
                          </div>
                          <div className="links">
                            <ul>
                              <li>
                                <Link to="/">
                                  <IonIcon icon={chatboxOutline} />0
                                </Link>
                              </li>
                              <li>
                                {comment?.total?.like?.includes(
                                  authData._id
                                ) ? (
                                  <IonButton
                                    className="icon-btn primary-icon-btn"
                                    type="button"
                                    onClick={() =>
                                      handleUnLike(
                                        comment?._id,
                                        "comment"
                                      )
                                    }
                                  >
                                    <IonIcon icon={thumbsUpSharp} />
                                  </IonButton>
                                ) : (
                                  <IonButton
                                    className="icon-btn primary-icon-btn"
                                    type="button"
                                    onClick={() =>
                                      handleLike(
                                        comment._id,
                                        "comment"
                                      )
                                    }
                                  >
                                    <IonIcon icon={thumbsUpOutline} />
                                  </IonButton>
                                )}
                                {comment?.total?.like?.length}
                              </li>

                              <li>
                                <Link to="/">
                                  <IonIcon icon={arrowRedoOutline} />
                                  7.9K
                                </Link>
                              </li>
                              <li>
                                <Link to="/">
                                  <IonIcon icon={flagOutline} />
                                  7.9K
                                </Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )
                  )
                ) : (
                  <span>No Comments</span>
                )}
              </div>
            </div>
            {/* Comment start */}
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ForumTopic;
