import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonTextarea,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  calendarClearOutline,
  cameraOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Forum.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const AddTopic: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            <div className="form-group input-label">
              <IonLabel>Title</IonLabel>
              <IonInput
                type="text"
                className="form-control"
                placeholder="Lorem Ipsum is simply"
              ></IonInput>
            </div>
            <div className="form-group input-label">
              <IonLabel>Description</IonLabel>
              <IonTextarea
                rows={18}
                className="form-control"
                placeholder="Lorem Ipsum is simply"
              ></IonTextarea>
            </div>

            <div className="form-group mb-30">
              <IonLabel>Add Media</IonLabel>
              <div className="file-upload-card">
                <div className="card-inner">
                  <IonIcon icon={cameraOutline} />
                  <p>Tap to upload</p>
                </div>
                <input className="file-input" type="file"></input>
              </div>
            </div>
            
            <div>
              <IonButton expand="block" className="theme-button primary-btn">
                Create
              </IonButton>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default AddTopic;
