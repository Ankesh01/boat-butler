import {
  InputChangeEventDetail,
  IonButton,
  IonContent,
  IonImg,
  IonInput,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  useIonToast,
} from "@ionic/react";

import "./Reminders.scss";
import calendarIcon from "../../images/calendar-icon.svg";
import clockIcon from "../../images/clock-icon.svg";
import repeatIcon from "../../images/repeat-icon.svg";

import Header from "../../components/header/Header";
import { formatDate } from "../../utils/Helper";
import React, { useRef, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";
import { addNewReminderAction } from "../../redux/action-creators/reminder";
import { Priority_Reminder, Repeat_Reminder } from "../../utils/constants";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import moment from "moment";
import {
  IReminderErrorMessage,
  ISubReminder,
} from "../../interfaceModules/IReminderInterface";
import { number } from "yup/lib/locale";

const NewReminder: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [reminder, setReminder] = useState<ISubReminder>({
    date: "",
    end_time: "",
    notes: "",
    priority: "",
    repeat: "",
    start_time: "",
    title: "",
    due_start_datetime: "",
    due_end_datetime: "",
  });
  const [showLoader, setShowLoader] = useState(false);
  const [present, dismiss] = useIonToast();
  const [buttonDisable, setButtonDisable] = useState(false);

  let [errorMessage, setErrorMessage] = useState<IReminderErrorMessage>({
    title: "",
    notes: "",
    date: "",
    start_time: "",
    end_time: "",
    repeat: "",
    priority: "",
  });
  let now = new Date();
  // console.log(
  //   "reminder--",
  //   moment.utc(reminder.start_time).format("DD-MM-YYYY HH:mm:ss")
  // );0

  let due_end_datetime = moment
    .utc(new Date(reminder.date + " " + reminder.end_time))
    .local()
    .format();
  // const due_start_datetime = moment
  //   .utc(new Date(reminder.date + " " + reminder.start_time))
  //   .local()
  //   .format();
  console.log("due_end_datetime", due_end_datetime);
  // let dateTime = new Date(reminder.date + " " + reminder.start_time);
  // let EndDateTime = new Date(reminder.date + " " + reminder.end_time);
  // const local = moment.utc(dateTime).local().format();
  // console.log(local, "- UTC now to dateTime");

  // moment(local).toISOString(true);
  const validateUserInfo = () => {
    let isFormValid = true;

    if (reminder.title == null || reminder.title == "") {
      isFormValid = false;
      errorMessage.title = "Title is required";
    }
    if (reminder.notes == null || reminder.notes == "") {
      isFormValid = false;
      errorMessage.notes = "Notes is required";
    }

    if (reminder.date == null || reminder.date == "") {
      isFormValid = false;
      errorMessage.date = "Date is required";
    }

    if (reminder.start_time == null || reminder.start_time == "") {
      isFormValid = false;
      errorMessage.start_time = "Start Time is required";
    }
    if (reminder.end_time == null || reminder.end_time == "") {
      isFormValid = false;
      errorMessage.end_time = "End Time is required";
    } else if (
      moment(reminder.end_time, "hh:mm") < moment(reminder.start_time, "hh:mm")
    ) {
      isFormValid = false;
      errorMessage.end_time = "End time should be more than start time!";
    }
    if (reminder.repeat == null || reminder.repeat == "") {
      isFormValid = false;
      errorMessage.repeat = "Repeat is required";
    }
    if (reminder.priority == null || reminder.priority == "") {
      isFormValid = false;
      errorMessage.priority = "Priority is required";
    }

    setReminder((prevState) => ({
      ...prevState,
    }));
    return isFormValid;
  };

  const handleStateChange = (
    e: CustomEvent<InputChangeEventDetail>,
    name: string
  ) => {
    let target = e.target as HTMLSelectElement;
    if (errorMessage) {
      setErrorMessage((prevState) => ({
        ...prevState,
        [name]: undefined,
      }));
    }
    setReminder((prevState) => ({
      ...prevState,
      [name]: target.value,
    }));
  };

  const onSubmit = async () => {
    setShowLoader(true);
    setButtonDisable(true);

    await setReminder((prevState) => ({
      ...prevState,
      errormessage: "",
    }));
    if (validateUserInfo()) {
      const due_end_datetime = moment
        .utc(new Date(reminder.date + " " + reminder.end_time))
        .format();
      const due_start_datetime = moment
        .utc(new Date(reminder.date + " " + reminder.start_time))
        .format();
      const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      let body = {
        ...reminder,
        due_start_datetime: due_start_datetime,
        due_end_datetime: due_end_datetime,
      };

      setReminder(body);

      const res = await addNewReminderAction({
        userId: authData._id,
        reminder: body,
        timezone,
      });
      if (res?.data?.success) {
        present(translation("new_reminder_added_successfully"), 2000);
      }
      setTimeout(() => history.push("/reminders"), 2000);
    }

    setShowLoader(false);
    setButtonDisable(false);
  };

  console.log("reminder ------ ", reminder);
  return (
    <>
      <Header title={"Details"} />
      <IonContent fullscreen>
        <div className="reminders-page">
          <div className="main-container">
            {/* reminder-card */}
            <div className="reminder-card">
              <div className="action-item-list">
                {/* item */}
                <div className="action-item">
                  <IonInput
                    type="text"
                    className="form-control color-primary"
                    placeholder="New Reminder"
                    onIonChange={(e) => handleStateChange(e, "title")}
                  />
                  <div className="message error">
                    {errorMessage && errorMessage?.title && (
                      <p>{errorMessage?.title}</p>
                    )}
                  </div>
                </div>
                {/* item */}
                <div className="action-item">
                  <div className="action-input w-100">
                    <div className="form-group">
                      <IonInput
                        type="text"
                        className="form-control"
                        placeholder="Notes"
                        onIonChange={(e) => handleStateChange(e, "notes")}
                      />
                      <div className="message error">
                        {errorMessage && errorMessage?.notes && (
                          <p>{errorMessage?.notes}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <div className="action-item-list">
                {/* item */}
                <div className="action-item">
                  <div className="name">
                    <p>
                      <IonImg src={calendarIcon} />
                      {translation("date")}
                    </p>
                  </div>
                  <div className="action-input">
                    <div className="form-group">
                      <IonInput
                        type="date"
                        className="form-control"
                        placeholder="DD - MM - YYYY"
                        min={formatDate(new Date())}
                        onIonChange={(e) => handleStateChange(e, "date")}
                      />
                      <div className="message error">
                        {errorMessage && errorMessage?.date && (
                          <p>{errorMessage?.date}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="action-item">
                  <div className="name">
                    <p>
                      <IonImg src={clockIcon} />
                      {translation("start_time")}
                    </p>
                  </div>
                  <div className="action-input">
                    <div className="form-group">
                      <IonInput
                        type="time"
                        className="form-control"
                        placeholder="DD - MM - YYYY"
                        onIonChange={(e) => handleStateChange(e, "start_time")}
                      />
                      <div className="message error">
                        {errorMessage && errorMessage?.start_time && (
                          <p>{errorMessage?.start_time}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="action-item">
                  <div className="name">
                    <p>
                      <IonImg src={clockIcon} />
                      {translation("end_time")}
                    </p>
                  </div>
                  <div className="action-input">
                    <div className="form-group">
                      <IonInput
                        type="time"
                        className="form-control"
                        placeholder="DD - MM - YYYY"
                        onIonChange={(e) => handleStateChange(e, "end_time")}
                      />
                      <div className="message error">
                        {errorMessage && errorMessage?.end_time && (
                          <p>{errorMessage?.end_time}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <div className="action-item-list">
                {/* item */}
                <div className="action-item">
                  <div className="name">
                    <p>
                      <IonImg src={repeatIcon} />
                      {translation("repeat")}
                    </p>
                  </div>
                  <div className="action-input">
                    <IonSelect
                      placeholder="Select Snoozer"
                      className="form-control"
                      onIonChange={(e) => handleStateChange(e, "repeat")}
                    >
                      {Repeat_Reminder.map((name: number) => (
                        <IonSelectOption key={name} value={name}>
                          {name} Minutes
                        </IonSelectOption>
                      ))}{" "}
                    </IonSelect>
                    <div className="message error">
                      {errorMessage && errorMessage?.repeat && (
                        <p>{errorMessage?.repeat}</p>
                      )}
                    </div>
                    {/* <IonIcon icon={chevronForwardOutline} /> */}
                  </div>
                </div>
              </div>
            </div>

            {/* reminder-card */}
            <div className="reminder-card">
              <div className="action-item-list">
                {/* item */}
                <div className="action-item">
                  <div className="name">
                    <p>
                      <IonImg src={repeatIcon} />
                      {translation("priority")}
                    </p>
                  </div>
                  <div className="action-input">
                    <IonSelect
                      placeholder="Select Priority"
                      className="form-control"
                      onIonChange={(e) => handleStateChange(e, "priority")}
                    >
                      {Priority_Reminder.map((name: string) => (
                        <IonSelectOption key={name} value={name}>
                          {name}
                        </IonSelectOption>
                      ))}{" "}
                    </IonSelect>
                    <div className="message error">
                      {errorMessage && errorMessage?.priority && (
                        <p>{errorMessage?.priority}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <IonButton
              expand="block"
              className="theme-button primary-btn"
              onClick={onSubmit}
              disabled={buttonDisable}
            >
              {translation("save")}
              {showLoader ? <IonSpinner /> : null}
            </IonButton>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default NewReminder;
