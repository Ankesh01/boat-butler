import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides, IonSpinner,
} from "@ionic/react";
import {Link, useHistory} from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Services.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import React, {useEffect, useState} from "react";
import {RootStateOrAny, useSelector} from "react-redux";
import {getBoatServicesByUserId} from "../../redux/action-creators/boatServices";
import {IServiceInterface} from "../../interfaceModules/IServiceInterface";
import {newDateWithoutTime} from "../../utils/Helper";
import ServiceCard from "../../components/ServiceCard";

const UpcomingServices: React.FC = () => {
  const history = useHistory();
  const authData = useSelector(
      (state: RootStateOrAny) => state.authReducer.user
  );
  const [selectedDate, setSelectedDate] = useState(newDateWithoutTime());
  const [serviceList, setServiceList] = useState<IServiceInterface[]>([]);
  const [showLoader, setShowLoader] = useState(false)

  useEffect(()=>{
    fetchServices();
  },[selectedDate])

  const fetchServices = async () => {
    setShowLoader(true)
    const response = await getBoatServicesByUserId(authData._id, {date : selectedDate})
    if(response?.data?.data){
      setServiceList(response?.data?.data)
    }
    setShowLoader(false)
  }

  const showDate = () => {
    let string = selectedDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
    return string
  }

  return (
    <>
      <Header title={"Upcoming Services"}/>
      <IonContent fullscreen>
        <div className="upcomingservices-page-inner">
          {/* services-filter start */}
          <div className="services-filter">
            <div className="filter-body">
              <div className="upcoming-calendar">
                <ThemeCalendar
                    value={selectedDate}
                    onChange={(e : any)=> setSelectedDate(new Date(e))}
                />
              </div>
            </div>
            <div className="filter-bottom">
              <div className="main-container">
                <IonGrid className="p-0">
                  <IonRow className="align-items-center">
                    <IonCol size="6">
                      <div className="heading">
                        <h4>Upcoming Services</h4>
                      </div>
                    </IonCol>
                    {/*<IonCol size="6">
                      <div className="tab-menu">
                        <ul>
                          <li>
                            <Link to="/" className="active">
                              Day
                            </Link>
                          </li>
                          <li>
                            <Link to="/">Week</Link>
                          </li>
                          <li>
                            <Link to="/">Month</Link>
                          </li>
                        </ul>
                      </div>
                    </IonCol>*/}
                  </IonRow>
                </IonGrid>
              </div>
            </div>
          </div>
          {/* services-filter end */}

          {/* Upcoming Services start */}
          <div className="upcoming-services">
            <div className="main-container">
              <div className="heading">
                <h4>
                  <span> {showDate()}</span>
                </h4>
              </div>
              <div className="upcoming-services-inner">
                {/* card start */}
                {
                  showLoader ?
                      <IonSpinner/>
                      :
                      serviceList.length > 0 ?
                      serviceList.map((service, index) =>
                  <ServiceCard
                      serviceData={service}
                      key={index}
                  />)
                          :
                          <p>No Services found!</p>
                }
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}
        </div>
        {/* fab */}
        <IonFab slot="fixed" horizontal="end" vertical="bottom">
          <IonFabButton
              className="theme-fab-btn primary-btn"
              onClick={() =>history.push("/new-services")}
          >
            <IonIcon icon={addOutline} />
          </IonFabButton>
        </IonFab>
      </IonContent>
    </>
  );
};

export default UpcomingServices;
