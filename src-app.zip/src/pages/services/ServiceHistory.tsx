import React, { useRef } from "react";
import {
  IonButton,
  IonCheckbox,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonLabel,
  IonRow,
  IonSpinner,
  useIonToast,
} from "@ionic/react";
import { useHistory, useLocation } from "react-router-dom";

import {
  addCircleOutline,
  closeCircleOutline,
  downloadOutline,
} from "ionicons/icons";

import "./Services.scss";
import boatImg from "../../images/boat.png";

import Header from "../../components/header/Header";
import { useEffect, useState } from "react";
import {
  downloadFile,
  formatTimestamp,
  uploadFileOnS3,
} from "../../utils/Helper";
import { RootStateOrAny, useSelector } from "react-redux";
import { BoatDb } from "../../interfaceModules/IBoatInterface";
import {
  getBoatServicesByServiceId,
  updateBoatService,
} from "../../redux/action-creators/boatServices";
import {deleteFile} from "../../redux/action-creators/FileUpload";

interface IServiceItem {
  name: string;
  status: string;
}
interface IServiceData {
  _id: string;
  user_id: string;
  boat_id: string;
  items: IServiceItem[];
  due_date: Date;
  status: string;
  receipts: any[];
  photos: any[];
  created_ts: Date;
  updated_ts: Date;
  __v: number;
  boatInfo: BoatDb[];
}

const ServiceHistory: React.FC = (props) => {
  const history = useHistory();
  const [present, dismiss] = useIonToast();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const location = useLocation();
  const serviceId = location.pathname.split("/")[2];
  const [currentService, setCurrentService] = useState<IServiceData>();
  const [buttonDisable, setButtonDisable] = useState(false);
  const [spin, setSpin] = useState(false);
  const inputRef: any = useRef();
  const [deletedFiles, setDeletedFile] = useState<string[]>([])


  useEffect(() => {
    fetchBoatServices();
  }, []);

  const fetchBoatServices = async () => {
    const response = await getBoatServicesByServiceId(serviceId);
    if (response && response?.data?.data?.[0]) {
      let boatData = response?.data?.data[0];
      boatData.receipts = boatData.receipts.map((i: string) => ({
        data: i,
        format: "",
      }));
      setCurrentService(response?.data?.data[0]);
    }
  };

  const handleChangeCheckList = (e: any, name: string, index: number) => {
    e.preventDefault();
    const { checked } = e.detail;
    let state = { ...currentService } as IServiceData;
    if (state.items && state.items[index]) {
      state.items[index]["status"] = checked ? "Completed" : "Pending";
    }
    setCurrentService({ ...state });
  };

  const handleFileUpload = async (event: any) => {
    let { files } = event.target;
    setSpin(true);
    const fileUrlList = await uploadFileOnS3(files, "receipt");
    let state = { ...currentService } as IServiceData;
    state.receipts = [
      ...state.receipts,
      ...fileUrlList.map((i: string) => ({ data: i, format: "" })),
    ];
    setCurrentService({ ...state });
    setSpin(false);
  };

  const handleServiceStatus = async () => {
    let state = { ...currentService } as IServiceData;
    if (state && state.status === "Pending") {
      state.status = "Completed";
    } else {
      state.status = "Pending";
    }
    setCurrentService({ ...state });
  };

  const handleSave = async () => {
    dismiss();
    setButtonDisable(true);
    let data = {
      receipts: currentService?.receipts,
      items: currentService?.items,
      serviceStatus: currentService?.status,
    } as any;
    const res = await updateBoatService(serviceId, data);
    if (res?.data?.success) {
      present("Service Updated Successfully!", 3000);
      if(deletedFiles.length > 0){
        deleteFile(deletedFiles)
      }
      history.goBack();
    }
    setButtonDisable(false);
  };

  const handleRemoveImage = (index: number) => {
    let state = { ...currentService } as IServiceData;
    const deleteFile = [...state.receipts][index]
    state.receipts.splice(index, 1);
    setCurrentService({ ...state });
    setDeletedFile((prevState) => ([...prevState, deleteFile.data]))
  };

  const handleDownloadClick = async (data : string) => {
    const fileUri = await downloadFile(data);
    present(`File Downloaded ${fileUri ? `in ${fileUri?.toString()}` : ""}`, 3000)
  }

  return (
    <>
      <Header title={"Service History"} />
      <IonContent fullscreen>
        <div className="upcomingservices-page-inner">
          <div className="main-container">
            {/* my-boats-box start */}
            <div className="my-boats-box mb-30">
              <div className="box-inner">
                <IonGrid className="p-0">
                  <IonRow>
                    <IonCol size="4">
                      <div className="boats-img">
                        <IonImg
                          className="w-100 pr-10"
                          src={
                            currentService?.boatInfo[0]["photos"][0]
                              ? currentService?.boatInfo[0]["photos"][0]
                              : boatImg
                          }
                        />
                      </div>
                    </IonCol>
                    <IonCol size="8">
                      <div className="boat-info">
                        <div className="heading">
                          <h4>{currentService?.boatInfo[0]?.title}</h4>
                          <span>
                            {
                              currentService?.boatInfo[0]?.engine
                                ?.number_of_engines
                            }
                          </span>
                        </div>
                        <div className="boat-info-detail">
                          {/* item */}
                          <div className="info-item">
                            <div className="item-contnet">
                              <p>Service Date</p>
                            </div>
                            <div className="item-contnet">
                              <p>
                                {currentService?.due_date
                                  ? formatTimestamp(currentService?.due_date)
                                  : `-`}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className="brif">
                          <p>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry’s standard dummy text ever since the 1500s,
                            when an unknown.
                          </p>
                        </div>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>
            {/* my-boats-box start */}

            {/* new-services-form start */}
            <div className="new-services-form">
              <div className="main-container">
                <div className="form-group mb-30">
                  {currentService?.items.map((item, index) => (
                    <div className="checkbox-item">
                      <IonCheckbox
                        slot="end"
                        value={item.name}
                        checked={item.status === "Completed"}
                        onIonChange={(e) =>
                          handleChangeCheckList(e, item.name, index)
                        }
                      />
                      <IonLabel>{item.name}</IonLabel>
                    </div>
                  ))}
                </div>
                <div className="form-group">
                  <div className="checkbox-item">
                    <IonCheckbox
                      slot="end"
                      // value={item.name}
                      checked={currentService?.status === "Completed"}
                      onClick={() => handleServiceStatus()}
                    />
                    <IonLabel>Completed</IonLabel>
                  </div>
                </div>

                <div>
                  <div className="form-group">
                    <div className="file-upload-btn">
                      {currentService?.receipts &&
                        currentService?.receipts?.length > 0 &&
                        currentService?.receipts.map((i, index) => (
                          <div key={index}>
                            <div className="file-card">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="19.43"
                                height="24"
                                viewBox="0 0 19.43 24"
                              >
                                <path
                                  id="Union_22"
                                  data-name="Union 22"
                                  d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                                  transform="translate(-23740.998 -12058.001)"
                                />
                              </svg>

                              <div className="action-btn">
                                <IonButton
                                  type="button"
                                  className="icon-btn primary-icon-btn "
                                  onClick={() => handleDownloadClick(i.data)}
                                >
                                  <IonIcon icon={downloadOutline} />
                                </IonButton>
                                <IonButton
                                  type="button"
                                  className="icon-btn primary-icon-btn "
                                  onClick={() => handleRemoveImage(index)}
                                >
                                  <IonIcon icon={closeCircleOutline} />
                                </IonButton>
                              </div>
                            </div>
                            {/* <IonIcon
                              icon={fileTrayStackedSharp}
                            />*/}
                          </div>
                        ))}
                      <input
                        type="file"
                        style={{ display: "none" }}
                        ref={inputRef}
                        onChange={handleFileUpload}
                      />
                      <IonButton
                        expand="block"
                        className="theme-button dark-btn right-icon-btn"
                        onClick={() => inputRef.current.click()}
                      >
                        Upload Receipts
                        <IonIcon icon={addCircleOutline} />
                        {spin && (
                          <span>
                            <IonSpinner />
                          </span>
                        )}
                      </IonButton>
                    </div>
                  </div>
                  <IonButton
                    expand="block"
                    className="theme-button primary-btn"
                    onClick={() => handleSave()}
                    disabled={buttonDisable}
                  >
                    Save
                  </IonButton>
                </div>
              </div>
            </div>
            {/* new-services-form end */}
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ServiceHistory;
