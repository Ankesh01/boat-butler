import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useState } from "react";
import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  useIonToast,
  IonInput,
} from "@ionic/react";
import {
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";

import "./UserAuth.scss";
import authbg from "../../images/user-auth-bg.png";
import logo from "../../images/logo.png";
import { ISignUpState } from "../../interfaceModules/IUserInterface";
import { signUpValidationSchema } from "../../utils/validationschema";
import { SignUpAction } from "../../redux/action-creators";
import { RoutingLinks } from "../../utils/constants";
import * as toast from "../../utils/toastsMessage";

const SignUp: React.FC = () => {
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<ISignUpState>({
    resolver: yupResolver(signUpValidationSchema()),
  });
  const [showPass, setshowPass] = useState(false);
  const [present, dismiss] = useIonToast();
  const onSubmit = async (data: ISignUpState) => {
    const response = await SignUpAction(data);
    console.log("Signup Response-0------------", response);
    if (response?.data?.success) {
      present({
        message: "User Signed up successfully",
        duration: 2000,
      });
    } else if (response?.data?.success === false) {
      present({
        message: "Something went wrong ",
        duration: 3000,
        color: "danger",
      });
      console.log("lfailed-");
    }
  };

  return (
    <IonContent fullscreen>
      <div className="auth-page" style={{ backgroundImage: `url(${authbg})` }}>
        <div className="main-container">
          <div className="auth-logo">
            <IonImg src={logo} />
          </div>
          <div className="auth-card">
            <div className="card-top">
              <h2>Sign Up</h2>
              <p>Lorem Ipsum has been the industry’s.</p>
            </div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="card-mid">
                <div className="form-group">
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className="form-control"
                        type="text"
                        placeholder="username"
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="name"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.name && <p>{errors?.name?.message}</p>}
                  </div>
                  {/* <IonInput
                    className="form-control"
                    type="text"
                    placeholder="Username"
                  ></IonInput> */}
                </div>
                <div className="form-group">
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className="form-control"
                        type="email"
                        placeholder="email"
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="email"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.email && <p>{errors?.email?.message}</p>}
                  </div>
                  {/* <IonInput
                    className="form-control"
                    type="email"
                    placeholder="Email ID"
                  ></IonInput> */}
                </div>
                <div className="form-group">
                  <div className="right-icon-input">
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className="form-control"
                          type={showPass ? "text" : "password"}
                          placeholder="password"
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="password"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.password && (
                        <p>{errors?.password?.message}</p>
                      )}
                    </div>
                    {/* <IonInput
                      className="form-control"
                      type="password"
                      placeholder="Password"
                    ></IonInput> */}
                    {/* <Link to="/"> */}
                    <IonIcon
                      icon={keyOutline}
                      onClick={() => {
                        setshowPass(!showPass);
                      }}
                    />
                    {/* </Link> */}
                  </div>
                </div>
              </div>
            </form>
            <div className="auth-btn">
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit(onSubmit)}
              >
                Sign Up
              </IonButton>
            </div>
            <div className="or-separator">
              <span>or</span>
            </div>
            <div className="social-login">
              <button className="social-btn google-btn">
                <IonIcon icon={logoGoogle} />
              </button>
              <button className="social-btn facebook-btn">
                <IonIcon icon={logoFacebook} />
              </button>
              <button className="social-btn apple-btn">
                <IonIcon icon={logoApple} />
              </button>
            </div>
            <div className="have-account">
              <p>Already have an account?</p>
              <Link to={RoutingLinks.login}>Login</Link>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default SignUp;
