import {
  IonButton,
  IonCheckbox,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  cameraOutline,
  checkmarkCircleOutline,
  closeCircleOutline,
  imageOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Receipts.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const UploadReceipts: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="receipts-page">
          <div className="main-container">
            {/* my-boats-box start */}
            <div className="my-boats-box mb-15">
              <div className="box-inner">
                <IonGrid className="p-0">
                  <IonRow>
                    <IonCol size="4">
                      <div className="boats-img">
                        <IonImg className="w-100 pr-10" src={boatImg} />
                      </div>
                    </IonCol>
                    <IonCol size="8">
                      <div className="boat-info">
                        <div className="heading">
                          <h4>Centurion</h4>
                          <span>Single Engine</span>
                        </div>
                        <div className="boat-info-detail">
                          {/* item */}
                          <div className="info-item">
                            <div className="item-contnet">
                              <p>Service Date</p>
                            </div>
                            <div className="item-contnet">
                              <p>JAN 15, 2021</p>
                            </div>
                          </div>
                        </div>
                        <div className="brif">
                          <p>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry’s standard dummy text ever since the 1500s,
                            when an unknown.
                          </p>
                        </div>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>
            {/* my-boats-box start */}

            <div className="form-group input-label">
              <IonLabel>Select Service</IonLabel>
              <IonSelect
                className="form-control"
                interface="popover"
                placeholder="— Select —"
              >
                <IonSelectOption value="Loream Ipusme">
                  Loream Ipusme
                </IonSelectOption>
                <IonSelectOption value="Loream Ipusme">
                  Loream Ipusme
                </IonSelectOption>
              </IonSelect>
            </div>

            <div className="form-group mb-30">
              <div className="file-upload-card">
                <div className="card-inner">
                  <IonIcon icon={cameraOutline} />
                  <p>
                    Tap to upload from the camera and browse from the photo
                    gallery.
                  </p>
                </div>
                <input className="file-input" type="file"></input>
              </div>
            </div>

            <div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn danger-icon-btn">
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
            </div>

            <IonButton expand="block" className="theme-button primary-btn">
              Save
            </IonButton>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default UploadReceipts;
