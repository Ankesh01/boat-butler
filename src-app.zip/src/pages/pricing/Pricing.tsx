import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonRow,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";

import "./Pricing.scss";
import pricingBg from "../../images/pricing-bg.png";
import logo from "../../images/logo.png";

const Pricing: React.FC = () => {
  return (
    <IonContent fullscreen>
      <div
        className="pricing-page"
        style={{ backgroundImage: `url(${pricingBg})` }}
      >
        <div className="main-container">
          <div className="pricing-heading">
            <h2>Pricing</h2>
            <p>
              Lorem Ipsum has been the industry’s standard dummy text ever since
              the 1500s.
            </p>
          </div>

          <div className="pricing-card-list">
            <div className="pricing-card">
              <Link to="/" className="active">
                <div className="name">
                  <h3>Personal</h3>
                  <p>$90 billed yearly</p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>8<sub>/mo</sub>
                  </p>
                </div>
              </Link>
            </div>

            <div className="pricing-card">
              <Link to="/">
                <div className="name">
                  <h3>Profesional</h3>
                  <p>$180 billed yearly</p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>16<sub>/mo</sub>
                  </p>
                </div>
              </Link>
            </div>

            <div className="pricing-card">
              <Link to="/">
                <div className="name">
                  <h3>Business</h3>
                  <p>$200 billed yearly</p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>20<sub>/mo</sub>
                  </p>
                </div>
              </Link>
            </div>

            <div className="pricing-card">
              <Link to="/">
                <div className="name">
                  <h3>Free trial</h3>
                  <p>30 days free trial</p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>0<sub>/mo</sub>
                  </p>
                </div>
              </Link>
            </div>
          </div>

          <div className="pricing-bottom-btn">
            <IonButton
              expand="block"
              className="theme-button white-outline-btn right-icon-btn"
            >
              Continue <IonIcon icon={arrowForwardOutline} />
            </IonButton>
          </div>
        </div>

        {/* Confirm Payment start */}
        <div className="price-payemnt-card">
          <div className="main-container">
            <div className="price-payemnt-card-inner">
              <div className="card-top">
                <span className="blank-border"></span>
                <h2>Confirm Payment</h2>
                <p>Lorem Ipsum has been the industry’s.</p>
              </div>
              <div className="card-mid">
                <div className="card-tab">
                  <div className="card-tab-menu">
                    <ul>
                      <li>
                        <Link className="active" to="/">
                          Monthly
                        </Link>
                      </li>
                      <li>
                        <Link to="/">Yearly</Link>
                      </li>
                    </ul>
                  </div>

                  <div className="card-tab-content">
                    <div className="price-table">
                      <table>
                        <thead>
                          <tr>
                            <td>Plan</td>
                            <td>
                              <b>Personal</b>
                            </td>
                          </tr>
                          <tr>
                            <td>Billing Cycle</td>
                            <td>
                              <b>Monthly</b>
                            </td>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Plan</td>
                            <td>$8.00</td>
                          </tr>
                          <tr>
                            <td>Tax</td>
                            <td>$2.00</td>
                          </tr>
                          <tr>
                            <td>Total</td>
                            <td>$10.00</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div className="auth-btn">
                <IonButton
                  expand="block"
                  className="theme-button right-icon-btn primary-btn"
                >
                  Continue <IonIcon icon={arrowForwardOutline} />
                </IonButton>
              </div>
            </div>
          </div>
        </div>
        {/* Confirm Payment end */}

        {/* Checkout start */}
        <div className="price-payemnt-card">
          <div className="main-container">
            <div className="price-payemnt-card-inner">
              <div className="card-top">
                <span className="blank-border"></span>
                <h2>Checkout</h2>
                <p>
                  There are many variations of passages of Lorem Ipsum
                  available, but the majority have suffered alteration in some.
                </p>
              </div>
              <div className="card-mid">
                <IonGrid className="p-0">
                  <IonRow>
                    <IonCol size="12">
                      <div className="form-group mb-0">
                        <IonInput
                          type="number"
                          className="form-control"
                          placeholder="Card Number"
                        />
                      </div>
                    </IonCol>
                    <IonCol size="6">
                      <div className="form-group mb-0">
                        <IonInput
                          type="number"
                          className="form-control"
                          placeholder="MM/ YY"
                        />
                      </div>
                    </IonCol>
                    <IonCol size="6">
                      <div className="form-group mb-0">
                        <IonInput
                          type="number"
                          className="form-control"
                          placeholder="CVV"
                        />
                      </div>
                    </IonCol>
                    <IonCol size="12">
                      <div className="form-group mb-0">
                        <IonInput
                          type="number"
                          className="form-control"
                          placeholder="Card Holder"
                        />
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>

                <div className="total-status">
                  <div className="total-heading">
                    <h3>Total</h3>
                  </div>
                  <div className="total-price">
                    <span>$90.00 USD</span>
                  </div>
                </div>
              </div>
              <div className="auth-btn">
                <IonButton
                  expand="block"
                  className="theme-button right-icon-btn primary-btn"
                >
                  Confirm Payment <IonIcon icon={arrowForwardOutline} />
                </IonButton>
              </div>
            </div>
          </div>
        </div>
        {/* Checkout end */}
      </div>
    </IonContent>
  );
};

export default Pricing;
