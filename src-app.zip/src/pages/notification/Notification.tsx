import {
  IonButton,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  notifications,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Notification.scss";
import userProfileImg from "../../images/user-profile-img.png";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";

const Notification: React.FC = () => {
  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="notification-page">
          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>Welcome to “Boat Butler” platform.</p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>
                    You have successfully add new service. Please go to service
                    page and check it.
                  </p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>Welcome to “Boat Butler” platform.</p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>
                    You have successfully add new service. Please go to service
                    page and check it.
                  </p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>Welcome to “Boat Butler” platform.</p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>
                    You have successfully add new service. Please go to service
                    page and check it.
                  </p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>Welcome to “Boat Butler” platform.</p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>

          {/* notification-item */}
          <div className="notification-item">
            <Link to="/">
              <div className="info">
                <div className="icon">
                  <IonIcon icon={notifications} />
                </div>
                <div className="content">
                  <p>
                    You have successfully add new service. Please go to service
                    page and check it.
                  </p>
                  <span>Admin</span>
                </div>
              </div>
              <div className="time">
                <span>10:27 AM</span>
              </div>
            </Link>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Notification;
