import { IonFooter, IonIcon, IonPage } from "@ionic/react";
import { Route, Switch } from "react-router";
import Footer from "../components/footer/Footer";
import AddBoat from "../pages/addBoat/AddBoat";
import BoatDetails from "../pages/boatDetails/BoatDetails";
import BusinessDirectory from "../pages/businessDirectory/BusinessDirectory";
import Community from "../pages/community/Community";
import CreateCommunity from "../pages/community/CreateCommunity";
import AddTopic from "../pages/forum/AddTopic";
import Forum from "../pages/forum/Forum";
import ForumMain from "../pages/forum/ForumMain";
import ForumTopic from "../pages/forum/ForumTopic";
import PostShare from "../pages/forum/PostShare";
import SavedPost from "../pages/forum/SavedPost";
import HelpAndSupport from "../pages/helpAndSupport/HelpAndSupport";
import Home from "../pages/home/Home";
import Notification from "../pages/notification/Notification";
import Page from "../pages/Page";
import PaymentHistory from "../pages/payment/PaymentHistory";
import PaymentSuccessful from "../pages/paymentSuccessful/PaymentSuccessful";
import Pricing from "../pages/pricing/Pricing";
import Profile from "../pages/profile/Profile";
import ProfileInner from "../pages/profile/ProfileInner";
import NewReminder from "../pages/reminders/NewReminder";
import Reminders from "../pages/reminders/Reminders";
import NewServices from "../pages/services/NewServices";
import ServiceHistory from "../pages/services/ServiceHistory";
import ServiceProvider from "../pages/services/ServiceProvider";
import UpcomingServices from "../pages/services/UpcomingServices";
import Receipts from "../pages/uploadReceipts/Receipts";
import UploadReceipts from "../pages/uploadReceipts/UploadReceipts";
import Login from "../pages/userAuth/Login";
import ChangePassword from "../pages/changePasswordProfile/ChangePassword";
import NewPassword from "../pages/userAuth/NewPassword";
import PasswordReset from "../pages/userAuth/PasswordReset";
import SignUp from "../pages/userAuth/SignUp";
import Verification from "../pages/userAuth/Verification";
import PrivateGuard from "./PrivateGuard";
const PublicRoutes: React.FC = (props: any) => {
  return (
    <IonPage>
      <Switch>
        <PrivateGuard path="/receipts" component={Receipts} />
        <PrivateGuard path="/upload-receipts" component={UploadReceipts} />
        <PrivateGuard path="/profile-inner" component={ProfileInner} />
        <PrivateGuard path="/change-password" component={ChangePassword} />
        <PrivateGuard path="/new-reminder" component={NewReminder} />
        <PrivateGuard path="/reminders" component={Reminders} />
        <PrivateGuard path="/help-and-support" component={HelpAndSupport} />
        <PrivateGuard path="/payment-history" component={PaymentHistory} />
        <PrivateGuard path="/post-detail" component={ForumTopic} />
        <PrivateGuard
          path="/service-provider/:id"
          component={ServiceProvider}
        />
        <PrivateGuard
          path="/business-directory"
          component={BusinessDirectory}
        />
        <PrivateGuard path="/community/:id" component={Community} />
        <PrivateGuard path="/create-community" component={CreateCommunity} />
        <PrivateGuard path="/saved-post" component={SavedPost} />
        <PrivateGuard path="/post-share" component={PostShare} />
        <PrivateGuard path="/add-topic" component={AddTopic} />
        <PrivateGuard path="/forum-topic" component={ForumTopic} />
        <PrivateGuard path="/forum-main" component={ForumMain} />
        <PrivateGuard path="/forum" component={Forum} />
        <PrivateGuard path="/notification" component={Notification} />
        <PrivateGuard
          path="/service-history/:serviceId"
          component={ServiceHistory}
        />
        <PrivateGuard path="/new-services" component={NewServices} />
        <PrivateGuard path="/new-services/:boatId" component={NewServices} />
        <PrivateGuard path="/boat-details/:boatId" component={BoatDetails} />
        <PrivateGuard path="/upcoming-services" component={UpcomingServices} />
        <PrivateGuard path="/add-boat" component={AddBoat} />
        <PrivateGuard path="/edit-boat/:boatId" component={AddBoat} />
        <PrivateGuard path="/home" component={Home} />
        <PrivateGuard path="/profile" component={Profile} />
        <PrivateGuard
          path="/payment-successful"
          component={PaymentSuccessful}
        />
        <PrivateGuard path="/pricing" component={Pricing} />
        <PrivateGuard path="/new-password" component={NewPassword} />
        <PrivateGuard path="/verification" component={Verification} />
        <PrivateGuard path="/password-reset" component={PasswordReset} />
        <PrivateGuard path="/sign-up" component={SignUp} />
        <PrivateGuard path="/page/:slug" component={Page} />
        <PrivateGuard path="/" component={Login} />

        {/* <Route path="/" component={Page} exact /> */}
      </Switch>
      <Footer />
    </IonPage>
  );
};
export default PublicRoutes;
