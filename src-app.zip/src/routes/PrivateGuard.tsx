import { Route, Redirect, withRouter } from "react-router-dom";
import { RoutingLinks } from "../utils/constants";
import { getAccessToken } from "../utils/storage";
import { useEffect, useState } from "react";

function PrivateGuard(props: any) {
  const [token, setToken] = useState<string | null>(null);
  const dontShowAfterLogin = [
    "/sign-up",
    "/login",
    "/verification",
    "/new-password",
    "/password-reset",
    "/",
  ];
  const route = props.location?.pathname;

  useEffect(() => {
    console.log("token updated!", getAccessToken());
    getAccessToken().then((token) => {
      setToken(token);
    });
  }, [route]);

  return (
    <>
      {token && token.length > 0 ? (
        route === "/" ? (
          <>
            <Redirect
              to={{
                pathname: RoutingLinks.home,
                state: { from: props.location },
              }}
            />
          </>
        ) : !dontShowAfterLogin.includes(route) ? (
          <>
            <Route {...props} />
          </>
        ) : (
          <>
            <Redirect
              to={{
                pathname: RoutingLinks.home,
                state: { from: props.location },
              }}
            />
          </>
        )
      ) : dontShowAfterLogin.includes(route) ? (
        <>
          <Route {...props} />
        </>
      ) : (
        <>
          <Redirect
            to={{
              pathname: "/",
              state: { from: props.location },
            }}
          />
        </>
      )}
    </>
  );
}

export default withRouter(PrivateGuard);
