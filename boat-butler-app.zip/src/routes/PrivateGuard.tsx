import { Route, Redirect, withRouter } from "react-router-dom";
import { RoutingLinks } from "../utils/constants";
import { getAccessToken } from "../utils/storage";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";

function PrivateGuard(props: any) {
  const [token, setToken] = useState<string | null | undefined>(undefined);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const dontShowAfterLogin = [
    "/sign-up",
    "/login",
    "/verification",
    "/new-password",
    "/password-reset",
    "/",
  ];
  const dontShowIfnotPaid = [
    "/sign-up",
    "/login",
    "/verification",
    "/new-password",
    "/password-reset",
    "/home",
    "/reminders",
    "/forum-main",
    // "/profile-inner",
    "/",
  ];
  const route = props.location?.pathname;
  console.log("props guard", props);
  console.log("private guard", route);
  console.log("authData== ", authData);
  useEffect(() => {
    getAccessToken().then((token) => {
      setToken(token);
    });
  }, [route]);

  const date1 = new Date();

  const checkPayment = () => {
    let bool = false;
    if (authData?.paymentInfo) {
      bool =
        new Date(authData?.paymentInfo?.end_date).getTime() > date1.getTime();
      return bool;
    }
    return bool;
  };

  console.log("checkpayment--", checkPayment());
  return (
    <>
      {token !== undefined && (
        <>
          {token && token.length > 0 ? (
            checkPayment() ? (
              route === "/" ? (
                <>
                  <Redirect
                    to={{
                      pathname: RoutingLinks.home,
                      state: { from: props.location },
                    }}
                  />
                </>
              ) : !dontShowAfterLogin.includes(route) ? (
                <>
                  <Route {...props} />
                </>
              ) : (
                <>
                  <Redirect
                    to={{
                      pathname: RoutingLinks.home,
                      state: { from: props.location },
                    }}
                  />
                </>
              )
            ) : route === "/" ? (
              <>
                <Redirect
                  to={{
                    pathname: RoutingLinks.pricing,
                    state: { from: props.location },
                  }}
                />
              </>
            ) : !dontShowIfnotPaid.includes(route) ? (
              <>
                {console.log(" dontShowIfnotPaid", dontShowIfnotPaid)}
                <Route {...props} />
              </>
            ) : (
              <>
                <Redirect
                  to={{
                    pathname: RoutingLinks.pricing,
                    state: { from: props.location },
                  }}
                />
              </>
            )
          ) : dontShowAfterLogin.includes(route) ? (
            <>
              <Route {...props} />
            </>
          ) : (
            <>
              <Redirect
                to={{
                  pathname: "/",
                  state: { from: props.location },
                }}
              />
            </>
          )}
        </>
      )}
    </>
  );
}

export default withRouter(PrivateGuard);
