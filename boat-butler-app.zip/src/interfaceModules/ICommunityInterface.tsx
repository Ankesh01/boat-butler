export interface ICommunityDetails {
  status: string;
  _id: string;
  offset?: number;
  query?: string;
}

export interface ICommunityList {
  created_ts: string;
  description: string;
  image: string;
  status: string;
  title: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}
export interface IReportCommunity {
  type_id: string;
  userId: string;
  type: string;
}

export interface ICommunityDetailInterface {
  _id?: string;
  user_id: string;
  title: string;
  description?: string;
  status: string;
  image?: string;
  reported: { count: number; reported_by: Array<string[]> };
  created_ts: string;
  updated_ts: string;
  user_role?: string;
}

export interface IJoinedCommunityInterface {
  community_detail: ICommunityDetailInterface;
  community_id: string;
  created_ts: string;
  status: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}
export interface ICommunityEachList {
  community_detail?: ICommunityDetailInterface;
  community_id: string;
  created_ts: string;
  status: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}

export interface ISuggestedCommunityInterface {
  communityMember_detail: ICommunityMembersInterface[];
  created_ts: string;
  description: string;
  image: string;
  status: string;
  title: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}

export interface ICreateCommunityInterface {
  _id?: string;
  user_id?: string;
  title: string;
  description?: string;
  oldImage?: string;

  image?: { data: string; format: string };
  // reported: { count: number; reported_by: Array<string[]> };
  // created_ts: string;
  // updated_ts: string;
  // user_role?: string;
}
export interface IPhotoInterface {
  image?: { data: string; format: string };
}

export interface IPostInterface {
  _id: string;
  user_id?: string;
  type: string;
  title?: string;
  description?: string;
  type_item_id: string;
  media_file?: string;
  total: IPostActivity;
  userInfo?: any;
  user_info: IUserinfo[];
  post_comments?: IPostCommentInterface[] | any;
  created_ts: string;
  updated_ts: string;
  reported?: IReportedPosts[];
  shared_post_detail: ISharedPostInterface[];
  post_creator_detail?: IUserinfo[];
}
export interface ISharedPostInterface {
  _id?: string;
  user_id?: string;
  type?: string;
  title?: string;
  description?: string;
  type_item_id?: string;
  media_file?: string;
  total?: IPostActivity;
  userInfo?: any;
  user_info?: IUserinfo[];
  post_comments?: IPostCommentInterface[];
  created_ts?: string;
  updated_ts?: string;
  post_creator_detail: IPostCreatorInterface[];
}
export interface IPostCreatorInterface {
  name?: string;
  image?: string;
  created_ts?: string;
  updated_ts?: string;
}
export interface IPropsInterface {
  post: IPostInterface;
  index?: number;
  updatePostLike?: any;
  refreshPostList?: any;
  role?: string;
}
export interface IReportedPosts {
  user_id: string;
  date: string;
}

export interface IUserinfo {
  created_ts?: string;
  email?: string;

  image?: string;

  name: string;

  updated_ts?: string;
}

export interface IPostActivity {
  like?: string[];
  comment?: string;
  bookmarks?: string[];
}

export interface ICommentInterface {
  user_id?: string;
  comment?: string;
  post_id?: string;
  status?: string;
  total?: { like: string; reported: string };
  _id: string;
}
export interface IGetCommentInterface {
  _id: string;
  user_id: string;
  comment: string;
  post_id: string;
  status: string;
  total?: {
    like?: string[];
    comment?: string;
    bookmark?: string[];
  };
  userInfo?: any;
  created_ts: Date;
  updated_ts: string;
}

export interface IPostCommentInterface {
  user_id: string;
  comment: string;
  post_id: string;
  status: string;
}

export interface ICommunityMembersInterface {
  user_id?: string;
  community_id?: string;
  comment?: string;
  post_id?: string;
  community_user_details: IComDetails;
  status?: string;
  created_ts?: string;
  updated_ts?: string;
  _id?: string;
}

export interface IComDetails {
  _id: string;

  image?: string;

  name: string;
}
