export interface IRequestInterface {
  community_id: string;
  community_user_details: ICommunityUserDetail;
  created_ts: string;
  status: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}

export interface ICommunityUserDetail {
  image: string;
  name: string;
  _id: string;
}
