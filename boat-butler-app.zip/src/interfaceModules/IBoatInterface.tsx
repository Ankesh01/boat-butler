export interface add_Boat {
  title: string;
  date: string;
  phone_number: string;
  RegId: string;
  vin: string;
  boat_make: string;
  boat_model: string;
  year_hull: string;
  engine_no: string;
  engine_make: string;
  engine_model: string;
  engine_hp?: number;
  engine_dry_weight?: number;
  engine_start_type?: string;
  engine_tilt_trim?: string;
  engine_fuel_type?: string;
  engine_year_model?: number;
  engine_strock_series?: string;
  engine_hours: string;
  engine_year: string;
  engine_SN: string;
  otherEquip: IEquipment[];
  equip_make: string;
  equip_model: string;
  year_bought: string;
  equip_SN: string;
}

export interface IEquipment {
  equip_make: string;
  equip_model: string;
  year_bought: string;
  equip_SN: string;
  img?: string[];
}

export interface BoatDb {
  _id?: string;
  user_id?: string;
  title?: string;
  date_of_bought: Date;
  seller_phone: string;
  registration_id: string;
  vin: string;
  make: string;
  model: string;
  year_of_hull: number;
  engine?: IEngine;
  other_equipments: IEquipment[];
  photos?: any;
}

export interface IEngine {
  number_of_engines?: number;
  make?: string;
  model?: string;
  hours?: number;
  year?: number;
  serial_number?: string;
  manuals?: [];
  photos?: [];
}

export interface IUpcomingServices {
  boatInfo: BoatDb[];
  boat_id: string;
  created_ts: string;
  due_date: string;
  items: IItem;
  photos: [];
  receipts: [];
  status: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}

export interface IItem {
  name: string;
  status: string;
}
