export interface IChangePasswordState {
  // id: number;
  password: string;
  newpassword: string;
  confirm_password: string;
}

export interface ICitiesInterface {
  city: string;
  growth_from_2000_to_2013: string;
  latitude: number;
  longitude: number;
  population: string;
  rank: string;
  state: string;
}
