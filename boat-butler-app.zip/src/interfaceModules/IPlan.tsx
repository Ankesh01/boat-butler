export interface IPlan {
  _id: string;
  title: string;
  boat_count: number;
  plan_id: string;
  slug: string;
  price: number;
  created_ts: string;
  updated_ts: string;
}

export interface IPaymentHistory {
  _id: string;
  amount: string;
  end_date: string;
  mode: string;
  plan_id: string;
  plan_info: IPlan[];
  created_ts: string;
  slug: string;
  title: string;

  transaction_id: string;
  updated_ts: string;
  user_id: string;
}
