export interface IReminderInterface {
  created_ts?: string;
  due_end_datetime?: Date;
  due_start_datetime?: Date;
  id: string;
  notes?: string;
  priority?: string;
  repeat?: number;
  status?: string;
  title?: string;
  updated_ts?: string;
  user_id: string;
  __v?: 0;
  _id?: string;
}

export interface INewReminder {
  userId: string;
  reminder: ISubReminder;
  timezone?: string;
}
export interface ISubReminder {
  date: string;
  end_time: string;
  notes: string;
  priority: string;
  repeat: string;
  start_time: string;
  title: string;
  due_start_datetime: string;
  due_end_datetime: string;
}

export interface IReminderErrorMessage {
  title: string;
  notes: string;
  date: string;
  start_time: string;
  end_time: string;
  repeat: string;
  priority: string;
}

export interface IReminderNotification {
  reminder_id: string;
  send_status: number;
  status: string;
}
