import {
  IPostActivity,
  IPostCommentInterface,
  ISharedPostInterface,
  IUserinfo,
} from "./ICommunityInterface";

export interface IPostActivityData {
  _id: string;
  userId?: string;
  user_id?: string;
  type?: string;
}
export interface IPostInterface {
  _id: string;
  user_id?: string;
  type: string;
  title?: string;
  description?: string;
  type_item_id: string;
  media_file?: string;
  total: IPostActivity;
  userInfo?: any;
  user_info: IUserinfo[];
  post_comments?: IPostCommentInterface[];
  created_ts: string;
  updated_ts: string;
  shared_post_detail: ISharedPostInterface[];
  post_creator_detail?: IUserinfo[];
}

export interface IUserInfo {
  created_ts?: string;
  _id: string;
  name?: string;
}
export interface IDataSubmit {
  created_ts?: string;
  _id?: string;
  title?: string;
}
