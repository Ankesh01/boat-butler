export interface IPost {
  created_ts?: string;
  description: string;
  id?: string;
  status?: string;
  media_file?: string;
  title?: string;
  type?: string;
  total?: IPostActivity;
  type_item_id?: string;
  post_comments?: any;
  updated_ts?: string;
  user_id?: string;
  _id?: string;
}

export interface IPostActivity {
  like?: string[];
  comment?: any;
  bookmarks?: string[];
}
