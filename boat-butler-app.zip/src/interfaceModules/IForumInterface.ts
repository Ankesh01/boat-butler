import { IPostActivity } from "./ICommunityInterface";

export interface IForumInterface {
  _id: string;
  title: string;
  description: string;
  status: string;
  created_ts?: string;
  updated_ts?: string;
}

export interface IAddTopicInterface {
  id: string;
  is_active: Boolean;
  title: string;
  updated_ts: string;
  user_id: string[];
  _id: string;
}

export interface IForum {
  title: string;
  _id: string;
}

export interface IForumMain {
  created_ts?: string;
  description: string;
  media_file?: string;
  post_comments?: IPostComment[];
  reported?: any;
  shared_post_detail?: any;
  status?: string;
  title?: string;
  total?: IPostActivity;
  type?: string;
  type_item_id?: string;
  updated_ts: string;
  userInfo: IUserInfoInterface[];
  user_id: string;
  _id?: string;
}

export interface IPostComment {
  comment: string;
  created_ts: string;
  post_id: string;
  status: string;
  updated_ts: string;
  user_id: string;
  _id: string;
}

export interface IUserInfoInterface {
  account_type: string;
  created_ts: string;
  email: string;
  is_active: Boolean;
  is_verified: Boolean;
  name: string;
  password: string;
  timezone: string;
  updated_ts: string;
  _id: string;
}
