const RoutingLinks = {
  upcomingservices: "/upcoming-services",
  add_boat: "/add-boat",
  home: "/home",
  succ_payment: "/payment-successful",
  pricing: "/pricing",
  newPass: "/new-password",
  resetpass: "/password-reset",
  signup: "/sign-up",
  login: "/",
  profile: "/profile",
};

const Engine_make = ["Option 1", "Option 2", "Option 3", "Option 4"];

const Engine_option = ["Option 1", "Option 2", "Option 3", "Option 4"];
const Engine_year_option = [1990, 1992, 1993, 1995, 2000];
const Engine_hp_option = [1500, 1700, 2000, 2500];
const Gender_List = ["Female", "Male"];
const Country_List = [
  "Afghanistan",
  "Albania",
  "Algeria",
  "Andorra",
  "China",
  "Canada",
  "Brazil",
  "Bolivia",
  "Bhutan",
  "Benin",
  "Belgium",
  "Armenia",
];
const State_List = [
  "Afghanistan",
  "Albania",
  "Algeria",
  "Andorra",
  "China",
  "Canada",
  "Brazil",
  "Bolivia",
  "Bhutan",
  "Benin",
  "Belgium",
  "Armenia",
];

const Repeat_Reminder = [15, 30, 60];

const Priority_Reminder = ["Low", "Medium", "High"];

export {
  RoutingLinks,
  Engine_make,
  Engine_option,
  Country_List,
  State_List,
  Gender_List,
  Engine_year_option,
  Engine_hp_option,
  Repeat_Reminder,
  Priority_Reminder,
};
