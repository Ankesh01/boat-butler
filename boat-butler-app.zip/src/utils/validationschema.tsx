import * as yup from "yup";
import NewReminder from "../pages/reminders/NewReminder";

const passworRegExp =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
const nameRegExp = /^[ a-zA-Z0-9\-’]+$/;
const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const signUpValidationSchema = () =>
  yup.object().shape({
    name: yup
      .string()
      .trim()
      .required("username is required")
      .matches(nameRegExp, "Please enter a valid first name")
      .max(25, "Must be less than or equal 25 digits"),
    email: yup
      .string()
      .trim()
      .required("Email is required")
      .email("Please enter a valid email"),
    password: yup
      .string()
      .required("Password is required")
      .matches(
        passworRegExp,
        "Your password must be more than 8 characters long, should contain at least 1 uppercase, 1 lowercase, 1 numeric and 1 special character."
      )
      .max(25, "Must be less than or equal 25 digits."),
  });

const loginValidationSchema = () =>
  yup.object().shape({
    email: yup
      .string()
      .trim()
      .required("Email is required")
      .email("Please enter a valid email"),
    password: yup
      .string()
      .required("Password is required")
      .max(25, "Must be less than or equal 25 digits."),
  });

const ChangePasswordValidationSchema = () =>
  yup.object().shape({
    password: yup
      .string()
      .required("Password is required")
      .matches(
        passworRegExp,
        "Your password must be more than 8 characters long, should contain at least 1 uppercase, 1 lowercase, 1 numeric and 1 special character."
      )
      .max(25, "Must be less than or equal 25 digits."),
    newpassword: yup
      .string()
      .required("Password is required")
      .matches(
        passworRegExp,
        "Your password must be more than 8 characters long, should contain at least 1 uppercase, 1 lowercase, 1 numeric and 1 special character."
      )
      .max(25, "Must be less than or equal 25 digits."),
    confirm_password: yup
      .string()
      .required("Confirm Password is required")
      .oneOf(
        [yup.ref("newpassword")],
        "New Password and Confirm Password must match"
      ),
  });
const ResetpasswordSchema = () =>
  yup.object().shape({
    email: yup
      .string()
      .trim()
      .required("Email is required")
      .email("Please enter a valid email"),
  });
const verificationSchema = () =>
  yup.object().shape({
    otp: yup.string().trim().required("OTP required"),
  });
const NewPasswordSchema = () =>
  yup.object().shape({
    password: yup
      .string()
      .required("Password is required")
      .matches(
        passworRegExp,
        "Your password must be more than 8 characters long, should contain at least 1 uppercase, 1 lowercase, 1 numeric and 1 special character."
      )
      .max(25, "Must be less than or equal 25 digits."),
    confirm_password: yup.string().required("Confirm new password is required"),
  });

const profileValidationSchema = () =>
  yup.object().shape({
    name: yup
      .string()
      .trim()
      .required("Name is required")
      .matches(nameRegExp, "Please enter a valid Name")
      .max(50, "Must be less than or equal 50 digits"),
    email: yup
      .string()
      .trim()
      .required("Email is required")
      .email("Please enter a valid email"),
    phone: yup
      .string()
      .required("Phone Number Required")
      .matches(phoneRegExp, "Phone number is not valid")
      .min(10, "Must be 10")
      .max(10, "Must be 10"),
    address_line_1: yup
      .string()
      .trim()
      .required("Address is required")
      .max(150, "Must be less than or equal 150 digits"),
    address_line_2: yup
      .string()
      .trim()
      .required("Address is required")
      .max(150, "Must be less than or equal 150 digits"),
    state: yup.string().required("State is required"),
    zipcode: yup
      .string()
      .required("ZipCode is required")
      .matches(/^[0-9]+$/, "Zipcode is not Valid")
      .min(5, "Not a valid zip code")
      .max(6, "Not a valid zip code"),
    // password: yup
    //   .string()
    //   .required("Password is required")
    //   .matches(
    //     passworRegExp,
    //     "Your password must be more than 8 characters long, should contain at least 1 uppercase, 1 lowercase, 1 numeric and 1 special character."
    //   )
    //   .max(25, "Must be less than or equal 25 digits."),
  });

const CommunityValidationSchema = () =>
  yup.object().shape({
    description: yup
      .string()
      .trim()
      .required("description is required")
      // .matches(nameRegExp, "Please enter a valid Name")
      .max(250, "Must be less than or equal 250 digits"),
    // title: yup.string().required("Title is Required"),
  });

const CreateCommunityValidationSchema = () =>
  yup.object().shape({
    title: yup.string().required("Title is Required"),
    description: yup
      .string()
      .trim()
      .required("Description is required")
      // .matches(nameRegExp, "Please enter a valid Name")
      .max(250, "Must be less than or equal 250 digits"),
  });
const PostShareValidationSchema = () =>
  yup.object().shape({
    description: yup
      .string()
      .trim()
      .required("description is required")
      // .matches(nameRegExp, "Please enter a valid Name")
      .max(250, "Must be less than or equal 250 digits"),
    // title: yup.string().required("Title is Required"),
  });
const AddBoatSchema = (isOtherMake: boolean, isOtherModel: boolean) =>
  yup.object().shape({
    date: yup.string().required("Date is Required"),
    phone_number: yup
      .string()
      .required("Phone Number is Required")
      .matches(phoneRegExp, "Phone number is not valid")
      .min(10, "Must be 10")
      .max(10, "Must be 10"),
    title: yup.string().required("Title is Required"),
    RegId: yup.string().required("Reg Id is Required"),
    vin: yup.string().required("VIN is Required"),
    boat_make: yup.string().required("Boat make is Required"),
    year_hull: yup.string().required("Year hull is Required"),
    engine_no: yup.string().required("Engine No. is Required"),
    engine_make: yup.string().required("Engine Make  is Required"),
    engine_model: yup.string().required("Engine Model is Required"),
    engine_hp: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Engine HP is Required"),
    }),
    engine_dry_weight: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Engine Dry Weight is Required"),
    }),
    engine_start_type: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Engine Start Type is Required"),
    }),
    engine_tilt_trim: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Tilt/Trim is Required"),
    }),
    engine_fuel_type: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Fuel Type is Required"),
    }),
    engine_strock_series: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Strock Series is Required"),
    }),
    engine_year_model: yup.string().when(["isOtherMake", "isOtherModel"], {
      is: () => isOtherMake || isOtherModel,
      then: yup.string().required("Year is Required"),
    }),
    engine_hours: yup.string().required("Engine used Hours is Required"),
    engine_year: yup.string().required("Engine Year is Required"),
    engine_SN: yup.string().required("Engine Serial Number is Required"),
    otherEquip: yup.array().of(
      yup.object().shape({
        equip_make: yup.string().required("Equipment is Required"),
        equip_model: yup.string().required("Equipment model  is Required"),
        year_bought: yup.string().required("Bought year is Required"),
        equip_SN: yup.string().required("Equipment Serial Number is Required"),
      })
    ),
    // date: yup.string().required('Date is Required'),
    // phone_number: yup.string().required('Phone Number is Required'),
    // RegId: yup.string().required('Reg Id is Required'),
    // vin: yup.string().required('VIN is Required'),
    // boat_make: yup.string().required('boat_make is Required'),
    // year_hull: yup.string().required('year_hull is Required'),
    // engine_no: yup.string().required('Engine No. is Required'),
  });

export {
  signUpValidationSchema,
  loginValidationSchema,
  NewPasswordSchema,
  verificationSchema,
  ResetpasswordSchema,
  profileValidationSchema,
  CommunityValidationSchema,
  AddBoatSchema,
  CreateCommunityValidationSchema,
  PostShareValidationSchema,
  ChangePasswordValidationSchema,
};
