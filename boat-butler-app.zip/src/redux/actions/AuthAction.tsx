import { ActionType } from "../action-types/index";
import { ISignUpState } from "../../interfaceModules/IUserInterface";

interface SignUpAction {
  type: ActionType.SIGNUP;
  payload: ISignUpState | undefined;
}

interface FailureAction {
  type: ActionType.FAILURE;
}

interface LogoutAction {
  type: ActionType.LOGOUTUSER;
}

export type Action = SignUpAction | FailureAction | LogoutAction ;
