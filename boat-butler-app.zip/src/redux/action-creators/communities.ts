import ApiResponse from "../../interfaceModules/IApiResponse";
import {
  ICommunityDetails,
  ICreateCommunityInterface,
  IReportCommunity,
} from "../../interfaceModules/ICommunityInterface";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";
import { AxiosRequestConfig } from "axios";

export const createCommunityAction = (
  data: ICreateCommunityInterface
): Promise<ApiResponse> => {
  return http.post(`${endpoint.Community.create}`, data);
};
export const getCommunityById = (
  _id: string,
  user_id: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Community.get}/${_id}${user_id ? `?user_id=${user_id}` : ""}`
  );
};

export const getCommunityDetails = (
  data: ICommunityDetails
): Promise<ApiResponse> => {
  return http.post(
    `${endpoint.Community.details}${
      data.offset ? `?offset=${data.offset}` : ""
    }${data.query ? `&query=${data.query}` : ""}`,
    data
  );
};

export const getCommunityPosts = (
  _id: string,
  offset: number,
  user_id: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Community.getposts}/${_id}${`?offset=${offset}`}${
      user_id ? `&user_id=${user_id}` : ""
    }`
  );
};

export const editCommunityAction = (
  // _id: string,
  data: ICreateCommunityInterface
): Promise<ApiResponse> => {
  return http.put(`${endpoint.Community.edit}/${data._id}`, data);
};

export const joinCommunity = (data: {
  community_id: string;
  userId: string;
}): Promise<ApiResponse> => {
  return http.post(
    `${endpoint.Community.join.replace(":id", data.community_id)}`,
    data
  );
};
export const requestAction = (
  status: string,
  user_id: string,
  community_id: string
): Promise<ApiResponse> => {
  return http.put(
    `${endpoint.Community.request_action}
    `,
    { status, user_id, community_id }
  );
};
export const deleteMember = (
  user_id: string,
  community_id: string
  // data: any
): Promise<ApiResponse> => {
  return http.post(
    `${endpoint.Community.delete_member}
    `,
    { user_id, community_id }
  );
};
// export const unlikePostAction = (
//   data: IPostActivityData
// ): Promise<ApiResponse> => {
//   return http.put(`${endpoint.Post.unlike_community}`, data);
// };

export const getCommunityList = (
  _id: string,
  type: string,
  offset: number
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Community.community_list}/${_id}${type ? `?type=${type}` : ""}${
      offset ? `&offset=${offset}` : ""
    }`
  );
};

export const reportCommunityAction = (
  data: IReportCommunity
): Promise<ApiResponse> => {
  console.log("IReportCommunity", data);
  return http.put(`${endpoint.Community.report_community}`, data);
};
