import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";
import { string } from "yup/lib/locale";
import { boat } from "ionicons/icons";

interface BoatSchema {}

interface Idata {
  receipts?: {
    dataUrl: string;
    format: string;
  }[];
  items: {
    name: string;
    status: string;
  }[];
  serviceStatus: string;
}

export const createBoatService = (data: {
  user_id: string;
  serviceDate: Date;
  selectedBoat: BoatSchema;
  items: string[];
}): Promise<ApiResponse> => {
  return http.post(endpoint.BoatServices.create, data);
};
export const updateBoatService = (
  serviceId: string,
  data: Idata
): Promise<ApiResponse> => {
  return http.post(
    `${endpoint.BoatServices.update.replace(":serviceId", serviceId)}`,
    data
  );
};

export const getBoatServicesByUserId = (
  userId: string,
  data?: {
    boatId?: string;
    date?: Date;
  }
): Promise<ApiResponse> => {
  let query: string[] = [];
  if (data?.boatId) {
    query.push(`boatId=${data.boatId}`);
  }
  if (data?.date) {
    query.push(`date=${data.date}`);
  }
  return http.get(
    `${endpoint.BoatServices.getAll}/${userId}${
      query.length > 0 ? `?${query.join("&")}` : ""
    }`
  );
};

export const getBoatServicesByServiceId = (
  serviceId: string
): Promise<ApiResponse> => {
  return http.get(`${endpoint.BoatServices.get}/${serviceId}`);
};

export const getServicesHistory = (
  userId: string,
  data?: {
    boatId?: string;
    date?: Date;
  }
): Promise<ApiResponse> => {
  let query: string[] = [];
  if (data?.boatId) {
    query.push(`boatId=${data.boatId}`);
  }
  if (data?.date) {
    query.push(`date=${data.date}`);
  }
  return http.get(
    `${endpoint.BoatServices.get}/get-history/${userId}${
      query.length > 0 ? `?${query.join("&")}` : ""
    }`
  );
};
