import ApiResponse from "../../interfaceModules/IApiResponse";
import {
  INewReminder,
  IReminderNotification,
} from "../../interfaceModules/IReminderInterface";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const addNewReminderAction = (
  data: INewReminder
): Promise<ApiResponse> => {
  return http.post(`${endpoint.Reminders.add}`, data);
};

export const getAllReminderAction = (userId: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Reminders.getAllReminder}/${userId}`);
};

export const deleteReminderByIdAction = (
  _id: string[]
): Promise<ApiResponse> => {
  return http.delete(`${endpoint.Reminders.deleteReminder}/${_id}`);
};

export const reminderNotificationAction = (
  data: IReminderNotification
): Promise<ApiResponse> => {
  return http.post(`${endpoint.Reminders.ReminderNotification}`, data);
};
