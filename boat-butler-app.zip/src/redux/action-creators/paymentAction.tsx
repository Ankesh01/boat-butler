import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { IPostActivityData } from "../../interfaceModules/IPostInterface";
import { http } from "./http";
import { IPaymentsInterface } from "../../interfaceModules/IPayment";

export const getPlanListAction = (): Promise<ApiResponse> => {
  return http.get(endpoint.Payment.get_plans);
};

export const createPaymentAction = (
  data: IPaymentsInterface
): Promise<ApiResponse> => {
  return http.post(endpoint.Payment.create);
};

export const getPaymentHistory = (
  offset: number,
  userId: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Payment.get_paymenHistory}${`?offset=${offset}`}${
      userId ? `&userId=${userId}` : ""
    }`
  );
};
