import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const getServiceProviderAction = (
  coordinates: any
): Promise<ApiResponse> => {
  return http.post(`${endpoint.BusinessDirectory.get_service}`, coordinates);
};

export const getServiceProviderById = (
  service_id: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.BusinessDirectory.get_servicebyId}/${service_id}`
  );
};

export const GooglePlacesDetail = (placeId: string): Promise<ApiResponse> => {
  return http.get(`/api/v1/businesses/googlePlace/${placeId}`);
};
