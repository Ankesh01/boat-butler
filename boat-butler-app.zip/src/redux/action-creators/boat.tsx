import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const addBoatAction = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.Boat.add}`, data);
};

export const getEngineMakeListAction = (): Promise<ApiResponse> => {
  return http.get(endpoint.Boat.getEngineMake);
};
export const getBoatCountByUserId = (userId: string): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Boat.getBoatCountByUserId}${`?userId=${userId}`}`
  );
};

export const getBoatByIdAction = (boatId: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Boat.getBoat}/${boatId}`);
};

export const editBoatAction = (
  boatId: string,
  data: any
): Promise<ApiResponse> => {
  return http.post(`${endpoint.Boat.editBoat}/${boatId}`, data);
};

export const getEngineModelListAction = (): Promise<ApiResponse> => {
  return http.get(endpoint.Boat.getEngineMake);
};

export const getBoatListAction = (
  id: any,
  searchKeyword?: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Boat.getBoatList}/${id}${
      searchKeyword ? `?searchKeyword=${searchKeyword}` : ""
    }`
  );
};

export const getBoatServicesById = (
  userId: string,
  boatId?: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Boat.getBoatServices}/${userId}${
      boatId ? `?boatId=${boatId}` : ""
    }`
  );
};
