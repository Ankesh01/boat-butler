import ApiResponse from "../../interfaceModules/IApiResponse";
import {
  IGetCommentInterface,
  IPostCommentInterface,
} from "../../interfaceModules/ICommunityInterface";
import { endpoint } from "../../utils/endPoints";
import { http } from "./http";

export const postCommentAction = (
  data: IPostCommentInterface
): Promise<ApiResponse> => {
  return http.post(`${endpoint.Post.postcomment}`, data);
};

export const getCommentAction = (data: any): Promise<ApiResponse> => {
  return http.get(`${endpoint.Post.getcomment}/${data.post_id}`);
};
