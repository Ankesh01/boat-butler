import ApiResponse from "../../interfaceModules/IApiResponse";
import { endpoint } from "../../utils/endPoints";
import { IPostActivityData } from "../../interfaceModules/IPostInterface";
import { http } from "./http";

export const createPostAction = (data: any): Promise<ApiResponse> => {
  return http.post(`${endpoint.Post.create}`, data);
};

export const likePostAction = (
  data: IPostActivityData
): Promise<ApiResponse> => {
  return http.put(`${endpoint.Post.like_community}`, data);
};

export const reportPostAction = (
  data: IPostActivityData
): Promise<ApiResponse> => {
  return http.put(`${endpoint.Post.report_post}`, data);
};

export const unlikePostAction = (
  data: IPostActivityData
): Promise<ApiResponse> => {
  return http.put(`${endpoint.Post.unlike_community}`, data);
};

export const getPostById = (_id: string): Promise<ApiResponse> => {
  return http.get(`${endpoint.Post.detail}/${_id}`);
};

export const getPostListAction = (
  userId: string,
  offset: number
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Post.getList.replace(":userId", userId)}${
      offset ? `?offset=${offset}` : ""
    }`
  );
};

// export const getSavedPostListAction = (userId: string): any => {
//   return http.get(endpoint.Post.getsavedPostList.replace(":userId", userId));
// };
export const getSavedPostListAction = (
  userId: string,
  offset: number,
  searchKeyword?: string
): Promise<ApiResponse> => {
  return http.get(
    `${endpoint.Post.getsavedPostList.replace(
      ":userId",
      userId
    )}${`?offset=${offset}`}${
      searchKeyword ? `&searchKeyword=${searchKeyword}` : ""
    }`
  );
};
