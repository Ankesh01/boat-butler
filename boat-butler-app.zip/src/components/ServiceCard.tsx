import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { IonCol, IonGrid, IonImg, IonProgressBar, IonRow } from "@ionic/react";

import boatImg from "../images/boat.png";

import {
  calculateProgress,
  formatTimestamp,
  getDaysDifferenceFromToday,
} from "../utils/Helper";

const ServiceCard = (props: any) => {
  const [service, setService] = useState(props.serviceData);

  useEffect(() => {
    setService(props.serviceData);
  }, [props.serviceData]);

  return (
    <Link to={`/service-history/${service._id}`}>
      <div className="upcoming-card">
        <div className="card-img">
          <IonImg
            src={
              service.boatInfo[0] && service.boatInfo[0]?.photos?.[0]
                ? service.boatInfo[0]["photos"][0]
                : boatImg
            }
          />
        </div>
        <div className="card-content">
          <IonGrid className="p-0">
            <IonRow>
              <IonCol size="5">
                <div className="info">
                  <h2>{service?.boatInfo[0]?.["title"]}</h2>
                  <div className="brif">
                    <p>{service?.boatInfo[0]?.["engine"].number_of_engines}</p>
                  </div>
                </div>
              </IonCol>
              <IonCol size="7">
                <div className="info">
                  <h2>
                    {service.due_date ? formatTimestamp(service.due_date) : `-`}
                  </h2>
                  <div className="brif">
                    <p>
                      {getDaysDifferenceFromToday(service.due_date)} Days Left
                    </p>
                    <div className="time-status">
                      <IonProgressBar
                        value={calculateProgress(service.due_date)}
                      />
                    </div>
                  </div>
                </div>
              </IonCol>
            </IonRow>
          </IonGrid>
        </div>
      </div>
    </Link>
  );
};

export default ServiceCard;
