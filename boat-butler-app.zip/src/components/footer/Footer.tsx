import { IonFooter } from "@ionic/react";
import { Link, useLocation } from "react-router-dom";
import { RootStateOrAny, useSelector } from "react-redux";

import "./Footer.scss";

const Footer: React.FC = () => {
  const location = useLocation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  return authData ? (
    <IonFooter className="common-footer">
      <div className="main-container">
        <div className="footer-links">
          <Link
            to="/home"
            className={location.pathname === "/home" ? "active" : ""}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="23.554"
              height="24"
              viewBox="0 0 23.554 24"
            >
              <path
                id="np_home_2087677_000000"
                d="M29.568,24.812h-.581v.748h.581Zm-1.994,0-.54-.041v.789h.54Zm-.54-1.413h.54v-.748h-.54Zm1.953,0h.581v-.748h-.581Zm-3.364-1.454a.728.728,0,0,1,.706-.706h3.946a.728.728,0,0,1,.706.706v4.278a.7.7,0,0,1-.706.706H26.329a.7.7,0,0,1-.706-.706Zm-9.1,4.029,11.3-9.969a.811.811,0,0,1,.955,0l11.3,9.969-.955,1.039-.623-.54L35.052,39.351a.723.723,0,0,1-.706.5H22.216a.638.638,0,0,1-.665-.54L18.1,26.476l-.665.54-.914-1.039ZM28.281,17.5l-9.014,7.934,3.489,13.042h2.035V30.584a2.427,2.427,0,0,1,.333-1.247,1.286,1.286,0,0,1,1.163-.706h4.029a1.327,1.327,0,0,1,1.163.706,2.424,2.424,0,0,1,.333,1.247v7.893h1.994l3.531-13.042ZM26.2,30.586v7.893h4.2V30.586a1.034,1.034,0,0,0-.125-.54H26.328v.041a.894.894,0,0,0-.125.5ZM30.316,30.046Z"
                transform="translate(-16.523 -15.85)"
              />
            </svg>
          </Link>
          <Link
            to="/forum-main"
            className={
              location.pathname === "/create-community" ? "active" : ""
            }
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18.855"
              height="24"
              viewBox="0 0 18.855 24"
            >
              <path
                id="Union_46"
                data-name="Union 46"
                d="M15532.288,12082a4.283,4.283,0,0,1-4.286-4.285v-18.855a.856.856,0,0,1,.856-.859h13.714a4.293,4.293,0,0,1,4.285,4.287v18.855a.86.86,0,0,1-.252.607.85.85,0,0,1-.6.25Zm-2.574-4.285a2.574,2.574,0,0,0,2.574,2.57h12.854v-18a2.57,2.57,0,0,0-2.57-2.572h-12.858Zm3.43-1.715a.857.857,0,1,1,0-1.715h8.568a.857.857,0,1,1,0,1.715Zm0-5.141a.857.857,0,1,1,0-1.715h8.568a.857.857,0,1,1,0,1.715Zm0-5.143a.857.857,0,1,1,0-1.715h8.568a.857.857,0,1,1,0,1.715Z"
                transform="translate(-15528.002 -12057.998)"
              />
            </svg>
          </Link>
          <Link
            to="/reminders"
            className={
              location.pathname === "/reminders" ||
              location.pathname === "/new-reminder"
                ? "active"
                : ""
            }
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="23.602"
              height="24"
              viewBox="0 0 23.602 24"
            >
              <path
                id="np_alarm_3715853_000000"
                d="M10.9,6.191l-3.989,3.99,1.21,1.21L12.114,7.4Zm15.624,0L25.318,7.4l3.989,3.99,1.21-1.21Zm-7.6,1.744A11.128,11.128,0,1,0,30.057,19.063,11.141,11.141,0,0,0,18.929,7.935Zm0,1.712a9.416,9.416,0,1,1-9.416,9.416,9.4,9.4,0,0,1,9.416-9.416Zm-.856,4.288V19.92h5.987V18.207H19.785V13.936Z"
                transform="translate(-6.915 -6.191)"
              />
            </svg>
          </Link>
          <Link
            to="/profile-inner"
            className={location.pathname === "/profile-inner" ? "active" : ""}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
            >
              <path
                id="np_profile_339269_000000"
                d="M39.027,37.817a9.512,9.512,0,0,0-5.174-4,4.686,4.686,0,1,0-5.709,0,9.51,9.51,0,0,0-5.173,4,10.542,10.542,0,1,1,16.055,0M27.771,30.131A3.228,3.228,0,1,1,31,33.358a3.232,3.232,0,0,1-3.229-3.227M31,41.542a10.486,10.486,0,0,1-7-2.682c.017-.023.047-.035.062-.062a8.032,8.032,0,0,1,13.871,0,.652.652,0,0,0,.061.068A10.491,10.491,0,0,1,31,41.542M31,19A12,12,0,1,0,43,31,12.014,12.014,0,0,0,31,19"
                transform="translate(-18.999 -19)"
              />
            </svg>
          </Link>
        </div>
      </div>
    </IonFooter>
  ) : null;
};

export default Footer;
