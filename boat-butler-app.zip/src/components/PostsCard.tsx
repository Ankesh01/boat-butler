import {
  IonButton,
  IonIcon,
  IonImg,
  IonModal,
  IonPopover,
  useIonToast,
} from "@ionic/react";
import {
  arrowRedoOutline,
  bookmarkOutline,
  bookmarkSharp,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  ellipsisHorizontalCircleSharp,
  flagOutline,
  thumbsUpOutline,
  thumbsUpSharp,
} from "ionicons/icons";
import { useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import moment from "moment";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import {
  IPropsInterface,
  ISharedPostInterface,
} from "../interfaceModules/ICommunityInterface";
import {
  likePostAction,
  reportPostAction,
  unlikePostAction,
} from "../redux/action-creators/postsAction";
import { isImageFile } from "../utils/Helper";

import userProfileImg from "../images/user-profile-img.png";

const PostsCard = (props: IPropsInterface) => {
  const { t: translation } = useTranslation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [popoverState, setShowPopover] = useState<{
    showPopover: boolean;
    event?: Event;
    type_id: string;
  }>({
    showPopover: false,
    event: undefined,
    type_id: "",
  });
  const [disabled, setDisabled] = useState(false);
  const [present, dismiss] = useIonToast();
  const history = useHistory();
  const [sharedPost, setSharedPost] = useState<ISharedPostInterface[]>([]);
  const [showModal, setShowModal] = useState(false);
  useEffect(() => {
    setSharedPost(props?.post?.shared_post_detail);
  }, [props]);

  const handleUnLike = async (_id: string, type: string) => {
    setDisabled(true);
    let response = await unlikePostAction({
      _id: _id,
      userId: authData._id,
      type: type,
    });
    let post = props?.post;
    post.total = response?.data?.data?.total;

    props.updatePostLike(post);
    setDisabled(false);
  };

  const handleLike = async (_id: string, type: string) => {
    setDisabled(true);
    console.log("---_id type-", _id, type);
    if (type === "report") {
      setShowModal(false);
      let response = await reportPostAction({
        _id: _id,
        userId: authData._id,
        type,
      });

      if (response?.data?.success) {
        setShowPopover((prevState) => ({ ...prevState, showPopover: false }));
        present("Post reported successfully", 2000);

        props.refreshPostList();
      }

      // fetchPostDetail();
    }
    let response = await likePostAction({
      _id: _id,
      userId: authData._id,
      type: type,
    });

    let post = props?.post;

    post.total = response?.data?.data?.total;

    props.updatePostLike(post);
    setDisabled(false);
  };

  return (
    <div>
      {/* topic-card start */}
      <div className='topic-card topic-card-border' key={props.index}>
        <div className='card-head'>
          <div className='heading'>
            {props?.post?.userInfo?.[0]?.["image"] &&
            props?.post?.userInfo?.[0]?.["image"].length > 0 ? (
              <div className='user-img'>
                <IonImg src={props?.post?.userInfo?.[0]?.["image"]} />
              </div>
            ) : (
              <div className='user-img'>
                <IonImg src={userProfileImg} />
              </div>
            )}

            <div className='heading-inner'>
              <h5>
                {translation("post_by")}{" "}
                <span>{props?.post?.userInfo?.[0]?.["name"]}</span>
              </h5>

              <p>
                {"   "}
                {moment(props?.post?.created_ts).format("MMM DD, YYYY")} at{" "}
                {moment(props?.post?.created_ts).format("hh:m A")}
              </p>
            </div>
          </div>
          {/* ellipsisHorizontalCircleSharp */}
          <div className='card-head-btn'>
            <a
              className='link-icon-btn tertiary-btn'
              onClick={(e) => {
                e.persist();
                setShowPopover({
                  showPopover: true,
                  event: e as unknown as Event,
                  type_id: props?.post?._id,
                });
              }}
            >
              {props?.post?.reported?.find(
                ({ user_id }: any) => user_id === authData._id
              ) ? (
                <IonIcon icon={ellipsisHorizontalCircleSharp} />
              ) : (
                <IonIcon icon={ellipsisHorizontalCircleOutline} />
              )}
            </a>
          </div>
        </div>

        <Link to={`/post-detail/${props?.post?._id}`}>
          <div className='card-mid'>
            <div className='content'>
              <p>{props?.post?.description ? props?.post?.description : ""}</p>
            </div>
            {props?.post?.media_file ? (
              <div className='topic-img'>
                {isImageFile(props?.post?.media_file) ? (
                  <IonImg src={props?.post?.media_file} />
                ) : (
                  <video width='100%' height='230' controls>
                    <source src={props?.post?.media_file}></source>
                  </video>
                )}
              </div>
            ) : (
              ""
            )}
          </div>
        </Link>

        {/* inner topic-card start */}
        {sharedPost && sharedPost?.length > 0 && (
          <div
            className='topic-card topic-card-border inner-topic-card'
            key={props.index}
          >
            <div className='card-head'>
              <div className='heading'>
                <div className='user-img'>
                  {!!sharedPost[0]?.post_creator_detail?.[0]?.["image"] && (
                    <IonImg
                      src={sharedPost[0].post_creator_detail?.[0]?.["image"]}
                    />
                  )}
                </div>
                <div className='heading-inner'>
                  <h5>
                    {translation("post_by")}{" "}
                    <span>
                      {sharedPost?.[0]?.post_creator_detail?.[0]?.["name"]}
                    </span>
                  </h5>

                  <p>
                    {"   "}
                    {moment(sharedPost?.[0]?.created_ts).format(
                      "MMM DD, YYYY"
                    )}{" "}
                    at {moment(sharedPost?.[0]?.created_ts).format("hh:m A")}
                  </p>
                </div>
              </div>
            </div>
            <Link to={`/post-detail/${sharedPost?.[0]?._id}`}>
              <div className='card-mid'>
                <div className='content'>
                  <p>
                    {sharedPost?.[0]?.description
                      ? sharedPost?.[0]?.description
                      : ""}
                  </p>
                </div>
                {sharedPost[0]?.media_file ? (
                  <div className='topic-img'>
                    {isImageFile(sharedPost[0]?.media_file.toLowerCase()) ? (
                      <IonImg src={sharedPost[0]?.media_file} />
                    ) : (
                      <video width='100%' height='230' controls>
                        <source src={sharedPost[0]?.media_file}></source>
                      </video>
                    )}
                  </div>
                ) : (
                  ""
                )}
              </div>
            </Link>
          </div>
        )}
        {/* inner topic-card end */}
        {props.role === "guest" || props.role === "requested" ? (
          ""
        ) : (
          <div className='card-bottom'>
            <div className='links'>
              <ul>
                <li>
                  <Link to={`/post-detail/${props?.post?._id}`}>
                    <IonIcon icon={chatboxOutline} />{" "}
                    {props?.post?.post_comments?.[0]?.total}
                  </Link>
                </li>
                <li>
                  {props?.post?.total?.like?.includes(authData._id) ? (
                    <IonButton
                      className='icon-btn primary-icon-btn'
                      disabled={disabled}
                      onClick={() => handleUnLike(props?.post?._id, "like")}
                    >
                      <IonIcon icon={thumbsUpSharp} />
                    </IonButton>
                  ) : (
                    <IonButton
                      className='icon-btn primary-icon-btn'
                      disabled={disabled}
                      onClick={() => handleLike(props?.post?._id, "like")}
                    >
                      <IonIcon icon={thumbsUpOutline} />
                    </IonButton>
                  )}
                  {props?.post?.total?.like?.length}
                </li>
                {console.log(
                  "report",
                  props?.post?.reported?.find(({ user_id }: any) =>
                    console.log("user_id", user_id)
                  )
                )}
                <li>
                  {/* array1.find(element => element > 10) */}
                  {
                    // props?.post?.total?.bookmarks?.includes(authData._id)
                    props?.post?.total?.bookmarks?.find(
                      ({ user_id }: any) => user_id === authData._id
                    ) ? (
                      <IonButton
                        className='icon-btn primary-icon-btn'
                        onClick={() =>
                          handleUnLike(props?.post?._id, "bookmarks")
                        }
                      >
                        <IonIcon icon={bookmarkSharp} />
                      </IonButton>
                    ) : (
                      <IonButton
                        className='icon-btn primary-icon-btn'
                        onClick={() =>
                          handleLike(props?.post?._id, "bookmarks")
                        }
                      >
                        <IonIcon icon={bookmarkOutline} />
                      </IonButton>
                    )
                  }
                </li>
                <li>
                  <Link to={`/post-share/${props?.post?._id}`}>
                    <IonIcon icon={arrowRedoOutline} />
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>

      <IonPopover
        className='theme-popover'
        event={popoverState.event}
        isOpen={popoverState.showPopover}
        onDidDismiss={() =>
          setShowPopover({
            showPopover: false,
            event: undefined,
            type_id: "",
          })
        }
      >
        <ul className='popover-details'>
          <li>
            <a onClick={() => setShowModal(true)}>
              <IonIcon icon={flagOutline} />
              {translation("report")}
            </a>
          </li>
        </ul>
      </IonPopover>
      <IonModal
        className='theme-modal delete-account-modal'
        isOpen={showModal}
        breakpoints={[0.1, 0.5, 1]}
        initialBreakpoint={0.9}
      >
        <div className='modal-inner'>
          <div className='modal-header text-center'>
            <div className='modal-heading'>
              <h3>
                {translation("are_you_sure_you_want_to_report_this_post")}
              </h3>
            </div>
          </div>
          <div className='modal-body'>
            <div className='d-flex justify-content-center'>
              <IonButton
                onClick={() => {
                  handleLike(popoverState.type_id, "report");
                }}
                className='theme-button primary-btn'
              >
                {translation("yes")}
              </IonButton>
              <IonButton
                onClick={() => setShowModal(false)}
                className='theme-button primary-outline-btn'
              >
                {translation("no")}
              </IonButton>
            </div>
          </div>
        </div>
      </IonModal>
    </div>
  );
};

export default PostsCard;
