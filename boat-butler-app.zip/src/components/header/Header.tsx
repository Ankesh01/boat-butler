import {
  IonButton,
  IonButtons,
  IonHeader,
  IonIcon,
  IonImg,
  IonMenuButton,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { Link, useHistory, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";

import "./Header.scss";

import toolbarIconImg from "../../images/100-X-100.png";
import { arrowBack, person } from "ionicons/icons";

const Header = (props: any) => {
  const history = useHistory();
  const location = useLocation();
  const [isMainPage, setIsMainPage] = useState(false);

  const mainPageList = ["/", "/reminders", "/home", "/profile-inner"];

  useEffect(() => {
    setIsMainPage(mainPageList.includes(location.pathname));
  }, [location.pathname]);

  return (
    <IonHeader
      className={`common-header ${
        props?.title === "Community" ? "primary-header" : ""
      }`}
    >
      <div className="main-container">
        <IonToolbar>
          {isMainPage ? (
            <IonButtons slot="start" className="toolbar-btn">
              <IonMenuButton>
                <IonImg src={toolbarIconImg} />
              </IonMenuButton>
            </IonButtons>
          ) : (
            <IonButton
              slot="start"
              className="icon-btn dark-icon-btn"
              onClick={() => history.goBack()}
            >
              <IonIcon icon={arrowBack} />
            </IonButton>
          )}

          <IonTitle className="text-center">{props?.title}</IonTitle>

          <div className="header-btn" slot="end">
            {props.show_icon ? (
              <div className="user-notifications-icon">
                <Link to={`/requests/${props.community_id}`}>
                  <IonIcon icon={person} />
                  {props?.count > 0 ? <span>{props?.count}</span> : ""}
                </Link>
              </div>
            ) : (
              ""
            )}
          </div>
        </IonToolbar>
      </div>
    </IonHeader>
  );
};

export default Header;
