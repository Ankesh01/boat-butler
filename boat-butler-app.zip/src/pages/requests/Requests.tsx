import {
  IonButton,
  IonContent,
  IonImg,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonSpinner,
} from "@ionic/react";
import { useTranslation } from "react-i18next";
import { useEffect, useState } from "react";

import "./Requests.scss";
import userProfileImg from "../../images/user-profile-img.png";

import Header from "../../components/header/Header";
import {
  getCommunityDetails,
  requestAction,
} from "../../redux/action-creators/communities";
import { IRequestInterface } from "../../interfaceModules/IRequestInterface";

const Requests: React.FC = () => {
  const [communityMembers, setcommunityMembers] = useState([]);
  const { t: translation } = useTranslation();
  const [spin, setSpin] = useState(false);
  useEffect(() => {
    fetchCommunity(true, 0);
  }, []);

  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });

  const community_id = location.pathname.includes("/requests")
    ? location.pathname.split("/")?.[2]
    : "";

  /**
   * @method to fetch community
   * @param firstLoad
   * @param offset
   */
  const fetchCommunity = async (firstLoad: boolean, offset: number) => {
    setSpin(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      const result = await getCommunityDetails({
        _id: community_id,
        status: "Pending",
      });

      if (result?.data?.success) {
        setcommunityMembers(
          firstLoad
            ? result?.data?.data?.res
            : (prevState) => [...prevState, ...result?.data?.data?.res]
        );
        // setPaginationState((prevState) => ({
        //   ...prevState,
        //   prevOffset: offset,
        //   offset: prevState.offset + 5,
        //   hasMore: true,
        // }));
        setPaginationState((prevState) => ({
          ...prevState,
          prevOffset:
            result?.data?.data?.res.length > 0
              ? offset
              : offset
              ? offset - 5
              : 0,
          offset:
            result?.data?.data?.res.length > 0 ? prevState.offset + 5 : offset,
          hasMore: result?.data?.data?.res.length > 0,
        }));
      } else {
        setPaginationState((prevState) => ({
          ...prevState,
          hasMore: false,
        }));
      }
    } else {
      setPaginationState((prevState) => ({
        ...prevState,
        hasMore: false,
      }));
    }
    setSpin(false);
  };

  /**
   * @method to load more data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchCommunity(false, paginationState.offset);
      ev.target.complete();
      // if (data.length == 1000) {
      //   setInfiniteDisabled(true);
      // }
    }, 500);
  };

  /**
   * @method to handle request
   * @param status
   * @param user_id
   */
  const handleRequest = async (status: string, user_id: string) => {
    const response = await requestAction(status, user_id, community_id);
    if (response?.data?.success) {
      fetchCommunity(true, 0);
    }
  };

  return (
    <>
      <Header title={"Requests"} />
      <IonContent fullscreen>
        <div className="requests-page">
          <div className="main-container">
            {spin && (
              <span>
                <IonSpinner />
              </span>
            )}
            <div className="requests-card-list">
              {communityMembers && communityMembers.length > 0 ? (
                communityMembers.map((member: IRequestInterface) => {
                  return (
                    <div className="requests-card">
                      <div className="card-img">
                        <IonImg
                          src={
                            member.community_user_details.image
                              ? member.community_user_details.image
                              : userProfileImg
                          }
                        />
                      </div>

                      <div className="card-info">
                        <div className="name">
                          <h2>{member.community_user_details.name}</h2>
                        </div>
                        <div className="rider">
                          <p>{translation("business_advisor")}</p>
                        </div>
                        <div className="action-btn">
                          <IonButton
                            type="button"
                            className="theme-button white-btn"
                            onClick={() => {
                              handleRequest(
                                "Rejected",
                                member.community_user_details._id
                              );
                            }}
                          >
                            <span>{translation("decline")}</span>
                          </IonButton>
                          <IonButton
                            type="button"
                            className="theme-button primary-btn"
                            onClick={() => {
                              handleRequest(
                                "Accepted",
                                member.community_user_details._id
                              );
                            }}
                          >
                            <span>{translation("accept")}</span>
                          </IonButton>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <>{spin ? "" : translation("no_pending_requests")}</>
              )}
            </div>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={!paginationState.hasMore}
            >
              <IonInfiniteScrollContent
                loadingSpinner="bubbles"
                loadingText="Loading more data..."
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Requests;
