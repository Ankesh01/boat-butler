import { useForm, Controller } from "react-hook-form";
import { RootStateOrAny, useSelector } from "react-redux";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useState } from "react";
import {
  IonButton,
  IonContent,
  IonIcon,
  IonInput,
  IonLabel,
  useIonToast,
  IonSpinner,
} from "@ionic/react";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import { IChangePasswordState } from "../../interfaceModules/IProfileInterface";
import { ChangePasswordValidationSchema } from "../../utils/validationschema";
import { ChangePasswordAction } from "../../redux/action-creators";
import "./ChangePassword.scss";
import { keyOutline } from "ionicons/icons";
import Header from "../../components/header/Header";

const ChangePassword: React.FC = () => {
  const [present, dismiss] = useIonToast();
  const [showLoader, setshowLoader] = useState(false);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const { t: translation } = useTranslation();
  const [newPass, setnewpass] = useState(false);
  const [oldPass, setoldpass] = useState(false);
  const [confPass, setconfpass] = useState(false);
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<IChangePasswordState>({
    resolver: yupResolver(ChangePasswordValidationSchema()),
  });

  const history = useHistory();

  /**
   * @method to change password
   * @param data
   */
  const onSubmit = async (data: IChangePasswordState) => {
    setshowLoader(true);
    await ChangePasswordAction({ ...data, email: authData.email }).then(
      (res) => {
        if (res?.data?.data?.success) {
          present(translation("password_updated_successfully"), 2000);
          history.push({ pathname: "/login" });
        } else {
          present(res?.data?.data?.message, 2000);
        }
      }
    );
    setshowLoader(false);
  };

  return (
    <>
      <Header title={"Change Password"} />
      <IonContent fullscreen>
        <div className="change-password-page">
          <div className="main-container">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-inner">
                <div className="form-group input-label">
                  <IonLabel>{translation("old_password")}</IonLabel>
                  <div className="right-icon-input">
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className="form-control"
                          type={oldPass ? "text" : "password"}
                          placeholder={translation("old_password")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="password"
                      control={control}
                    />
                    <a>
                      <IonIcon
                        icon={keyOutline}
                        onClick={() => {
                          setoldpass(!oldPass);
                        }}
                      />
                    </a>
                  </div>

                  <div className="message error">
                    {errors && errors?.password && (
                      <p>{errors?.password?.message}</p>
                    )}
                  </div>
                </div>
                <div className="form-group input-label">
                  <IonLabel>{translation("new_password")}</IonLabel>
                  <div className="right-icon-input">
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className="form-control"
                          type={newPass ? "text" : "password"}
                          placeholder={translation("new_password")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="newpassword"
                      control={control}
                    />
                    <a>
                      <IonIcon
                        icon={keyOutline}
                        onClick={() => {
                          setnewpass(!newPass);
                        }}
                      />
                    </a>
                  </div>

                  <div className="message error">
                    {errors && errors?.newpassword && (
                      <p>{errors?.newpassword?.message}</p>
                    )}
                  </div>
                </div>
                <div className="form-group input-label">
                  <IonLabel>{translation("confirm_password")}</IonLabel>
                  <div className="right-icon-input">
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className="form-control"
                          type={confPass ? "text" : "password"}
                          placeholder={translation("confirm_password")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="confirm_password"
                      control={control}
                    />
                    <a>
                      <IonIcon
                        icon={keyOutline}
                        onClick={() => {
                          setconfpass(!confPass);
                        }}
                      />
                    </a>
                  </div>

                  <div className="message error">
                    {errors && errors?.confirm_password && (
                      <p>{errors?.confirm_password?.message}</p>
                    )}
                  </div>
                </div>

                <div className="profile-btn">
                  <IonButton
                    expand="block"
                    className="theme-button primary-btn"
                    onClick={handleSubmit(onSubmit)}
                    type="submit"
                  >
                    {translation("change_password")}
                  </IonButton>
                </div>
                {showLoader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ChangePassword;
