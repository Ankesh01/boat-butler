import {
  IonContent,
  IonIcon,
  IonImg,
  IonSpinner,
  IonButton,
  IonFabButton,
  IonFab,
  IonRefresher,
  IonRefresherContent,
  RefresherEventDetail,
  IonPopover,
  IonModal,
  useIonToast,
} from "@ionic/react";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import "../businessDirectory/BusinessDirectory.scss";

import {
  getCommunityList,
  joinCommunity,
  reportCommunityAction,
} from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import {
  chevronDownCircleOutline,
  createOutline,
  ellipsisHorizontalCircleOutline,
  flagOutline,
  pencilOutline,
} from "ionicons/icons";
import {
  ICommunityList,
  IJoinedCommunityInterface,
  ISuggestedCommunityInterface,
} from "../../interfaceModules/ICommunityInterface";

const CommunityList: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const [present, dismiss] = useIonToast();
  const [popoverState, setShowPopover] = useState<{
    showPopover: boolean;
    event?: Event;
    type_id: string;
  }>({
    showPopover: false,
    event: undefined,
    type_id: "",
  });
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [communityList, setCommunityList] = React.useState<ICommunityList[]>(
    []
  );

  const [showModal, setShowModal] = useState(false);
  const [joinedCommunity, setJoinedCommunity] = React.useState<
    IJoinedCommunityInterface[]
  >([]);
  const [suggestedCommunity, setSuggestedCommunity] = React.useState<
    ISuggestedCommunityInterface[]
  >([]);

  const [showLoader, setShowLoader] = React.useState(false);

  useEffect(() => {
    fetchCommunityList(true, 0);
  }, []);

  /**
   * @method to fetch List of Community
   * @param firstLoad
   * @param offset
   */
  const fetchCommunityList = async (firstLoad: boolean, offset: number) => {
    setShowLoader(true);
    const result = await getCommunityList(authData._id, "All", offset);

    if (result?.data?.data?.myCommunityList?.length > 0) {
      setCommunityList(result?.data?.data?.myCommunityList);
    }
    if (result?.data?.data?.joinedCommunity?.length > 0) {
      setJoinedCommunity(result?.data?.data?.joinedCommunity);
    }
    if (result?.data?.data?.suggestedCommunityList?.length > 0) {
      setSuggestedCommunity(result?.data?.data?.suggestedCommunityList);
    }
    setShowLoader(false);
  };

  /**
   * @method to redirect on community-listing page & fetch data corresponding to its type
   * @param event
   * @param name
   */
  const Direct = (event: any, name: string) => {
    history.push({
      pathname: "/community-listing",

      state: {
        type: name,
      },
    });
  };

  /**
   * @method to handle Join Community
   * @param community_id
   */
  const handleJoinCommunity = async (community_id: string) => {
    const response = await joinCommunity({
      community_id,
      userId: authData._id,
    });
    if (response?.data?.success) {
      fetchCommunityList(true, 0);
    }
  };

  /**
   * @method to refresh page
   * @param event
   */
  function doRefresh(event: CustomEvent<RefresherEventDetail>) {
    setTimeout(() => {
      event.detail.complete();
    }, 1000);
  }

  const handleActivity = async (type: string) => {
    setShowModal(false);
    console.log("type_id------->", popoverState.type_id);
    let response = await reportCommunityAction({
      type_id: popoverState.type_id,
      userId: authData._id,
      type,
    });

    if (response?.data?.success) {
      setShowPopover((prevState) => ({ ...prevState, showPopover: false }));
      present("Community reported successfully", 2000);
      fetchCommunityList(true, 0);
      // history.goBack();
    }
  };

  // console.log("communityList-----", communityList);

  return (
    <>
      <Header title={"Community List"} />
      <IonContent fullscreen>
        <div className="business-directory-page">
          <IonRefresher slot="fixed" onIonRefresh={doRefresh}>
            <IonRefresherContent
              pullingIcon={chevronDownCircleOutline}
              pullingText="Pull to refresh"
              refreshingSpinner="circles"
            ></IonRefresherContent>
          </IonRefresher>
          <div className="main-container">
            <div>
              <div className="mb-30">
                <div className="common-heading">
                  <div className="heading">
                    <h2>{translation("my_community")}</h2>
                  </div>
                  <div className="btn-inline">
                    <a
                      onClick={(e) => Direct(e, "My")}
                      className="link-btn dark-link-btn"
                    >
                      {translation("view_all")}
                    </a>
                  </div>
                </div>
                {showLoader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
                {communityList && communityList.length > 0 ? (
                  communityList.map(
                    (item: ICommunityList, index: number) =>
                      index < 2 && (
                        <>
                          <Link
                            className="service-providers-card"
                            key={index}
                            to={`/community/${item._id}`}
                          >
                            <div className="card-img">
                              <IonImg src={item.image} />
                            </div>
                            <div className="card-detail">
                              <div className="heading">
                                <h3>{item.title}</h3>
                                <span></span>
                              </div>
                              <div className="mid">
                                <p></p>
                              </div>
                            </div>
                          </Link>
                        </>
                      )
                  )
                ) : (
                  <div className="message info-message text-center">
                    <p>{showLoader ? "" : "No Community Found"}</p>
                  </div>
                )}
              </div>
              <div className="mb-30">
                <div className="common-heading">
                  <div className="heading">
                    <h2>{translation("joined_by_me")}</h2>
                  </div>
                  {joinedCommunity && joinedCommunity.length > 0 ? (
                    <div className="btn-inline">
                      <a
                        onClick={(e) => Direct(e, "Joined")}
                        className="link-btn dark-link-btn"
                      >
                        {translation("view_all")}
                      </a>
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                {showLoader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
                {joinedCommunity && joinedCommunity.length > 0 ? (
                  joinedCommunity.map(
                    (item: IJoinedCommunityInterface, index: number) =>
                      index < 2 && (
                        <>
                          {/* <Link
                            className="service-providers-card"
                            key={index}
                            to={`/community/${item.community_id}`}
                          > */}
                          <div
                            className="service-providers-card"
                            onClick={() =>
                              history.push(`/community/${item.community_id}`)
                            }
                          >
                            <div className="card-img">
                              <IonImg src={item?.community_detail?.image} />
                            </div>
                            <div className="card-detail">
                              <div className="heading">
                                <h3>{item?.community_detail?.title}</h3>
                                <span></span>{" "}
                              </div>
                              <div className="mid">
                                <p></p>
                              </div>
                            </div>
                            <div className="action-btn">
                              <a
                                className="link-icon-btn tertiary-btn"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  e.persist();

                                  setShowPopover({
                                    showPopover: true,
                                    event: e as unknown as Event,
                                    type_id: item.community_id,
                                  });
                                }}
                              >
                                <IonIcon
                                  icon={ellipsisHorizontalCircleOutline}
                                />
                              </a>
                            </div>
                          </div>

                          {/* </Link> */}
                        </>
                      )
                  )
                ) : (
                  <div className="message info-message text-center">
                    <p>{showLoader ? "" : "No Community Found"}</p>
                  </div>
                )}
              </div>
              <div className="mb-30">
                <div className="common-heading">
                  <div className="heading">
                    <h2>{translation("suggested")}</h2>
                  </div>
                  <div className="btn-inline">
                    <a
                      onClick={(e) => Direct(e, "Suggested")}
                      className="link-btn dark-link-btn"
                    >
                      {translation("view_all")}
                    </a>
                  </div>
                </div>
                {showLoader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
                {suggestedCommunity && suggestedCommunity.length > 0 ? (
                  suggestedCommunity.map(
                    (item: ISuggestedCommunityInterface, index: number) =>
                      index < 2 && (
                        <>
                          <Link
                            className="service-providers-card"
                            key={index}
                            to={`/community/${item._id}`}
                          >
                            <div className="card-img">
                              <IonImg src={item?.image} />
                            </div>
                            <div className="card-detail">
                              <div className="heading">
                                <h3>{item?.title}</h3>
                                <span></span>
                              </div>
                              <IonButton
                                className="theme-button primary-btn btn-sm"
                                onClick={() => handleJoinCommunity(item._id)}
                              >
                                {translation("join")}
                              </IonButton>
                            </div>
                          </Link>
                        </>
                      )
                  )
                ) : (
                  <div className="message info-message text-center">
                    <p>{showLoader ? "" : "No Community Found"}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <IonFab
          className="theme-fab-btn primary-btn"
          slot="fixed"
          vertical="bottom"
          horizontal="end"
        >
          <IonFabButton onClick={() => history.push("/create-community")}>
            <IonIcon icon={createOutline} />
          </IonFabButton>
        </IonFab>
        <IonPopover
          className="theme-popover"
          event={popoverState.event}
          isOpen={popoverState.showPopover}
          onDidDismiss={() =>
            setShowPopover({
              showPopover: false,
              event: undefined,
              type_id: "",
            })
          }
        >
          <ul className="popover-details">
            <li>
              <a onClick={() => setShowModal(true)}>
                <IonIcon icon={flagOutline} />
                {translation("report")}
              </a>
            </li>
          </ul>
        </IonPopover>
        <IonModal
          className="theme-modal delete-account-modal"
          isOpen={showModal}
          breakpoints={[0.1, 0.5, 1]}
          initialBreakpoint={0.9}
        >
          <div className="modal-inner">
            <div className="modal-header text-center">
              <div className="modal-heading">
                <h3>
                  {translation(
                    "are_you_sure_you_want_to_report_this_community"
                  )}
                </h3>
              </div>
            </div>
            <div className="modal-body">
              <div className="d-flex justify-content-center">
                <IonButton
                  onClick={() => {
                    handleActivity("report");
                  }}
                  className="theme-button primary-btn"
                >
                  {translation("yes")}
                </IonButton>
                <IonButton
                  onClick={() => setShowModal(false)}
                  className="theme-button primary-outline-btn"
                >
                  {translation("no")}
                </IonButton>
              </div>
            </div>
          </div>
        </IonModal>
      </IonContent>
    </>
  );
};
export default CommunityList;
