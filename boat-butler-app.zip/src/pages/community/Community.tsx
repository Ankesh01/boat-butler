import {
  IonButton,
  IonContent,
  IonFab,
  IonFabButton,
  IonIcon,
  IonImg,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonSpinner,
  IonTextarea,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useForm } from "react-hook-form";
import { useState, useEffect } from "react";
import { useHistory, useLocation } from "react-router";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import {
  cameraOutline,
  closeCircleOutline,
  createOutline,
} from "ionicons/icons";
import "./Community.scss";
import userProfileImg from "../../images/user-profile-img.png";
import { CommunityValidationSchema } from "../../utils/validationschema";
import {
  ICommunityDetailInterface,
  IPostInterface,
} from "../../interfaceModules/ICommunityInterface";
import {
  getCommunityById,
  getCommunityPosts,
  joinCommunity,
  getCommunityDetails,
} from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import { isImageFile, uploadFileOnS3 } from "../../utils/Helper";
import { createPostAction } from "../../redux/action-creators/postsAction";
import { deleteFile } from "../../redux/action-creators/FileUpload";
import PostsCard from "../../components/PostsCard";

const Community: React.FC = () => {
  const [community, setCommunity] = useState<ICommunityDetailInterface>();
  const history = useHistory();
  const { t: translation } = useTranslation();

  const [buttonDisable, setButtonDisable] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [postList, setPostList] = useState<IPostInterface[]>([]);
  const [spin, setSpin] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [role, setRole] = useState("");
  const [postspinner, setPostSpinner] = useState(false);
  const [isInfiniteDisabled, setisInfiniteDisabled] = useState(false);
  const [communityMembers, setcommunityMembers] = useState({
    total_count: 0,
    response: [],
  });
  const [pendingRequests, setpendingRequests] = useState({ total_count: 0 });
  const location = useLocation();
  const community_id = location.pathname.includes("/community")
    ? location.pathname.split("/")?.[2]
    : "";
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [image, setImage] = useState<string[]>([]);
  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });

  const [present, dismiss] = useIonToast();

  useEffect(() => {
    fetchCommunity();
    fetchCommunityPosts(true, 0);
  }, []);

  /**
   * @method to fetch Community
   */
  const fetchCommunity = async () => {
    const response = await getCommunityById(community_id, authData._id);
    setCommunity(response?.data?.data?.res ? response?.data?.data?.res : []);
    setRole(response?.data?.data?.role ? response?.data?.data?.role : "");

    const accepted = await getCommunityDetails({
      _id: community_id,
      status: "Accepted",
    });

    const pending = await getCommunityDetails({
      _id: community_id,
      status: "Pending",
    });
    setpendingRequests({ total_count: pending?.data?.data?.total_count });
    setcommunityMembers({
      total_count: accepted?.data?.data?.total_count,
      response: accepted?.data?.data?.res,
    });
  };

  /**
   * @method to fetch Post of Community
   * @param firstLoad
   * @param offset
   */
  const fetchCommunityPosts = async (firstLoad: boolean, offset: number) => {
    setShowLoader(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      let result = await getCommunityPosts(community_id, offset, authData._id);
      if (result?.data?.success) {
        setPostList(
          firstLoad
            ? result?.data?.data
            : (prevState) => [...prevState, ...result?.data?.data]
        );
        setPaginationState((prevState) => ({
          ...prevState,
          prevOffset:
            result?.data?.data.length > 0 ? offset : offset ? offset - 5 : 0,
          offset: result?.data?.data.length > 0 ? prevState.offset + 5 : offset,
          hasMore: result?.data?.data.length > 0,
        }));
      } else {
        setPaginationState((prevState) => ({
          ...prevState,
          hasMore: false,
        }));
      }
    } else {
      setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
    }
    setShowLoader(false);
  };

  /**
   * @method to Load more Data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchCommunityPosts(false, paginationState.offset);
      ev.target.complete();
    }, 500);
  };

  /**
   * @method to handle uploaded Image
   * @param event
   */
  const handleUpload = async (event: any) => {
    let target = event.target;
    setSpin(true);
    const { files } = target;

    const fileUrlList = await uploadFileOnS3(files, "posts");

    setImage(fileUrlList);
    setSpin(false);
  };

  /**
   * @method to handle Remove Image
   */
  const handleRemoveImage = () => {
    setSpin(true);
    const file: any = [...image];
    setImage([]);
    // state.receipts.splice(index,  1);
    // setSelectedService({ ...state });
    // setUpdateService(true);

    deleteFile([file]);
    setSpin(false);
  };

  const {
    control,
    resetField,
    handleSubmit,
    reset,

    clearErrors,
    formState: { errors },
  } = useForm<ICommunityDetailInterface>({
    resolver: yupResolver(CommunityValidationSchema()),
  });

  /**
   * @method to create Post when submitted
   * @param data
   */
  const onSubmit = async (data: ICommunityDetailInterface) => {
    setDisabled(true);
    let response;

    response = await createPostAction({
      ...data,
      user_id: authData._id,
      media_file: image[0],
      type: "community",
      type_item_id: community_id,
    });

    if (response?.data?.message && response?.data?.success) {
      setImage([]);
      reset({});
      present(response?.data?.message, 2000);
      setTimeout(() => {
        fetchCommunityPosts(true, 0);
      }, 1000);
    } else {
      present(response?.data?.message, 2000);
    }
    setPostSpinner(false);
    setDisabled(false);
  };

  /**
   * @method to Update Like on Post
   * @param data
   * @param type
   * @param index
   */
  const updatePostLike = (
    data: IPostInterface,
    type: string,
    index: number
  ) => {
    // if (type === "report") {
    //   fetchCommunityPosts(true, 0);
    // } else {
    let postListTemp = [...postList];
    postListTemp[index] = data;

    setPostList(postListTemp);
    // }
  };

  /**
   * @method to Join Community
   */
  const handleJoinCommunity = async () => {
    setButtonDisable(true);
    const response = await joinCommunity({
      community_id,
      userId: authData._id,
    });
    if (response?.data?.success) {
      // fetchCommunityList(true, 0);
      await fetchCommunity();
    }
    setButtonDisable(false);
  };

  const refreshPostList = () => {
    console.log("refreshing community posts");

    setTimeout(() => {
      fetchCommunityPosts(true, 0);
    }, 1000);
  };

  return (
    <>
      <Header
        title={"Community"}
        community_id={community_id}
        show_icon={role === "admin" ? true : false}
        count={pendingRequests?.total_count}
      />
      {/* show_icon={} */}
      <IonContent fullscreen>
        {postspinner && (
          <span>
            <IonSpinner />
          </span>
        )}
        <div className="community-page community-dashboard-page">
          {/* community-dashboard-head start */}
          <div className="community-dashboard-head">
            <div className="main-container">
              <div className="head-inner">
                <div className="name">
                  <div className="circle-img">
                    <IonImg
                      src={
                        community?.image && community?.image.length > 0
                          ? community?.image
                          : userProfileImg
                      }
                    />
                  </div>

                  <h2>{community?.title}</h2>
                </div>

                {role && role === "admin" ? (
                  <>
                    {/* <Link to={`/requests/${community_id}`}>
                      <div className="inline-btn">
                        <p> Pending Requests : {pendingRequests.total_count}</p>
                      </div>
                    </Link> */}
                  </>
                ) : (
                  ""
                )}
                {role && role === "guest" ? (
                  <>
                    {" "}
                    <IonButton
                      type="button"
                      className="theme-button white-btn btn-sm"
                      onClick={() => handleJoinCommunity()}
                      disabled={buttonDisable}
                    >
                      {translation("join")}
                    </IonButton>
                  </>
                ) : (
                  ""
                )}
                {role && role === "requested" ? (
                  <>
                    {" "}
                    <IonButton
                      type="button"
                      className="theme-button white-btn btn-sm"
                      disabled={true}
                    >
                      {translation("pending")}
                    </IonButton>
                  </>
                ) : (
                  ""
                )}

                {(role && role === "admin") || role === "member" ? (
                  <>
                    <div className="circle-list">
                      {communityMembers?.response &&
                      communityMembers?.response.length > 0
                        ? communityMembers.response.map(
                            (item: any, index: number) => {
                              return (
                                <div className="circle-img" key={index}>
                                  <IonImg
                                    src={item.community_user_details.image}
                                  />
                                </div>
                              );
                            }
                          )
                        : ""}

                      {/* <div className="circle-number">
                        <span>{communityMembers.total_count}+</span>
                      </div> */}
                    </div>
                    {/* <div className="circle-img-status"> */}

                    {role === "admin" ? (
                      <>
                        <Link to={`/members/${community_id}`}>
                          <div className="circle-number">
                            <span>
                              {communityMembers.total_count > 0 ? (
                                <>{communityMembers.total_count}+</>
                              ) : (
                                ""
                              )}
                            </span>
                          </div>
                        </Link>
                      </>
                    ) : role === "member" ? (
                      <div className="circle-number">
                        <span>
                          {communityMembers.total_count > 0 ? (
                            <>{communityMembers.total_count}+</>
                          ) : (
                            ""
                          )}
                        </span>
                      </div>
                    ) : (
                      ""
                    )}
                    {/* </div> */}
                  </>
                ) : (
                  ""
                )}
              </div>
            </div>
          </div>

          <div className="main-container">
            {/* post-input-card start */}
            {role === "admin" || role === "member" ? (
              <div className="post-input-card">
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="post-input">
                    <Controller
                      render={({ field }) => (
                        <IonTextarea
                          {...field}
                          rows={6}
                          className="form-control"
                          placeholder="Share your thoughts..."
                          onIonChange={field.onChange}
                        />
                      )}
                      name="description"
                      control={control}
                      rules={{ required: true }}
                      defaultValue=""
                    />
                    {/* <div className="message error">
                    {errors && errors.description && (
                      <p>{errors?.description?.message}</p>
                    )}
                  </div> */}
                  </div>

                  <div className="card-bottom">
                    <div className="form-group mb-0">
                      <div className="file-upload-btn d-inline-block">
                        <input
                          className="file-input"
                          accept="image/*,video/*"
                          type="file"
                          onChange={handleUpload}
                        />
                        <IonButton
                          expand="block"
                          className="icon-btn tertiary-icon-btn"
                        >
                          <IonIcon icon={cameraOutline} />
                        </IonButton>

                        {/* <IonButton
                        expand="block"
                        className="icon-btn tertiary-icon-btn"
                        onClick={() =>
                          handleImages("single", "base64", "boat_image")
                        }
                      > 
                        <IonIcon icon={cameraOutline} />
                       </IonButton> */}
                      </div>
                    </div>

                    <div className="inline-btn">
                      <IonButton
                        type="button"
                        className="theme-button dark-outline-btn btn-sm"
                        onClick={handleSubmit(onSubmit)}
                        disabled={disabled}
                      >
                        Post
                      </IonButton>
                    </div>
                  </div>
                </form>
              </div>
            ) : (
              ""
            )}

            <div className="file-upload-btn">
              {spin && (
                <span>
                  <IonSpinner />
                </span>
              )}
              {image && image?.length > 0 ? (
                <div className="card-head">
                  {/* <IonImg src={image[0]} /> */}
                  {isImageFile(image[0].toLowerCase()) ? (
                    <IonImg src={image[0]} />
                  ) : (
                    <video width="100%" height="230" controls>
                      <source src={image[0]}></source>
                    </video>
                  )}

                  <div className="action-btn">
                    <IonButton
                      type="button"
                      className="icon-btn primary-icon-btn "
                      onClick={() => handleRemoveImage()}
                    >
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>

                  {/* <IonIcon
                              icon={fileTrayStackedSharp}
                            />*/}
                </div>
              ) : (
                ""
              )}
            </div>

            <div>
              {/* topic-card start */}
              {showLoader && (
                <span>
                  <IonSpinner />
                </span>
              )}
              {postList && postList.length > 0 ? (
                postList.map((post: IPostInterface, index: number) => {
                  return (
                    <>
                      <PostsCard
                        post={post}
                        role={role}
                        index={index}
                        updatePostLike={(data: IPostInterface, type: string) =>
                          updatePostLike(data, type, index)
                        }
                        refreshPostList={refreshPostList}
                      />
                    </>
                  );
                })
              ) : (
                <>{showLoader ? "" : "No posts found"}</>
              )}
              {/* topic-card start */}
            </div>

            <div>
              {/* <IonButton expand="block" className="theme-button primary-btn">
                Create
              </IonButton> */}
            </div>
          </div>
        </div>
        {role === "admin" ? (
          <IonFab
            className="theme-fab-btn primary-btn"
            slot="fixed"
            vertical="bottom"
            horizontal="end"
          >
            <IonFabButton
              onClick={() => history.push(`/edit-community/${community_id}`)}
            >
              <IonIcon icon={createOutline} />
            </IonFabButton>
          </IonFab>
        ) : (
          ""
        )}
        <IonInfiniteScroll
          onIonInfinite={loadData}
          threshold="100px"
          disabled={!paginationState.hasMore}
        >
          <IonInfiniteScrollContent
            loadingSpinner="bubbles"
            loadingText="Loading more data..."
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
      </IonContent>
    </>
  );
};
export default Community;
