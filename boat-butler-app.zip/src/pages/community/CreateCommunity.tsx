import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonTextarea,
  useIonToast,
  IonSpinner,
} from "@ionic/react";
import { closeCircleOutline } from "ionicons/icons";
import { useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { RootStateOrAny, useSelector } from "react-redux";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useTranslation } from "react-i18next";

import "./Community.scss";

import { ICreateCommunityInterface } from "../../interfaceModules/ICommunityInterface";
import {
  createCommunityAction,
  editCommunityAction,
  getCommunityById,
} from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import { getPicture } from "../../utils/Helper";
import { CreateCommunityValidationSchema } from "../../utils/validationschema";

const CreateCommunity: React.FC = () => {
  const { t: translation } = useTranslation();
  const [community, setCommunityImg] = useState({
    data: "",
    format: "",
  });
  const [oldImage, setOldImage] = useState("");
  const [showloader, setshowLoader] = useState(false);
  const [spin, setSpin] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [present, dismiss] = useIonToast();
  const location = useLocation();
  const community_id = location.pathname.includes("/edit-community")
    ? location.pathname.split("/")?.[2]
    : "";
  useEffect(() => {
    if (community_id) {
      fetchCommunity();
    }
  }, []);

  /**
   * @method to fetch Community
   */
  const fetchCommunity = async () => {
    const response = await getCommunityById(community_id, authData._id);
    if (response?.data?.data?.res) {
      let community = response?.data?.data?.res;

      setOldImage(response?.data?.data?.res?.image);
      setCommunityImg({ data: response?.data?.data?.res?.image, format: "" }),
        reset({
          title: community.title,
          description: community.description,
        });
    }
    // setCommunity(comm);
  };

  const {
    control,
    resetField,
    handleSubmit,
    reset,

    clearErrors,
    formState: { errors },
  } = useForm<ICreateCommunityInterface>({
    resolver: yupResolver(CreateCommunityValidationSchema()),
  });

  /**
   * @method to handle Images
   * @param number
   * @param type
   * @param name
   * @param index
   * @returns
   */
  const handleImages = async (
    number: string,
    type: string,
    name: string,
    index?: string
  ) => {
    setSpin(true);
    let images: any = await getPicture(number, type);
    if (!images) {
      return null;
    }

    setCommunityImg(images);
    setSpin(false);
    // setCommunityImg((prevState: ICreateCommunityInterface) => ({
    //   ...prevState,
    //   ["image"]: images,
    // }));
  };

  /**
   * @method to edit and create community when submitted
   * @param data
   */
  const onSubmit = async (data: ICreateCommunityInterface) => {
    setshowLoader(true);
    setButtonDisable(true);
    if (community_id) {
      let response = await editCommunityAction({
        ...data,
        _id: community_id,
        user_id: authData._id,
        image: community,
        oldImage: oldImage,
      });
      if (response?.data?.message && response?.data?.success) {
        present(response?.data?.message, 2000);
        setTimeout(() => history.push(`/community/${community_id}`), 2000);
      }
    } else {
      let response = await createCommunityAction({
        ...data,
        image: community,
        user_id: authData._id,
      });
      if (response?.data?.message && response?.data?.success) {
        present(response?.data?.message, 2000);
        setTimeout(
          () => history.push(`/community/${response?.data?.data?._id}`),
          2000
        );
      } else {
        present(response?.data?.message, 2000);
      }
    }
    // setTimeout(() => history.push("/home"), 3000);

    setshowLoader(false);
    setButtonDisable(false);
  };

  return (
    <>
      <Header title={community_id ? "Edit Community" : "Create a community"} />
      <IonContent fullscreen>
        <div className="community-page">
          <div className="main-container">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-group input-label">
                <IonLabel>{translation("community_name")}</IonLabel>
                <Controller
                  render={({ field }) => (
                    <IonInput
                      {...field}
                      type="text"
                      className="form-control"
                      placeholder="Title"
                      onIonChange={field.onChange}
                    />
                  )}
                  name="title"
                  control={control}
                />
                <div className="message info-message">
                  <p className="opacity-3">
                    {translation("community_names_including_capitalisation")}
                  </p>
                </div>
                <div className="message error">
                  {errors && errors.title && <p>{errors?.title?.message}</p>}
                </div>

                <div className="heading">
                  <h2>{translation("conditions")}</h2>
                </div>
                <div className="conditions-inner">
                  <div className="form-group input-label">
                    <Controller
                      render={({ field }) => (
                        <IonTextarea
                          {...field}
                          rows={6}
                          className="form-control"
                          placeholder="Enter Community description"
                          onIonChange={field.onChange}
                        />
                      )}
                      name="description"
                      control={control}
                      rules={{ required: true }}
                      defaultValue=""
                    />

                    <div className="message error">
                      {errors && errors.description && (
                        <p>{errors?.description?.message}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </form>
            <div className="conditions-info">
              {/* <h3>Why do we use it?</h3>
                <p>
                  It is a long established fact that a reader will be distracted
                  by the readable content of a page when looking at its layout.
                  The point of using Lorem Ipsum is that it has a more-or-less
                  normal distribution of letters, as opposed to using ‘Content
                  here, content here’, making it look like readable English.
                </p> */}
            </div>

            <div>
              {community?.data && community.data.length > 0 ? (
                ""
              ) : (
                <IonButton
                  expand="block"
                  className="theme-button dark-outline-btn"
                  onClick={() => handleImages("single", "base64", "boat_image")}
                >
                  {translation("add_photo")}
                </IonButton>
              )}

              {community?.data ? (
                <div className="uploaded-file mt-15">
                  <IonImg
                    src={
                      community?.data
                      // ? community?.image?.data
                      // : userProfileImg
                    }
                    alt=""
                  />
                  <div className="action-btn">
                    <IonButton
                      className="icon-btn primary-icon-btn"
                      type="button"
                      onClick={() => setCommunityImg({ data: "", format: "" })}
                    >
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>
                </div>
              ) : (
                ""
              )}
            </div>

            <div>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit(onSubmit)}
                disabled={buttonDisable}
              >
                {community_id ? "Save" : "Create"}
                {showloader ? <IonSpinner /> : null}
              </IonButton>
            </div>
            {/* <IonButton
              expand="block"
              className="theme-button primary-btn"
              onClick={() =>
                history.push("/community/623bfa1a74a799c0c7b33e8f")
              }
            >
              Community
            </IonButton> */}
          </div>
        </div>
      </IonContent>
    </>
  );
};
export default CreateCommunity;
