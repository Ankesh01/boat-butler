import {
  IonContent,
  IonImg,
  IonSpinner,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonButton,
  IonModal,
  IonIcon,
  IonPopover,
  useIonToast,
} from "@ionic/react";
import React, { useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { RootStateOrAny, useSelector } from "react-redux";

import "../businessDirectory/BusinessDirectory.scss";

import {
  getCommunityList,
  reportCommunityAction,
} from "../../redux/action-creators/communities";
import Header from "../../components/header/Header";
import { ICommunityEachList } from "../../interfaceModules/ICommunityInterface";
import { ellipsisHorizontalCircleOutline, flagOutline } from "ionicons/icons";

const CommunityEachList: React.FC = () => {
  const location: any = useLocation();
  useEffect(() => {
    fetchCommunityList(true, 0);
  }, []);

  const type = location?.state?.type;
  const history = useHistory();
  const [present, dismiss] = useIonToast();
  const [popoverState, setShowPopover] = useState<{
    showPopover: boolean;
    event?: Event;
    type_id: string;
  }>({
    showPopover: false,
    event: undefined,
    type_id: "",
  });
  const [showModal, setShowModal] = useState(false);
  const { t: translation } = useTranslation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [communityList, setCommunityList] = React.useState<
    ICommunityEachList[]
  >([]);
  const [paginationState, setPaginationState] = React.useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });

  const [showLoader, setShowLoader] = React.useState(false);

  const handleActivity = async (type: string) => {
    setShowModal(false);

    let response = await reportCommunityAction({
      type_id: popoverState.type_id,
      userId: authData._id,
      type,
    });
    console.log("handleActivity", response);

    if (response?.data?.success) {
      setShowPopover((prevState) => ({ ...prevState, showPopover: false }));
      present("Community reported successfully", 2000);
      fetchCommunityList(true, 0);
      setPaginationState({
        offset: 0,
        prevOffset: 0,
        hasMore: true,
      });
      // history.goBack();
    }
  };
  /**
   * @method to fetch List of Communities
   * @param firstLoad
   * @param offset
   */
  const fetchCommunityList = async (firstLoad: boolean, offset: number) => {
    setShowLoader(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      const result = await getCommunityList(
        authData._id,
        type,
        paginationState.offset
      );

      let resultKey = "myCommunityList";
      switch (type) {
        case "My": {
          resultKey = "myCommunityList";
          break;
        }
        case "Joined": {
          resultKey = "joinedCommunity";
          break;
        }
        case "Suggested": {
          resultKey = "suggestedCommunityList";
          break;
        }
      }
      console.log("-resultKey---", result);
      // const resultKey = keyMaaping[type : "My" | "Joined" | "Suggested"] as string;

      if (result?.data?.success) {
        setCommunityList(
          firstLoad
            ? result?.data?.data?.[resultKey]
            : [...communityList, ...result?.data?.data?.[resultKey]]
        );

        setPaginationState((prevState) => ({
          ...prevState,
          prevOffset:
            result?.data?.data?.[resultKey].length > 0
              ? offset
              : offset
              ? offset - 5
              : 0,
          offset:
            result?.data?.data?.[resultKey].length > 0
              ? prevState.offset + 5
              : offset,
          hasMore: result?.data?.data?.[resultKey].length > 0,
        }));
      } else {
        setPaginationState((prevState) => ({
          ...prevState,
          hasMore: false,
        }));
      }
    } else {
      setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
    }
    setShowLoader(false);
  };

  /**
   * @method to Load More Data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchCommunityList(false, paginationState.offset);
      ev.target.complete();
      // if (data.length == 1000) {
      //   setInfiniteDisabled(true);
      // }
    }, 500);
  };
  console.log("*************************************************");
  return (
    <div>
      <Header title={"Community List"} />
      <IonContent fullscreen>
        <div className="business-directory-page">
          <div className="main-container">
            <div className="common-heading">
              <div className="heading">
                <h2>
                  {type} {translation("communities")}
                </h2>
              </div>
            </div>

            <div>
              {/* Service Providers start */}
              {showLoader && (
                <span>
                  <IonSpinner />
                </span>
              )}
              {communityList && communityList.length > 0 ? (
                communityList.map((item: any, index: number) => {
                  return (
                    <>
                      {type === "Suggested" || type === "My" ? (
                        <>
                          <Link to={`/community/${item._id}`}>
                            <div className="service-providers-card" key={index}>
                              <div className="card-img">
                                <IonImg src={item.image} />
                              </div>
                              <div className="card-detail">
                                <div className="heading">
                                  <h3>{item.title}</h3>
                                  <span></span>
                                </div>
                                <div className="mid">
                                  <p></p>
                                </div>
                              </div>
                            </div>
                          </Link>
                        </>
                      ) : type === "Joined" ? (
                        <>
                          <>
                            {/* <Link
                            className="service-providers-card"
                            key={index}
                            to={`/community/${item.community_id}`}
                          > */}
                            <div className="service-providers-card">
                              <div
                                className="card-img"
                                onClick={() =>
                                  history.push(
                                    `/community/${item.community_id}`
                                  )
                                }
                              >
                                <IonImg src={item?.community_detail?.image} />
                              </div>
                              <div className="card-detail">
                                <div className="heading">
                                  <h3>{item?.community_detail?.title}</h3>
                                  <span></span>{" "}
                                </div>
                                <div className="mid">
                                  <p></p>
                                </div>

                                <div className="action-btn">
                                  <a
                                    className="link-icon-btn tertiary-btn"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      e.persist();
                                      setShowPopover({
                                        showPopover: true,
                                        event: e as unknown as Event,
                                        type_id: item.community_id,
                                      });
                                    }}
                                  >
                                    <IonIcon
                                      icon={ellipsisHorizontalCircleOutline}
                                    />
                                  </a>
                                </div>
                              </div>
                            </div>

                            {/* </Link> */}
                          </>
                        </>
                      ) : (
                        ""
                      )}
                    </>
                  );
                })
              ) : (
                <>{showLoader ? "" : `No Community Found`}</>
              )}
            </div>
          </div>
          <IonPopover
            className="theme-popover"
            event={popoverState.event}
            isOpen={popoverState.showPopover}
            onDidDismiss={() =>
              setShowPopover({
                showPopover: false,
                event: undefined,
                type_id: "",
              })
            }
          >
            <ul className="popover-details">
              <li>
                <a onClick={() => setShowModal(true)}>
                  <IonIcon icon={flagOutline} />
                  {translation("report")}
                </a>
              </li>
            </ul>
          </IonPopover>
          <IonModal
            className="theme-modal delete-account-modal"
            isOpen={showModal}
            breakpoints={[0.1, 0.5, 1]}
            initialBreakpoint={0.9}
          >
            <div className="modal-inner">
              <div className="modal-header text-center">
                <div className="modal-heading">
                  <h3>
                    {translation(
                      "are_you_sure_you_want_to_report_this_community"
                    )}
                  </h3>
                </div>
              </div>
              <div className="modal-body">
                <div className="d-flex justify-content-center">
                  <IonButton
                    onClick={() => {
                      handleActivity("report");
                    }}
                    className="theme-button primary-btn"
                  >
                    {translation("yes")}
                  </IonButton>
                  <IonButton
                    onClick={() => setShowModal(false)}
                    className="theme-button primary-outline-btn"
                  >
                    {translation("no")}
                  </IonButton>
                </div>
              </div>
            </div>
          </IonModal>
          <IonInfiniteScroll
            onIonInfinite={loadData}
            threshold="100px"
            disabled={!paginationState.hasMore}
          >
            <IonInfiniteScrollContent
              loadingSpinner="bubbles"
              loadingText="Loading more data..."
            ></IonInfiniteScrollContent>
          </IonInfiniteScroll>
        </div>
      </IonContent>
    </div>
  );
};
export default CommunityEachList;
