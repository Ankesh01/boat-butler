import {
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonRow,
  IonSpinner,
} from "@ionic/react";
import { useHistory } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";

import { addOutline } from "ionicons/icons";
import "./Services.scss";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { getBoatServicesByUserId } from "../../redux/action-creators/boatServices";
import { IServiceInterface } from "../../interfaceModules/IServiceInterface";
import { newDateWithoutTime } from "../../utils/Helper";
import ServiceCard from "../../components/ServiceCard";
import { useTranslation } from "react-i18next";

const UpcomingServices: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [selectedDate, setSelectedDate] = useState(newDateWithoutTime());
  const [serviceList, setServiceList] = useState<IServiceInterface[]>([]);
  const [showLoader, setShowLoader] = useState(false);

  useEffect(() => {
    fetchServices();
  }, [selectedDate]);

  /**
   * @method to fetch services
   */
  const fetchServices = async () => {
    setShowLoader(true);
    const response = await getBoatServicesByUserId(authData._id, {
      date: selectedDate,
    });
    if (response?.data?.data) {
      setServiceList(response?.data?.data);
    }
    setShowLoader(false);
  };

  /**
   * @method to show date
   * @returns
   */
  const showDate = () => {
    let string = selectedDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
    return string;
  };

  return (
    <>
      <Header title={"Upcoming Services"} />
      <IonContent fullscreen>
        <div className="upcomingservices-page-inner">
          {/* services-filter start */}
          <div className="services-filter">
            <div className="filter-body">
              <div className="upcoming-calendar">
                <ThemeCalendar
                  value={selectedDate}
                  onChange={(e: any) => setSelectedDate(new Date(e))}
                />
              </div>
            </div>
            <div className="filter-bottom">
              <div className="main-container">
                <IonGrid className="p-0">
                  <IonRow className="align-items-center">
                    <IonCol size="6">
                      <div className="heading">
                        <h4>{translation("upcoming_services")}</h4>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>
          </div>
          {/* services-filter end */}

          {/* Upcoming Services start */}
          <div className="upcoming-services">
            <div className="main-container">
              <div className="heading">
                <h4>
                  <span> {showDate()}</span>
                </h4>
              </div>
              <div className="upcoming-services-inner">
                {/* card start */}
                {showLoader ? (
                  <IonSpinner />
                ) : serviceList.length > 0 ? (
                  serviceList.map((service, index) => (
                    <ServiceCard serviceData={service} key={index} />
                  ))
                ) : (
                  <p>{translation("no_services_found")}</p>
                )}
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}
        </div>
        {/* fab */}
        <IonFab slot="fixed" horizontal="end" vertical="bottom">
          <IonFabButton
            className="theme-fab-btn primary-btn"
            onClick={() => history.push("/new-services")}
          >
            <IonIcon icon={addOutline} />
          </IonFabButton>
        </IonFab>
      </IonContent>
    </>
  );
};

export default UpcomingServices;
