import {
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonRow,
  IonSkeletonText,
  IonThumbnail,
} from "@ionic/react";
import { useLocation } from "react-router";
import React, { useEffect, useState } from "react";

import { mailOutline } from "ionicons/icons";
import "./Services.scss";

import { getServiceProviderById } from "../../redux/action-creators/businessDirectory";
import Header from "../../components/header/Header";
import { useTranslation } from "react-i18next";

const ServiceProvider: React.FC = () => {
  const { t: translation } = useTranslation();
  const [loadingService, setLoadingService] = useState(false);
  const [serviceProvider, setserviceProvider] = useState({
    _id: "",
    business_name: "",
    owner_name: "",
    services: "",
    business_days: [],
    business_hours: { start_time: "", end_time: "" },
    contact_number: "",
    email: "",
    location: {
      address_line1: "",
      city: "",
      country: "",
      state: "",
      address_line2: " ",
      zip: " ",
    },
    photos: [],
  });
  const location = useLocation();
  const service_id = location.pathname.includes("/service-provider")
    ? location.pathname.split("/")?.[2]
    : "";

  useEffect(() => {
    fetchServiceProvider(service_id);
  }, []);

  /**
   * @method to fetch provider of service
   * @param service_id
   */
  const fetchServiceProvider = async (service_id: string) => {
    setLoadingService(true);
    const response = await getServiceProviderById(service_id);
    setserviceProvider(response?.data?.data ? response?.data?.data : []);
    setLoadingService(false);
  };

  const address =
    serviceProvider?.location.address_line1 +
    " " +
    serviceProvider?.location?.address_line2 +
    " " +
    serviceProvider?.location?.city +
    " " +
    " " +
    serviceProvider?.location?.state +
    " " +
    serviceProvider?.location?.zip;

  const addresses = address.split(" ").filter((item) => item !== "undefined");
  const final_address = addresses.join(" ");

  return (
    <>
      <Header title={serviceProvider.business_name} />
      <IonContent fullscreen>
        <div className="services-page service-provider-page">
          <div className="main-container">
            {/* provider-info start */}

            <div className="provider-info">
              <div className="heading">
                <h2>{serviceProvider.owner_name}</h2>
              </div>
              <div className="ion-padding custom-skeleton">
                {loadingService ? (
                  <>
                    <IonSkeletonText animated style={{ width: "60%" }} />
                    <IonSkeletonText animated />
                    <IonSkeletonText animated style={{ width: "88%" }} />
                    <IonSkeletonText animated style={{ width: "70%" }} />
                    <IonSkeletonText animated style={{ width: "60%" }} />
                  </>
                ) : (
                  <div className="info-list">
                    <ul>
                      <li>
                        <IonIcon icon={mailOutline} />
                        {serviceProvider.email}
                      </li>
                      <li>
                        <IonIcon icon={mailOutline} />
                        {serviceProvider.contact_number}
                      </li>
                      <li>
                        <IonIcon icon={mailOutline} />
                        {serviceProvider.business_name}
                      </li>
                      <li>
                        <IonIcon icon={mailOutline} />
                        {serviceProvider?.business_hours?.start_time
                          ? serviceProvider?.business_hours?.start_time
                          : ""}
                        -
                        {serviceProvider?.business_hours?.end_time
                          ? serviceProvider?.business_hours?.end_time
                          : ""}
                      </li>
                      <li>
                        <IonIcon icon={mailOutline} />
                        MON - FRI
                      </li>
                      <li>
                        <IonIcon icon={mailOutline} />

                        {final_address}
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
            {/* provider-service start */}
            {loadingService ? (
              <>
                {" "}
                <IonSkeletonText animated style={{ width: "60%" }} />
                <IonSkeletonText animated />
                <IonSkeletonText animated style={{ width: "88%" }} />
                <IonSkeletonText animated style={{ width: "70%" }} />
                <IonSkeletonText animated style={{ width: "60%" }} />
              </>
            ) : (
              <div className="provider-service">
                <div className="common-heading">
                  <div className="heading">
                    <h2>{translation("services")}</h2>
                  </div>
                </div>
                <div className="service-list">
                  <div
                    dangerouslySetInnerHTML={{
                      __html: serviceProvider.services
                        ? serviceProvider.services
                        : "No Services Found",
                    }}
                  ></div>
                </div>
              </div>
            )}

            {/* provider-photos start */}
            {loadingService ? (
              <>
                {" "}
                <IonThumbnail slot="start">
                  <IonSkeletonText animated />
                </IonThumbnail>
              </>
            ) : (
              <div className="provider-photos">
                <div className="common-heading">
                  <div className="heading">
                    <h2>{translation("photos")}</h2>
                  </div>
                </div>
                <div className="">
                  <IonGrid className="p-0">
                    <IonRow>
                      {serviceProvider.photos.map(
                        (img: string, index: number) => {
                          return (
                            <IonCol size="4">
                              <div className="gallery-card">
                                <IonImg src={img} />
                              </div>
                            </IonCol>
                          );
                        }
                      )}
                    </IonRow>
                  </IonGrid>
                </div>
              </div>
            )}
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ServiceProvider;
