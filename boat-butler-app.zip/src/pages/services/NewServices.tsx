import {
  CheckboxChangeEventDetail,
  IonButton,
  IonCheckbox,
  IonContent,
  IonIcon,
  IonInput,
  IonLabel,
  IonSelect,
  IonSelectOption,
  useIonToast,
} from "@ionic/react";
import { useHistory, useLocation } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";

import { addCircleOutline } from "ionicons/icons";
import "./Services.scss";

import { getBoatListAction } from "../../redux/action-creators/boat";
import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { createBoatService } from "../../redux/action-creators/boatServices";
import { BoatDb } from "../../interfaceModules/IBoatInterface";
import { useTranslation } from "react-i18next";

interface IServiceItem {
  name: string;
  checked: boolean;
}
const NewServices: React.FC = () => {
  const { t: translation } = useTranslation();
  const location = useLocation();
  const history = useHistory();
  const boatId =
    location.pathname?.split("/")?.length === 3
      ? location.pathname?.split("/")[2]
      : undefined;
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  const [boatList, setBoatList] = useState<BoatDb[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [serviceItems, setServiceItems] = useState<IServiceItem[]>([
    { name: "Oil Change", checked: false },
    { name: "Battery", checked: false },
    { name: "Spark Plug", checked: false },
    { name: "Breather hose & Fuel Line", checked: false },
    { name: "Lubrication", checked: false },
    { name: "Anodes and Bonding wires", checked: false },
  ]);
  const [selectedBoat, setSelectedBoat] = useState<BoatDb>({
    user_id: "",
    title: "",
    date_of_bought: new Date(),
    seller_phone: "",
    registration_id: "",
    vin: "",
    make: "",
    model: "",
    year_of_hull: 0,
    engine: {},
    other_equipments: [],
    photos: [],
  });
  const [addNew, setAddNew] = useState(false);
  const [newItem, setNewItem] = useState("");
  const [present, dismiss] = useIonToast();

  useEffect(() => {
    fetchBoatList();
  }, []);

  /**
   * @method to fetch list of Boat
   */
  const fetchBoatList = async () => {
    const res = await getBoatListAction(authData._id);
    setBoatList(res?.data?.data ? res?.data?.data : []);
    res?.data?.data.forEach((data: BoatDb) => {
      if (data._id === boatId) {
        setSelectedBoat(data);
      }
    });
  };

  /**
   * @method to handle change in checklist
   * @param e
   * @param name
   */
  const handleChangeCheckList = (
    e: CustomEvent<CheckboxChangeEventDetail>,
    name: string
  ) => {
    e.preventDefault();
    const { value, checked } = e.detail;
    let itemsListTemp = [...serviceItems];
    itemsListTemp.forEach((item) => {
      if (item.name === value) {
        item.checked = checked;
      }
    });
    setServiceItems(itemsListTemp);
  };

  /**
   * @method to create boat services when clicked on Submit
   * @returns
   */
  const handleSubmit = async () => {
    const selectedItems = serviceItems
      .filter((item) => item.checked)
      .map((item) => item.name);
    if (selectedItems.length === 0) {
      present("Please select some items!", 2000);
      return null;
    }
    const response = await createBoatService({
      user_id: authData._id,
      serviceDate: selectedDate,
      selectedBoat,
      items: selectedItems,
    });
    if (response?.data?.success) {
      await present(response.data.message, 2000);
      history.goBack();
    }
  };

  /**
   * @method to add new item when click on add item
   * @returns
   */
  const addNewItemClick = () => {
    if (newItem.length === 0) {
      setAddNew(false);
      return null;
    }
    setServiceItems((prevState) => [
      ...prevState,
      { name: newItem, checked: true },
    ]);
    setNewItem("");
    setAddNew(false);
  };

  return (
    <>
      <Header title={"New Service"} />
      <IonContent fullscreen>
        <div className="upcomingservices-page-inner">
          {/* services-filter start */}
          <div className="services-filter mb-30">
            <div className="filter-body">
              <div className="upcoming-calendar">
                <ThemeCalendar
                  value={selectedDate}
                  onChange={(e: any) => setSelectedDate(e)}
                  minDate={new Date()}
                />
              </div>
            </div>
          </div>
          {/* services-filter end */}

          <div className="new-services-form">
            <div className="main-container">
              <div className="form-group input-label">
                <IonLabel>{translation("select_boat")}</IonLabel>
                <IonSelect
                  className="form-control"
                  interface="popover"
                  placeholder="— Select —"
                  value={JSON.stringify(selectedBoat)}
                  onIonChange={(e) =>
                    setSelectedBoat(JSON.parse(e.detail.value))
                  }
                >
                  {boatList?.map((boat: BoatDb, index: number) => {
                    return (
                      <IonSelectOption key={index} value={JSON.stringify(boat)}>
                        {boat.title}
                      </IonSelectOption>
                    );
                  })}
                </IonSelect>
              </div>

              <div className="form-group">
                {serviceItems.map(
                  (item: { name: string; checked: boolean }, index: number) => (
                    <div className="checkbox-item" key={index}>
                      <IonCheckbox
                        slot="end"
                        checked={item.checked}
                        value={item.name}
                        onIonChange={(e) => handleChangeCheckList(e, item.name)}
                      />
                      <IonLabel>{item.name}</IonLabel>
                    </div>
                  )
                )}

                <div className="">
                  {addNew ? (
                    <div>
                      <div className="form-group">
                        <IonInput
                          className="form-control"
                          value={newItem}
                          onIonChange={(e) =>
                            setNewItem(e?.detail?.value as string)
                          }
                        />
                      </div>

                      <IonButton
                        onClick={addNewItemClick}
                        className="theme-button primary-btn"
                        expand="block"
                      >
                        {translation("save_items")}
                      </IonButton>
                    </div>
                  ) : (
                    <a
                      className="link-icon-btn primary-btn"
                      onClick={() => setAddNew(true)}
                    >
                      <IonIcon icon={addCircleOutline} />
                      {translation("add_new")}
                    </a>
                  )}
                </div>
              </div>

              <div>
                <IonButton
                  expand="block"
                  className="theme-button primary-btn"
                  onClick={handleSubmit}
                >
                  {translation("save")}
                </IonButton>
              </div>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default NewServices;
