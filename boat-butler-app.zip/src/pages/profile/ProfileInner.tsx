import {
  IonButton,
  IonContent,
  IonIcon,
  IonModal,
  useIonToast,
} from "@ionic/react";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { RootStateOrAny, useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { useTranslation } from "react-i18next";

import { chevronForwardOutline } from "ionicons/icons";
import "./Profile.scss";

import Header from "../../components/header/Header";
import { deleteUserAction, LogoutAction } from "../../redux/action-creators";

const ProfileInner: React.FC = () => {
  const dispatch = useDispatch();
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const { t: translation } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [present, dismiss] = useIonToast();

  /**
   * @method to delete user Id
   * @param user_id
   */
  const deleteUser = async (user_id: string) => {
    setShowModal(false);
    const response = await deleteUserAction(user_id);
    if (response?.data?.success) {
      present(response?.data?.message, 2000);
      await dispatch(LogoutAction(authData._id));
      history.push("/");
    } else {
      present(response?.data?.message, 2000);
    }
  };

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="profile-page">
          <div className="main-container">
            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/profile" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p>{authData.email && authData ? authData.email : ""}</p>
                    </div>

                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>

            {/* reminder-card */}
            <div className="reminder-card">
              <div className="action-item-list">
                <Link to="/change-password" className="action-link">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p> {translation("change_password")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </Link>
              </div>
            </div>

            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/pricing" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p> {translation("personal")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>

            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/page/privacy-policy" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p> {translation("legal_privacy")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p> {translation("notification_setting")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p>{translation("send_feedback")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <Link to="/help-and-support" className="action-link">
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p>{translation("help_faq")}</p>
                    </div>
                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
            {/* reminder-card */}
            <div className="reminder-card">
              <Link
                to="/profile-inner"
                className="action-link"
                onClick={() => setShowModal(true)}
              >
                <div className="action-item-list">
                  {/* item */}
                  <div className="action-item">
                    <div className="name">
                      <p>{translation("delete_account")}</p>
                    </div>

                    <div className="action-input">
                      {translation("edit")}
                      <IonIcon icon={chevronForwardOutline} />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
            {/* Theme modal */}
            <IonModal
              className="theme-modal delete-account-modal"
              isOpen={showModal}
              breakpoints={[0.1, 0.5, 1]}
              initialBreakpoint={0.9}
            >
              <div className="modal-inner">
                <div className="modal-header text-center">
                  <div className="modal-heading">
                    <h3>
                      {translation(
                        "are_you_sure_you_want_to_delete_your_account"
                      )}
                    </h3>
                  </div>
                </div>
                <div className="modal-body">
                  <div className="d-flex justify-content-center">
                    <IonButton
                      onClick={() => deleteUser(authData._id)}
                      className="theme-button primary-btn"
                    >
                      {translation("yes")}
                    </IonButton>
                    <IonButton
                      onClick={() => setShowModal(false)}
                      className="theme-button primary-outline-btn"
                    >
                      {translation("no")}
                    </IonButton>
                  </div>
                </div>
              </div>
            </IonModal>
            <div className="app-version">
              <h4>{translation("app_version")}</h4>
              <span>{translation("6.0.5")}</span>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ProfileInner;
