import { useForm, Controller } from "react-hook-form";
import { RootStateOrAny, useSelector, useDispatch } from "react-redux";
import { yupResolver } from "@hookform/resolvers/yup";
import React, { useState, useEffect, useMemo } from "react";
import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  SelectChangeEventDetail,
  useIonToast,
} from "@ionic/react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

import "./Profile.scss";
import statesData from "../../utils/states.json";

import { IProfileState } from "../../interfaceModules/IUserInterface";
import { ProfileAction, getUserAction } from "../../redux/action-creators";
import { profileValidationSchema } from "../../utils/validationschema";
import { Gender_List } from "../../utils/constants";
import { getPicture } from "../../utils/Helper";
import { ActionType } from "../../redux/action-types/index";
import { ICitiesInterface } from "../../interfaceModules/IProfileInterface";

const Profile: React.FC = () => {
  const { t: translation } = useTranslation();
  const dispatch = useDispatch();
  const [present, dismiss] = useIonToast();
  const [showloader, setshowLoader] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [cities, setCities] = useState(authData.city ? [authData.city] : []);
  const [oldImage, setOldImage] = useState(authData.image);
  let userId: number = Number(localStorage.getItem("userId"));
  const [userImage, setUserImage] = React.useState({
    dataUrl: authData.image,
    format: "",
  });

  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<IProfileState>({
    mode: "onChange",
    resolver: yupResolver(profileValidationSchema()),
    defaultValues: useMemo(() => {
      return authData;
    }, [authData]),
  });

  useEffect(() => {
    reset(authData);
    setUserImage({
      dataUrl: authData.image,
      format: "",
    });
  }, [authData]);

  useEffect(() => {
    let cities = statesData.filter(
      (item: ICitiesInterface) => item.state === authData.state
    );
    cities = Array.from(
      new Set(cities.map((item: ICitiesInterface) => item.city))
    ) as [];
    cities.sort();
    setCities(cities);
    fetchUserData();
  }, []);

  /**
   * @method to fetch data of User
   */
  const fetchUserData = async () => {
    const res = await getUserAction(authData._id);
    if (res?.data?.data) {
      localStorage.setItem("userData", JSON.stringify(res?.data?.data));
      dispatch({
        type: ActionType.LOGIN,
        payload: res?.data?.data,
      });
    }
  };
  let states = Array.from(
    new Set(statesData.map((item: ICitiesInterface) => item.state))
  ).sort();

  /**
   * @method to handle change in state
   * @param e
   */
  const handleStateChange = (e: CustomEvent<SelectChangeEventDetail>) => {
    let target = e.target as HTMLSelectElement;
    let cities = statesData.filter(
      (item: ICitiesInterface) => item.state === target.value
    );
    cities = Array.from(
      new Set(cities.map((item: ICitiesInterface) => item.city))
    ) as [];
    cities.sort();
    setCities(cities);
  };

  /**
   * @method to update profile when clicked on Submit
   * @param data
   */
  const onSubmit = async (data: IProfileState) => {
    setshowLoader(true);
    setButtonDisable(true);
    data.id = userId;
    data.oldImage = oldImage;
    await ProfileAction({ ...data, image: userImage }).then((res) => {
      if (res) {
        present(translation("profile_updated_successfully"), 3000);
      } else {
        present(translation("profile_updation_failed"), 3000);
      }
    });
    setshowLoader(false);
    setButtonDisable(false);
  };

  /**
   * @method to handle Images
   * @param number
   * @param type
   * @param name
   * @returns
   */
  const handleImages = async (number: string, type: string, name: string) => {
    const image: any = await getPicture(number, type);

    if (!image) {
      return null;
    }
    setUserImage({ dataUrl: image?.data, format: image?.format });
  };

  return (
    <>
      <IonHeader className="common-header">
        <div className="main-container">
          <IonGrid className="p-0">
            <IonRow>
              <IonCol size="3"></IonCol>
              <IonCol size="6">
                <div className="heading text-center">
                  <h3>{translation("profile")}</h3>
                </div>
              </IonCol>
              <IonCol size="3">
                <div className="text-right">
                  <Link className="link-btn tertiary-link-btn" to="/home">
                    {translation("skip")}
                  </Link>
                </div>
              </IonCol>
            </IonRow>
          </IonGrid>
        </div>
      </IonHeader>
      <IonContent fullscreen>
        <div className="profile-page-inner">
          <div className="main-container">
            <form onSubmit={handleSubmit(onSubmit)}>
              {/* profile-img */}
              <div className="profile-img">
                <div className="circle-img">
                  <IonImg
                    src={userImage.dataUrl ? userImage.dataUrl : authData.image}
                    alt="imageuploadicon"
                  />
                </div>

                <div className="file-input-link">
                  {/* <span>
                    Edit
                    <input
                      type="file"
                      onClick={handleImportImage}
                    />
                  </span> */}
                  <span>
                    <IonButton
                      expand="block"
                      className="icon-btn dark-icon-btn"
                      onClick={() =>
                        handleImages("single", "base64", "ProfileImg")
                      }
                    >
                      {translation("edit")}
                    </IonButton>
                  </span>
                </div>
              </div>

              <div className="form-inner">
                <div className="form-group input-label">
                  <IonLabel> {translation("full_name")}</IonLabel>
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        type="text"
                        className="form-control"
                        placeholder={translation("your_name")}
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="name"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.name && <p>{errors?.name?.message}</p>}
                  </div>
                </div>

                <div className="form-group input-label">
                  <IonLabel> {translation("phone_number")}</IonLabel>
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        type="number"
                        className="form-control"
                        placeholder={translation("phone")}
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="phone"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.phone && <p>{errors?.phone?.message}</p>}
                  </div>
                </div>

                <div className="form-group input-label">
                  <IonLabel> {translation("your_email_id")}</IonLabel>
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        type="text"
                        className="form-control"
                        placeholder={translation("email_id")}
                        disabled={true}
                      ></IonInput>
                    )}
                    name="email"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.email && <p>{errors?.email?.message}</p>}
                  </div>
                </div>

                <div className="form-group input-label">
                  <IonLabel> {translation("gender")}</IonLabel>
                  <Controller
                    render={({ field }) => (
                      <IonSelect
                        {...field}
                        className="form-control"
                        value={field.value}
                        interface="popover"
                        onIonChange={(e) => {
                          field.onChange(e);
                        }}
                        placeholder={translation("select_gender")}
                      >
                        {Gender_List.length > 0 &&
                          Gender_List?.map((Gender_List, index) => {
                            return (
                              <IonSelectOption key={index} value={Gender_List}>
                                {Gender_List}
                              </IonSelectOption>
                            );
                          })}
                      </IonSelect>
                    )}
                    name={"gender"}
                    control={control}
                  />

                  <div className="message error">
                    {errors && errors?.gender && (
                      <p>{errors?.gender?.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <div className="inner-heading">
                    <h3> {translation("address")}</h3>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel> {translation("address_line_1")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder={translation("address_line_1")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="address_line_1"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.address_line_1 && (
                        <p>{errors?.address_line_1?.message}</p>
                      )}
                    </div>
                  </div>

                  <div className="form-group input-label">
                    <IonLabel>{translation("address_line_2")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="text"
                          className="form-control"
                          placeholder={translation("address_line_2")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="address_line_2"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.address_line_2 && (
                        <p>{errors?.address_line_2?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>{translation("state")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonSelect
                          {...field}
                          className="form-control"
                          interface="popover"
                          placeholder={translation("state")}
                          value={field.value}
                          onIonChange={(e) => {
                            field.onChange(e);
                            handleStateChange(e);
                          }}
                        >
                          {states.length > 0 &&
                            states?.map((item, index) => {
                              return (
                                <IonSelectOption key={index} value={item}>
                                  {item}
                                </IonSelectOption>
                              );
                            })}
                        </IonSelect>
                      )}
                      name={"state"}
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.state && (
                        <p>{errors?.state?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>{translation("city")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonSelect
                          {...field}
                          className="form-control"
                          interface="popover"
                          value={field.value}
                          onIonChange={field.onChange}
                          placeholder={translation("city")}
                        >
                          {cities.length > 0 &&
                            cities?.map((item, index) => {
                              return (
                                <IonSelectOption key={index} value={item}>
                                  {item}
                                </IonSelectOption>
                              );
                            })}
                        </IonSelect>
                      )}
                      name={"city"}
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.city && <p>{errors?.city?.message}</p>}
                    </div>
                  </div>
                  <div className="form-group input-label">
                    <IonLabel>{translation("zip_code")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type="number"
                          className="form-control"
                          // interface='popover'
                          placeholder={translation("zip_code")}
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name="zipcode"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.zipcode && (
                        <p>{errors?.zipcode?.message}</p>
                      )}
                    </div>
                  </div>
                </div>

                <div className="profile-btn">
                  <IonButton
                    expand="block"
                    className="theme-button primary-btn"
                    onClick={handleSubmit(onSubmit)}
                    disabled={buttonDisable}
                    type="submit"
                  >
                    {translation("save")}
                    {showloader ? <IonSpinner /> : null}
                  </IonButton>
                </div>
              </div>
            </form>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Profile;
