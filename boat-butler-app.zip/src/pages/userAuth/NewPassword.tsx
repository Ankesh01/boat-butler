import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import React, { useState } from "react";
import { keyOutline } from "ionicons/icons";
import { useHistory } from "react-router-dom";
import "./UserAuth.scss";
import authbg from "../../images/user-auth-bg.png";
import logo from "../../images/logo.png";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, useForm } from "react-hook-form";
import { INewPassword } from "../../interfaceModules/IUserInterface";
import { NewPasswordSchema } from "../../utils/validationschema";
import { ChangePasswordAction } from "../../redux/action-creators";
import * as toast from "../../utils/toastsMessage";

const NewPassword: React.FC = (props: any) => {
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<INewPassword>({
    resolver: yupResolver(NewPasswordSchema()),
  });
  const [showpass, setshowpass] = useState(false);
  const [disableBtn, setDisableBtn] = useState(false);
  const [confirmPass, setConfirmPass] = useState(false);
  const history = useHistory();
  const [present, dismiss] = useIonToast();
  const email = props.location?.state?.email;

  const onSubmit = async (data: INewPassword) => {
    setDisableBtn(true);
    const password = data.password;
    const newpassword = data.confirm_password;

    ChangePasswordAction({ password, newpassword, email }).then((res) => {
      if (res?.data?.data?.success) {
        present("Password updated Successfully", 2000);
        history.push({ pathname: "/login" });
      } else {
        present("Password Incorrect", 2000);
      }
    });
    setDisableBtn(false);
  };
  return (
    <IonContent fullscreen>
      <div className="auth-page" style={{ backgroundImage: `url(${authbg})` }}>
        <div className="main-container">
          <div className="auth-logo">
            <IonImg src={logo} />
          </div>

          <div className="auth-card">
            <div className="card-top">
              <h2>New Password</h2>
              <p>
                Lorem Ipsum has been the industry’s standard dummy text ever
                since the 1500s.
              </p>
            </div>
            <div className="card-mid">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="form-group">
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className="form-control"
                        type={showpass ? "text" : "password"}
                        placeholder="New Password"
                        onIonChange={field.onChange}
                      >
                        <IonIcon
                          icon={keyOutline}
                          onClick={() => {
                            setshowpass(!showpass);
                          }}
                        />
                      </IonInput>
                    )}
                    name="password"
                    control={control}
                  />

                  <div className="message error">
                    {errors && errors?.password && (
                      <p>{errors?.password?.message}</p>
                    )}
                  </div>
                  {/* <IonInput
                    className="form-control"
                    type="password"
                    placeholder="Password"
                  ></IonInput> */}
                </div>
                <div className="form-group">
                  <div className="right-icon-input">
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className="form-control"
                          type={confirmPass ? "text" : "password"}
                          placeholder="Confirm Password "
                          onIonChange={field.onChange}
                        >
                          <IonIcon
                            icon={keyOutline}
                            onClick={() => {
                              setConfirmPass(!confirmPass);
                            }}
                          />
                        </IonInput>
                      )}
                      name="confirm_password"
                      control={control}
                    />
                    <div className="message error">
                      {errors && errors?.confirm_password && (
                        <p>{errors?.confirm_password?.message}</p>
                      )}
                    </div>
                    {/* <IonInput
                      className="form-control"
                      type="password"
                      placeholder="Confirm Password"
                    ></IonInput> */}
                    {/* <Link to="/"> */}

                    {/* </Link> */}
                  </div>
                </div>
              </form>
            </div>
            <div className="auth-btn">
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit(onSubmit)}
                disabled={disableBtn}
              >
                Update
              </IonButton>
            </div>
            <div className="have-account">
              <p>Already have an account?</p>
              <Link to="/">Login</Link>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default NewPassword;
