import React, { useState } from "react";
import {
  IonButton,
  IonContent,
  IonImg,
  IonInput,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { RootStateOrAny, useSelector } from "react-redux";
import "./UserAuth.scss";
import authbg from "../../images/user-auth-bg.png";
import logo from "../../images/logo.png";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { verificationSchema } from "../../utils/validationschema";
import { IVerification } from "../../interfaceModules/IUserInterface";
import { VerificationAction } from "../../redux/action-creators";
import { useHistory } from "react-router-dom";
import * as toast from "../../utils/toastsMessage";

const Verification: React.FC = (props: any) => {
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<IVerification>({
    resolver: yupResolver(verificationSchema()),
  });
  const [present, dismiss] = useIonToast();
  const [disableBtn, setDisableBtn] = useState(false);
  const history = useHistory();
  const email = props.location?.state?.email;

  const onSubmit = async (data: IVerification) => {
    setDisableBtn(true);
    const otp = data.otp;
    VerificationAction({ otp, email }).then((res) => {
      if (res?.data?.success) {
        present("User Verified Successfully", 2000);
        setTimeout(
          () =>
            history.push({
              pathname: "/new-password",
              state: { email: email },
            }),
          2000
        );
      } else if (res?.data?.success === false) {
        present("Incorrect Otp", 3000);
      }
    });
    setDisableBtn(false);
  };

  return (
    <IonContent fullscreen>
      <div className="auth-page" style={{ backgroundImage: `url(${authbg})` }}>
        <div className="main-container">
          <div className="auth-logo">
            <IonImg src={logo} />
          </div>
          <div className="auth-card">
            <div className="card-top">
              <h2>Verification</h2>
              <p>Lorem Ipsum has been the industry’s KurrozhDemma@yta.com</p>
            </div>
            <div className="card-mid">
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="form-group verification-inputs">
                  {/* <IonInput
                  className="form-control"
                  type="number"
                  placeholder="• • • •"
                  max={4}
                ></IonInput> */}
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className="form-control"
                        type="number"
                        placeholder="• • • •"
                        max={4}
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="otp"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.otp && <p>{errors?.otp?.message}</p>}
                  </div>
                  {/* <IonInput
                  className="form-control"
                  type="email"
                  placeholder="•"
                ></IonInput>
                <IonInput
                  className="form-control"
                  type="email"
                  placeholder="•"
                ></IonInput>
                <IonInput
                  className="form-control"
                  type="email"
                  placeholder="•"
                ></IonInput> */}
                </div>
              </form>
            </div>
            <div className="auth-btn">
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit(onSubmit)}
                disabled={disableBtn}
              >
                Verify
              </IonButton>
            </div>
            <div className="have-account">
              <p>Already have an account?</p>
              <Link to="/">Login</Link>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default Verification;
