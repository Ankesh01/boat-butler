import React, { useEffect, useState } from "react";
import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  useIonToast,
  IonInput,
  isPlatform,
  IonSpinner,
} from "@ionic/react";

import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch, useSelector } from "react-redux";
import { ActionType } from "../../redux/action-types/index";
import {
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";
import "./UserAuth.scss";
import authbg from "../../images/user-auth-bg.png";
import logo from "../../images/logo.png";
import { ILoginState } from "../../interfaceModules/IUserInterface";
import { loginValidationSchema } from "../../utils/validationschema";
import { LoginAction, socialLogin } from "../../redux/action-creators";
import { RoutingLinks } from "../../utils/constants";
import {
  FacebookLogin,
  FacebookLoginResponse,
} from "@capacitor-community/facebook-login";
import axios from "axios";
import { GoogleAuth } from "@codetrix-studio/capacitor-google-auth";

import "./UserAuth.scss";
import {
  ActionPerformed,
  PushNotifications,
  PushNotificationSchema,
  Token,
} from "@capacitor/push-notifications";
import { setAccessToken } from "../../utils/storage";
// import {
//   SignInWithApple,
//   ASAuthorizationAppleIDRequest,
// } from "@ionic-native/sign-in-with-apple";

const Login: React.FC = (props: any) => {
  let token: any;
  const authData = useSelector((state: any) => state.authReducer.user);
  const dispatch = useDispatch();
  const [disable, setDisable] = useState(false);
  const [spin, setSpin] = useState(false);
  const [userInfo, setUserInfo] = useState({});
  const [idToken, setIdToken] = useState("");
  const [showpass, setshowpass] = useState(false);
  const [present, dismiss] = useIonToast();
  // const navigate = useNavigation();
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<ILoginState>({
    resolver: yupResolver(loginValidationSchema()),
  });

  useEffect(() => {
    const token = localStorage.getItem("fcm_token");
    if (!token || token.length === 0) {
      registerPushNotification();
    }
  }, []);

  const registerPushNotification = () => {
    // Request permission to use push notifications
    // iOS will prompt user and return if they granted permission or not
    // Android will just grant without prompting
    PushNotifications.requestPermissions().then((result) => {
      if (result.receive === "granted") {
        // Register with Apple / Google to receive push via APNS/FCM
        PushNotifications.register();
      } else {
        // Show some error
      }
    });

    // On success, we should be able to receive notifications
    PushNotifications.addListener("registration", (token: Token) => {
      console.log("Push registration success, token: " + token.value);
      localStorage.setItem("fcm_token", token.value);
    });

    // Some issue with our setup and push will not work
    PushNotifications.addListener("registrationError", (error: any) => {
      console.log("Error on registration: " + JSON.stringify(error));
    });

    // Show us the notification payload if the app is open on our device
    PushNotifications.addListener(
      "pushNotificationReceived",
      (notification: PushNotificationSchema) => {
        console.log("Push received: " + JSON.stringify(notification));
      }
    );

    // Method called when tapping on a notification
    PushNotifications.addListener(
      "pushNotificationActionPerformed",
      (notification: ActionPerformed) => {
        console.log("Push action performed: " + JSON.stringify(notification));
      }
    );
  };
  let time = Intl.DateTimeFormat().resolvedOptions().timeZone;
  console.log("authdata-----", authData);

  const onSubmit = async (data: ILoginState) => {
    setDisable(true);
    setSpin(true);
    const fcmToken = localStorage.getItem("fcm_token");
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const res: any = await LoginAction({ ...data, fcmToken, timezone });

    if (res?.data?.success) {
      await setAccessToken(res?.data?.data?.token);
      localStorage.setItem("userId", res?.data?.data?._id);
      localStorage.setItem("userData", JSON.stringify(res?.data?.data));
      localStorage.setItem("token", res?.data?.data?.token);
      localStorage.setItem(
        "boatCount",
        res?.data?.data?.paymentInfo?.plan_info?.boat_count
      );
      dispatch({
        type: ActionType.LOGIN,
        payload: res?.data?.data,
      });

      present("login_successful", 2000);
      props.history.push(RoutingLinks.profile, {
        state: { id: res?.data?.data?.id },
      });
      // {
      //   res?.data?.data?.paymentInfo?.[0].length > 0
      //     ? props.history.push(RoutingLinks.profile, {
      //         state: { id: res?.data?.data?.id },
      //       })
      //     : props.history.push(RoutingLinks.pricing, {
      //         state: { id: res?.data?.data?.id },
      //       });
      // }
    } else if (!res.data.success) {
      present("credientials_not_match", 2000);
    }

    setDisable(false);
    setSpin(false);
  };
  /*const handleFcm = async (userId: number) => {
  let data = { userId, fcmToken: localStorage.getItem("fcmToken") };
  //await fcmToken(data);
};*/

  const handleFcm = async (userId: number) => {
    let data = { userId, fcmToken: localStorage.getItem("fcmToken") };
    //await fcmToken(data);
  };

  const signInGoogle = async () => {
    try {
      const result: any = await GoogleAuth.signIn();
      console.log("Google Result--", result);
      let users = {
        email: result?.email,
        name: result?.displayName,
        idToken: result?.authentication?.idToken,
        type: "google",
      };
      console.log("user Result--", users);
      if (users.idToken !== undefined) {
        setIdToken(result?.authentication?.idToken);
        await socialLogin(users);
      }
      // const loginData = await socialLogin(users);
      // console.log("loginData", loginData);
    } catch (error: any) {
      console.log("Erorr----------", error);
      // if (error ) {
      //  // alert("Opps Something went wrong");
      // }
    }
  };

  const loadUserData = async () => {
    const url = `https://graph.facebook.com/${token.userId}?fields=id,first_name,last_name,picture.width(720),birthday,email&access_token=${token.token}`;
    console.log("Inside url----------", url);
    const res: any = await axios.get(url);
    console.log("res after axios----------", res);
    let user = {
      email: res?.data?.email,
      first_name: res?.data?.first_name,
      last_name: res?.data?.last_name,

      profile_image_path: res?.data?.picture?.data?.url || "",
      type: "facebook",
    };
    console.log("USer-------", user);

    setUserInfo(user);
    const loginData = await socialLogin(user);
    console.log("loginData--socialLogin-----", loginData);
    // const resData = loginData?.data;
    // if (resData?.matched) {
    //   await handleFcm(resData?.user?._id);
    //   props.history.push("/");
    // } else {
    //   present({
    //     message: resData?.message || "Something went wrong Facebook Login",
    //     duration: 5000,
    //     color: "danger",
    //   });
    // }
  };

  const signInFacebook = async () => {
    const FACEBOOK_PERMISSIONS = ["public_profile", "email"];
    console.log("SIgn FB-");
    const result = await FacebookLogin.login({
      permissions: FACEBOOK_PERMISSIONS,
    });
    console.log("SIgn FB-", result);

    if (result.accessToken && result.accessToken.userId) {
      token = result.accessToken;
      console.log("tokennnnnnnnn", token);
      loadUserData();
    } else if (result.accessToken && !result.accessToken.userId) {
      getCurrentToken();
    }
  };
  const getCurrentToken = async () => {
    const result = await FacebookLogin.getCurrentAccessToken();
    if (result.accessToken) {
      token = result.accessToken;
      loadUserData();
    }
  };

  // const AppleSignIn = () => {
  //   console.log("enter")
  //   SignInWithApple.signin({
  //     requestedScopes: [
  //       ASAuthorizationAppleIDRequest.ASAuthorizationScopeFullName,
  //       ASAuthorizationAppleIDRequest.ASAuthorizationScopeEmail,
  //     ],
  //   })
  //     .then(async (res) => {
  //       console.log("res",res)
  //       const loginData:any = await appleLogin(res);
  //       const resData = loginData?.data;
  //       if (resData?.success) {
  //         await handleFcm(resData?.user?._id);
  //       //  props.history.push("/");
  //       } else {
  //         present({
  //           message: resData?.message || "Something went wrong Apple Login",
  //           duration: 3000,
  //           color: "danger",
  //         });
  //       }
  //     })
  //     .catch((error: any) => {
  //       console.log("Error google", error, JSON.stringify(error));
  //       alert("Oops something went wrong");
  //     });
  // };

  return (
    <IonContent fullscreen>
      <div className='auth-page' style={{ backgroundImage: `url(${authbg})` }}>
        <div className='main-container'>
          <div className='auth-logo'>
            <IonImg src={logo} />
          </div>

          <div className='auth-card'>
            <div className='card-top'>
              <h2>Login</h2>
              <p>
                Lorem Ipsum has been the industry’s standard dummy text ever
                since the 1500s.
              </p>
            </div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className='card-mid'>
                <div className='form-group'>
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className='form-control'
                        type='text'
                        placeholder='Username/ Email'
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name='email'
                    control={control}
                  />
                  <div className='message error'>
                    {errors && errors?.email && <p>{errors?.email?.message}</p>}
                  </div>
                </div>
                <div className='form-group'>
                  <div className='right-icon-input'>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          className='form-control'
                          type={showpass ? "text" : "password"}
                          placeholder='password'
                          onIonChange={field.onChange}
                        ></IonInput>
                      )}
                      name='password'
                      control={control}
                    />
                    <div className='message error'>
                      {errors && errors?.password && (
                        <p>{errors?.password?.message}</p>
                      )}
                    </div>
                    {/* <IonInput
                      className="form-control"
                      type="password"
                      placeholder="Password"
                    ></IonInput> */}

                    <IonIcon
                      icon={keyOutline}
                      onClick={() => {
                        setshowpass(!showpass);
                      }}
                    />
                  </div>
                </div>
              </div>
            </form>
            <div className='auth-btn'>
              <IonButton
                expand='block'
                className='theme-button primary-btn'
                disabled={disable}
                onClick={handleSubmit(onSubmit)}
              >
                Login
                {spin && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
              </IonButton>
            </div>

            <div className='text-right forgot-link'>
              <Link to='/password-reset'>Forgot Password?</Link>
            </div>

            <div className='or-separator'>
              <span>or</span>
            </div>

            <div className='social-login'>
              <button
                className='social-btn google-btn'
                onClick={() => signInGoogle()}
              >
                <IonIcon icon={logoGoogle} />
              </button>
              <button
                className='social-btn facebook-btn'
                onClick={() => signInFacebook()}
              >
                <IonIcon icon={logoFacebook} />
              </button>
              {isPlatform("ios") ? (
                <button className='social-btn apple-btn'>
                  <IonIcon icon={logoApple} />
                </button>
              ) : null}
            </div>
            <div className='have-account'>
              <p>Don’t have an account?</p>
              <Link to={RoutingLinks.signup}>Sign Up</Link>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default Login;
