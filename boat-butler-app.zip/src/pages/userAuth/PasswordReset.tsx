import React, { useState } from "react";
import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonToast,
  IonInput,
  isPlatform,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

import {
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";

import "./UserAuth.scss";
import authbg from "../../images/user-auth-bg.png";
import logo from "../../images/logo.png";
import { IResetPassState } from "../../interfaceModules/IUserInterface";
import { ResetpasswordSchema } from "../../utils/validationschema";
import { ResetPasswordAction } from "../../redux/action-creators";
import { RoutingLinks } from "../../utils/constants";
import { useHistory } from "react-router-dom";

const PasswordReset: React.FC = () => {
  const {
    control,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<IResetPassState>({
    resolver: yupResolver(ResetpasswordSchema()),
  });
  const history = useHistory();
  const [disableBtn, setDisableBtn] = useState(false);
  const [toastIsShown, setToastIsShown] = useState(false);
  const showToast = () => {
    setToastIsShown(true);
  };

  const onSubmit = async (data: IResetPassState) => {
    setDisableBtn(true);
    ResetPasswordAction(data).then((res: any) => {
      if (res.data.success) {
        history.push({
          pathname: "/verification",
          state: { email: data.email },
        });
      }
    });
    setDisableBtn(false);
    // props.history.push(RoutingLinks.profile, {
    //   state: { id: res?.data?.data?.id },
    // });
  };

  return (
    <IonContent fullscreen>
      <div className="auth-page" style={{ backgroundImage: `url(${authbg})` }}>
        <div className="main-container">
          <div className="auth-logo">
            <IonImg src={logo} />
          </div>

          <div className="auth-card">
            <div className="card-top">
              <h2>Password Reset</h2>
              <p>
                Lorem Ipsum has been the industry’s standard dummy text ever
                since the 1500s.
              </p>
            </div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="card-mid">
                <div className="form-group">
                  <Controller
                    render={({ field }) => (
                      <IonInput
                        {...field}
                        className="form-control"
                        type="email"
                        placeholder="email"
                        onIonChange={field.onChange}
                      ></IonInput>
                    )}
                    name="email"
                    control={control}
                  />
                  <div className="message error">
                    {errors && errors?.email && <p>{errors?.email?.message}</p>}
                  </div>
                  {/* <IonInput
                    className="form-control"
                    type="email"
                    placeholder="Email ID"
                  ></IonInput> */}
                </div>
              </div>
            </form>
            <div className="auth-btn">
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                disabled={disableBtn}
                onClick={handleSubmit(onSubmit)}
              >
                Next
              </IonButton>
            </div>
            <div className="or-separator">
              <span>or</span>
            </div>
            <div className="social-login">
              <button className="social-btn google-btn">
                <IonIcon icon={logoGoogle} />
              </button>
              <button className="social-btn facebook-btn">
                <IonIcon icon={logoFacebook} />
              </button>
              {isPlatform("ios") ? (
                <button className="social-btn apple-btn">
                  <IonIcon icon={logoApple} />
                </button>
              ) : null}
            </div>
            <div className="have-account">
              <p>Already have an account?</p>
              <Link to="/">Login</Link>
            </div>
          </div>
        </div>
      </div>
    </IonContent>
  );
};

export default PasswordReset;
