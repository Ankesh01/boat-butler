import {
  InputChangeEventDetail,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonRow,
  IonSpinner,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";
import moment from "moment";
import { useTranslation } from "react-i18next";

import { bookmark, searchOutline } from "ionicons/icons";
import "./Forum.scss";

import { getSavedPostListAction } from "../../redux/action-creators/postsAction";
import Header from "../../components/header/Header";
import { IPostInterface } from "../../interfaceModules/ICommunityInterface";
import { isImageFile } from "../../utils/Helper";

const SavedPost: React.FC = () => {
  const { t: translation } = useTranslation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [searchKeyword, setsearchKeyword] = useState("");
  const [postList, setPostList] = useState<IPostInterface[]>([]);
  const [spin, setSpin] = useState(false);

  useEffect(() => {
    if (searchKeyword?.length === 0) {
      setPostList([]);
    }
    fetchPostList(true, 0);
  }, [searchKeyword]);

  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });

  /**
   * @method to load more Data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchPostList(false, paginationState.offset);
      ev.target.complete();
    }, 500);
  };

  /**
   * @method to handle search
   * @param e
   */
  const handleSearch = (e: CustomEvent<InputChangeEventDetail>) => {
    e.preventDefault();
    let target = e.target as HTMLSelectElement;
    setTimeout(() => setsearchKeyword(target.value), 500);
  };

  /**
   * @method to fetch List of Post
   * @param firstLoad
   * @param offset
   */
  const fetchPostList = async (firstLoad: boolean, offset: number) => {
    setSpin(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      let result = await getSavedPostListAction(
        authData._id,
        offset,
        searchKeyword
      );
      if (result?.data?.success) {
        if (searchKeyword && searchKeyword !== "") {
          setPostList([...result?.data?.data]);
        } else {
          setPostList(
            firstLoad
              ? result?.data?.data
              : (prevState) => [...prevState, ...result?.data?.data]
          );
          setPaginationState((prevState) => ({
            ...prevState,
            prevOffset:
              result?.data?.data.length > 0 ? offset : offset ? offset - 5 : 0,
            offset:
              result?.data?.data.length > 0 ? prevState.offset + 5 : offset,
            hasMore: result?.data?.data.length > 0,
          }));
        }
      } else {
        // setPostList([...result?.data?.data]);
        setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
      }
    }
    setSpin(false);
  };

  return (
    <>
      <Header title={"Saved Posts"} />
      <IonContent fullscreen>
        <div className='forum-page'>
          <div className='main-container'>
            {/* post-card */}
            <div className='home-search'>
              <div className='form-group'>
                <div className='right-icon-input'>
                  <IonInput
                    className='form-control'
                    placeholder='Search Post'
                    onIonChange={(e) => handleSearch(e)}
                  />
                  <Link to='/'>
                    <IonIcon icon={searchOutline} />
                  </Link>
                </div>
              </div>
            </div>
            {spin && (
              <span>
                <IonSpinner />
              </span>
            )}
            {postList && postList.length > 0 ? (
              postList.map((post: IPostInterface, index: number) => {
                return (
                  <div className='post-card'>
                    <Link to={`/post-detail/${post?._id}`}>
                      <div className='card-inner'>
                        <IonGrid>
                          <IonRow>
                            <IonCol size='7'>
                              <div className='post-detail'>
                                <div className='time'>
                                  <span>
                                    <IonIcon icon={bookmark} />
                                    {/* Jan 29, 2021 */}
                                    {moment(post?.updated_ts).format(
                                      "MMM DD, YYYY"
                                    )}
                                  </span>
                                </div>
                                <div className='brif'>
                                  <h3>{post?.title}</h3>
                                  <p>{post?.description}</p>
                                </div>
                              </div>
                            </IonCol>
                            <IonCol size='5'>
                              {post?.media_file &&
                              post?.media_file.length > 0 ? (
                                <div className='post-img'>
                                  {isImageFile(
                                    post?.media_file.toLowerCase()
                                  ) ? (
                                    <IonImg src={post?.media_file} />
                                  ) : (
                                    <video width='100%' height='230' controls>
                                      <source src={post?.media_file}></source>
                                    </video>
                                  )}
                                </div>
                              ) : (
                                ""
                              )}
                            </IonCol>

                            <IonCol size='6'>
                              <div className='status-info'>
                                <p>
                                  {translation("comment")}{" "}
                                  <span>{post?.post_comments?.[0]?.total}</span>
                                </p>
                                <p>
                                  {translation("likes")}{" "}
                                  <span>{post?.total?.like?.length}</span>
                                </p>
                              </div>
                            </IonCol>
                            <IonCol size='6'>
                              <div className='post-time'>
                                <p>
                                  {translation("post")}{" "}
                                  {moment(post?.created_ts).format(
                                    "MMM DD, YYYY"
                                  )}{" "}
                                  {translation("at")}{" "}
                                  {moment(post?.created_ts).format("hh:mm A")}
                                </p>
                              </div>
                            </IonCol>
                          </IonRow>
                        </IonGrid>
                      </div>
                    </Link>
                  </div>
                );
              })
            ) : (
              <>{spin ? "" : translation("no_posts_found")}</>
            )}
          </div>
          <IonInfiniteScroll
            onIonInfinite={loadData}
            threshold='100px'
            disabled={!paginationState.hasMore}
          >
            <IonInfiniteScrollContent
              loadingSpinner='bubbles'
              loadingText='Loading more data...'
            ></IonInfiniteScrollContent>
          </IonInfiniteScroll>
        </div>
      </IonContent>
    </>
  );
};

export default SavedPost;
