import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonLabel,
  IonSpinner,
  IonTextarea,
  useIonToast,
} from "@ionic/react";
import React, { useEffect, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import { yupResolver } from "@hookform/resolvers/yup";
import moment from "moment";
import { Controller, useForm } from "react-hook-form";
import { RootStateOrAny, useSelector } from "react-redux";
import { chatboxOutline, thumbsUpOutline } from "ionicons/icons";
import { useTranslation } from "react-i18next";

import "./Forum.scss";
import userPlaceholder from "../../images/user-placeholder.jpeg";

import Header from "../../components/header/Header";
import { getPostById } from "../../redux/action-creators/postsAction";
import {
  IPostInterface,
  IDataSubmit,
} from "../../interfaceModules/IPostInterface";
import { createPostAction } from "../../redux/action-creators/postsAction";
import { PostShareValidationSchema } from "../../utils/validationschema";
import { isImageFile } from "../../utils/Helper";

const PostShare: React.FC = () => {
  const { t: translation } = useTranslation();
  const location = useLocation();
  const postId = location?.pathname?.includes("/post-share")
    ? location?.pathname?.split("/")?.[2]
    : undefined;
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [postInfo, setPostInfo] = useState<IPostInterface[]>([]);
  const [spin, setSpin] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const [present, dismiss] = useIonToast();

  useEffect(() => {
    if (postId) {
      fetchPostDetail();
    }
  }, []);

  const {
    control,
    resetField,
    handleSubmit,
    reset,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(PostShareValidationSchema()),
  });

  /**
   * @method to create Post when clicked on Submit
   * @param data
   */
  const onSubmit = async (data: IDataSubmit) => {
    setSpin(true);
    setButtonDisable(true);
    let response;

    response = await createPostAction({
      ...data,
      type: postInfo[0].type,
      type_item_id: postInfo[0].type_item_id,
      user_id: authData._id,
      shared_post_id: postId,
    });

    if (response?.data?.message && response?.data?.success) {
      present("post_shared", 2000);
      setTimeout(() => {
        history.goBack();
      }, 2000);
    } else {
      present(response?.data?.message, 2000);
    }
    setSpin(false);
    setButtonDisable(false);
  };

  /**
   * @method to fetch Details of Post
   */
  const fetchPostDetail = async () => {
    const response = await getPostById(postId as string);
    if (response?.data?.data.length > 0) {
      setPostInfo(response?.data?.data);
    }
  };

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            {/* post-input start */}
            <div className="post-input mb-30">
              <div className="form-group input-label">
                <IonLabel>{translation("title")}</IonLabel>
                <Controller
                  render={({ field }) => (
                    <IonTextarea
                      rows={18}
                      className="form-control"
                      placeholder="Add your text here…"
                      onIonChange={field.onChange}
                    ></IonTextarea>
                  )}
                  name="description"
                  control={control}
                  defaultValue=""
                />
                <div className="message error">
                  {errors && errors.description && (
                    <p>{errors?.description?.message}</p>
                  )}
                </div>
              </div>
              {/* </form> */}
              {/* topic-card start */}
              <div className="topic-card topic-card-border">
                <div className="card-head">
                  <div className="heading">
                    <div className="user-img">
                      <IonImg src={userPlaceholder} />
                    </div>
                    <div className="heading-inner">
                      <h5>
                        {translation("post_by")}{" "}
                        <span>{postInfo[0]?.user_info[0]?.name}</span>
                      </h5>
                      <p>
                        {"   "}
                        {moment(postInfo[0]?.created_ts).format(
                          "MMM DD, YYYY"
                        )}{" "}
                        {translation("at")}{" "}
                        {moment(postInfo[0]?.created_ts).format("hh:m A")}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="card-mid">
                  <div className="content">
                    <p>{postInfo[0]?.description}</p>
                  </div>
                  {postInfo[0]?.media_file &&
                  postInfo[0]?.media_file.length > 0 ? (
                    <div className="topic-img">
                      {isImageFile(postInfo[0]?.media_file.toLowerCase()) ? (
                        <IonImg src={postInfo[0]?.media_file} />
                      ) : (
                        <video width="100%" height="230" controls>
                          <source src={postInfo[0]?.media_file}></source>
                        </video>
                      )}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
                <div className="card-bottom">
                  <div className="links">
                    <ul className="justify-content-start">
                      <li>
                        <a>
                          <IonIcon icon={chatboxOutline} />{" "}
                          {postInfo[0]?.post_comments?.length}
                        </a>
                      </li>
                      <li>
                        <a>
                          <IonIcon icon={thumbsUpOutline} />
                          {postInfo[0]?.total?.like?.length}
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* topic-card end */}
            </div>
            {/* post-input end */}
            <div>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit(onSubmit)}
              >
                {translation("share")}
                {spin && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
              </IonButton>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default PostShare;
