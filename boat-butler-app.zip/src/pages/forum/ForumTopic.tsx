import {
  InputChangeEventDetail,
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonModal,
  IonPopover,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { useHistory, useLocation } from "react-router";
import moment from "moment";
import { useTranslation } from "react-i18next";
import { RootStateOrAny, useSelector } from "react-redux";
import React, { useEffect, useState } from "react";

import {
  arrowRedoOutline,
  bookmarkOutline,
  bookmarkSharp,
  chatboxOutline,
  ellipsisHorizontalCircleOutline,
  flagOutline,
  pencilOutline,
  thumbsUpOutline,
  thumbsUpSharp,
  sendOutline,
} from "ionicons/icons";
import "./Forum.scss";

import {
  likePostAction,
  unlikePostAction,
  reportPostAction,
} from "../../redux/action-creators/postsAction";
import { getPostById } from "../../redux/action-creators/postsAction";
import Header from "../../components/header/Header";
import {
  postCommentAction,
  getCommentAction,
} from "../../redux/action-creators/comment";
import {
  IPostInterface,
  IGetCommentInterface,
  IUserinfo,
} from "../../interfaceModules/ICommunityInterface";
import { isImageFile } from "../../utils/Helper";

const ForumTopic: React.FC = () => {
  const now = moment();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );

  const location = useLocation();
  const { t: translation } = useTranslation();
  const [showModal, setShowModal] = useState(false);
  const [disablePostLike, setPostLikeDisable] = useState(false);
  const [disableCommentLike, setCommentLikeDisable] = useState(false);

  const postId = location?.pathname?.includes("/post-detail")
    ? location?.pathname?.split("/")?.[2]
    : "";
  const [present] = useIonToast();
  const [comment, setComment] = useState<string>("");
  const [postInfo, setPostInfo] = useState<IPostInterface[]>([]);
  // const [userInfo, setUserInfo] = useState<IUserinfo[]>([]);
  // const [data, setData] = useState<ICommentInterface[]>([]);
  const [postCommentInfo, setPostCommentInfo] = useState<
    IGetCommentInterface[]
  >([]);

  useEffect(() => {
    if (postId) {
      fetchPostDetail();
    }
    getComment();
  }, []);

  /**
   * @method to get days difference from today
   * @param fromDate
   * @returns
   */
  const getDaysDifferenceFromToday = (fromDate: Date) => {
    const date1 = new Date(fromDate);
    const milliSec = Math.abs(date1.getTime() - Date.now());
    return Math.floor(milliSec / (24 * 60 * 60 * 1000));
  };

  /**
   * @method to fetch details of Post
   */
  const fetchPostDetail = async () => {
    const response = await getPostById(postId as string);
    if (response?.data?.data.length > 0) {
      setPostInfo(response?.data?.data);
    }
  };

  /**
   * @method to handle Change in comment
   * @param event
   */
  const handleChange = async (event: CustomEvent<InputChangeEventDetail>) => {
    event.preventDefault();
    let target = event.target as HTMLSelectElement;
    setComment(target.value);
  };

  const postComment = async () => {
    const response = await postCommentAction({
      user_id: authData._id,
      post_id: postId,
      comment: comment,
      status: "Active",
    });
    if (response?.data?.success) {
      getComment();
      setComment("");
      fetchPostDetail();
    }
    // console.log("postComment", response);
  };

  /**
   * @method to get Comment
   */
  const getComment = async () => {
    const result = await getCommentAction({ post_id: postId });
    console.log("resugetCommentlt--", result);
    if (result?.data?.success) {
      setPostCommentInfo(result?.data?.data);
    }
  };

  /**
   * @method to handle UnLike on Post
   * @param _id
   * @param type
   */
  const handleUnLike = async (_id: string, type: string) => {
    if (type === "like" || type === "bookmarks") {
      setPostLikeDisable(true);
      let response = await unlikePostAction({
        _id: _id,
        userId: authData._id,
        type,
      });

      fetchPostDetail();
      setPostLikeDisable(false);
    } else if (type === "comment") {
      setCommentLikeDisable(true);
      let response = await unlikePostAction({
        _id: _id,
        userId: authData._id,
        type,
      });

      getComment();
      setCommentLikeDisable(false);
    }
  };

  /**
   * @method to handle Like on Post
   * @param _id
   * @param type
   */
  const handleLike = async (_id: string, type: string) => {
    if (type === "like" || type === "bookmarks") {
      setPostLikeDisable(true);
      let response = await likePostAction({
        _id: _id,
        userId: authData._id,
        type,
      });
      fetchPostDetail();
      setPostLikeDisable(false);
    } else if (type === "comment") {
      setCommentLikeDisable(true);
      let response = await likePostAction({
        _id: _id,
        userId: authData._id,
        type,
      });
      // setPostLike(response?.data?.data?.total);
      getComment();
      setCommentLikeDisable(false);
    } else if (type === "report") {
      setShowModal(false);
      let response = await reportPostAction({
        _id: _id,
        userId: authData._id,
        type,
      });

      if (response?.data?.success) {
        setShowPopover((prevState) => ({ ...prevState, showPopover: false }));
        present("Post reported successfully", 2000);
        // history.goBack();
      }

      // fetchPostDetail();
    } else if (type === "flag") {
      let response = await reportPostAction({
        _id: _id,
        userId: authData._id,
        type,
      });

      if (response?.data?.success) {
        present("Comment reported successfully", 2000);
        getComment();
        fetchPostDetail();
        // history.goBack();
      }

      // fetchPostDetail();
    }
  };

  const [popoverState, setShowPopover] = useState<{
    showPopover: boolean;
    event?: Event;
  }>({
    showPopover: false,
    event: undefined,
  });

  return (
    <>
      <Header title={"Post"} />
      <IonContent fullscreen>
        <div className='forum-page'>
          <div className='main-container'>
            {/* topic-card start */}
            <div className='topic-card'>
              <div className='card-head'>
                {postInfo[0]?.user_info.length > 0
                  ? postInfo[0]?.user_info?.map(
                      (item: IUserinfo, index: number) => (
                        <div className='heading'>
                          <h5>
                            {translation("post_by")}{" "}
                            <span>{item?.name ? item?.name : ""}</span>
                          </h5>
                          <p>
                            {"    "}
                            {moment(postInfo[0]?.created_ts).format(
                              "MMM DD, YYYY"
                            )}{" "}
                            at{" "}
                            {moment(postInfo[0]?.created_ts).format("hh:mm A")}
                          </p>
                        </div>
                      )
                    )
                  : ""}

                <div className='card-head-btn'>
                  <a
                    className='link-icon-btn tertiary-btn'
                    onClick={(e) => {
                      e.persist();
                      setShowPopover({
                        showPopover: true,
                        event: e as unknown as Event,
                      });
                    }}
                  >
                    <IonIcon icon={ellipsisHorizontalCircleOutline} />
                  </a>
                </div>
              </div>

              <div className='card-mid'>
                <div className='content'>
                  <p>
                    {postInfo[0]?.description ? postInfo[0]?.description : ""}
                  </p>
                </div>
                {postInfo[0]?.shared_post_detail &&
                postInfo[0]?.shared_post_detail.length > 0 ? (
                  <div className='card-mid'>
                    <div className='content'>
                      <p>{translation("shared_post")}</p>
                    </div>
                    <div className='heading'>
                      <h5>
                        {translation("post_by")}{" "}
                        <span>
                          {postInfo[0]?.shared_post_detail[0]
                            ?.post_creator_detail[0]?.name
                            ? postInfo[0]?.shared_post_detail[0]
                                ?.post_creator_detail[0]?.name
                            : ""}
                        </span>
                      </h5>
                      <p>
                        {"    "}
                        {moment(
                          postInfo[0]?.shared_post_detail[0]
                            ?.post_creator_detail[0]?.created_ts
                        ).format("MMM DD, YYYY")}{" "}
                        {translation("at")}{" "}
                        {moment(
                          postInfo[0]?.shared_post_detail[0]
                            ?.post_creator_detail[0]?.created_ts
                        ).format("hh:mm A")}
                      </p>
                    </div>
                    <div className='content'>
                      <p>
                        {postInfo[0]?.shared_post_detail[0]?.description
                          ? postInfo[0]?.shared_post_detail[0]?.description
                          : ""}
                      </p>
                    </div>
                    {postInfo[0]?.shared_post_detail[0]?.media_file ? (
                      <div className='topic-img'>
                        {isImageFile(
                          postInfo[0]?.shared_post_detail[0]?.media_file.toLowerCase()
                        ) ? (
                          <IonImg
                            src={postInfo[0]?.shared_post_detail[0]?.media_file}
                          />
                        ) : (
                          <video width='100%' height='230' controls>
                            <source
                              src={
                                postInfo[0]?.shared_post_detail[0]?.media_file
                              }
                            ></source>
                          </video>
                        )}
                      </div>
                    ) : (
                      ""
                    )}
                  </div>
                ) : (
                  ""
                )}
                {postInfo[0]?.media_file &&
                postInfo[0]?.media_file.length > 0 ? (
                  <div className='topic-img'>
                    {isImageFile(postInfo[0]?.media_file.toLowerCase()) ? (
                      <IonImg src={postInfo[0]?.media_file} />
                    ) : (
                      <video width='100%' height='230' controls>
                        <source src={postInfo[0]?.media_file}></source>
                      </video>
                    )}
                  </div>
                ) : (
                  ""
                )}
              </div>

              <div className='card-bottom'>
                <div className='links'>
                  <ul>
                    <li>
                      <IonIcon icon={chatboxOutline} />
                      {postInfo?.[0]?.post_comments?.[0]?.total}
                    </li>

                    <li>
                      {postInfo[0]?.total?.like?.includes(authData._id) ? (
                        <IonButton
                          className='icon-btn primary-icon-btn'
                          type='button'
                          disabled={disablePostLike}
                          onClick={() => handleUnLike(postInfo[0]._id, "like")}
                        >
                          <IonIcon icon={thumbsUpSharp} />
                        </IonButton>
                      ) : (
                        <IonButton
                          className='icon-btn primary-icon-btn'
                          type='button'
                          disabled={disablePostLike}
                          onClick={() => handleLike(postInfo[0]._id, "like")}
                        >
                          <IonIcon icon={thumbsUpOutline} />
                        </IonButton>
                      )}
                      {postInfo[0]?.total?.like?.length}
                    </li>
                    <li>
                      {
                        // postInfo[0]?.total?.bookmarks?.includes(authData._id)
                        postInfo?.[0]?.total?.bookmarks?.find(
                          ({ user_id }: any) => user_id === authData._id
                        ) ? (
                          <IonButton
                            className='icon-btn primary-icon-btn'
                            type='button'
                            disabled={disablePostLike}
                            onClick={() =>
                              handleUnLike(postInfo[0]._id, "bookmarks")
                            }
                          >
                            <IonIcon icon={bookmarkSharp} />
                          </IonButton>
                        ) : (
                          <IonButton
                            className='icon-btn primary-icon-btn'
                            type='button'
                            disabled={disablePostLike}
                            onClick={() =>
                              handleLike(postInfo[0]._id, "bookmarks")
                            }
                          >
                            <IonIcon icon={bookmarkOutline} />
                          </IonButton>
                        )
                      }
                    </li>

                    <li>
                      <Link to={`/post-share/${postInfo[0]?._id}`}>
                        <IonIcon icon={arrowRedoOutline} />
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            {/* topic-card end */}

            {/* Comment start */}
            <div className='comment-section'>
              {/* comment-input */}
              <div className='form-group comment-input'>
                <IonLabel>
                  {translation("comment_as")}{" "}
                  <span>{authData?.name ? authData?.name : ""}</span>
                </IonLabel>
                <div className='comment-input-control'>
                  <IonInput
                    className='form-control'
                    placeholder='What are you thoughts?'
                    value={comment}
                    onIonChange={(e) => handleChange(e)}
                  ></IonInput>
                  <IonButton
                    type='button'
                    className='send-btn theme-button dark-btn'
                    disabled={comment?.length > 0 && comment ? false : true}
                    onClick={() => postComment()}
                  >
                    <IonIcon icon={sendOutline} />
                  </IonButton>
                </div>
              </div>

              <div className='comment-list'>
                {/* comment-item */}
                {postCommentInfo.length > 0 ? (
                  postCommentInfo.map((comment, index) =>
                    now.isAfter(comment.created_ts) ? (
                      <div className='comment-item'>
                        <div className='user-img'>
                          <IonImg src={comment?.userInfo[0]?.image} />
                        </div>
                        <div className='comment-detail'>
                          <div className='name'>
                            <h5>
                              {comment?.userInfo[0]?.name}
                              <span className='date'>
                                {getDaysDifferenceFromToday(
                                  comment.created_ts
                                ) == 0 ? (
                                  "today"
                                ) : (
                                  <>
                                    {getDaysDifferenceFromToday(
                                      comment.created_ts
                                    )}{" "}
                                    <span>{translation("days_ago")}</span>
                                  </>
                                )}{" "}
                              </span>
                            </h5>
                          </div>
                          <div className='brif'>
                            <p>{comment?.comment}</p>
                          </div>
                          <div className='links'>
                            <ul>
                              <li>
                                {comment?.total?.like?.includes(
                                  authData._id
                                ) ? (
                                  <IonButton
                                    className='icon-btn primary-icon-btn'
                                    type='button'
                                    disabled={disableCommentLike}
                                    onClick={() =>
                                      handleUnLike(comment?._id, "comment")
                                    }
                                  >
                                    <IonIcon icon={thumbsUpSharp} />
                                  </IonButton>
                                ) : (
                                  <IonButton
                                    className='icon-btn primary-icon-btn'
                                    type='button'
                                    disabled={disableCommentLike}
                                    onClick={() =>
                                      handleLike(comment._id, "comment")
                                    }
                                  >
                                    <IonIcon icon={thumbsUpOutline} />
                                  </IonButton>
                                )}
                                {comment?.total?.like?.length}
                              </li>

                              <li>
                                <IonIcon
                                  icon={flagOutline}
                                  onClick={() =>
                                    handleLike(comment._id, "flag")
                                  }
                                />
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    ) : (
                      ""
                    )
                  )
                ) : (
                  <span>{translation("no_comment")}</span>
                )}
              </div>
            </div>
            {/* Comment start */}
          </div>
        </div>
      </IonContent>

      <IonPopover
        className='theme-popover'
        event={popoverState.event}
        isOpen={popoverState.showPopover}
        onDidDismiss={() =>
          setShowPopover({ showPopover: false, event: undefined })
        }
      >
        <ul className='popover-details'>
          <li>
            <a>
              <IonIcon icon={pencilOutline} />
              {translation("edit")}
            </a>
          </li>
          <li>
            <a onClick={() => setShowModal(true)}>
              <IonIcon icon={flagOutline} />
              {translation("report")}
            </a>
          </li>
        </ul>
      </IonPopover>
      <IonModal
        className='theme-modal delete-account-modal'
        isOpen={showModal}
        breakpoints={[0.1, 0.5, 1]}
        initialBreakpoint={0.9}
      >
        <div className='modal-inner'>
          <div className='modal-header text-center'>
            <div className='modal-heading'>
              <h3>
                {translation("are_you_sure_you_want_to_report_this_post")}
              </h3>
            </div>
          </div>
          <div className='modal-body'>
            <div className='d-flex justify-content-center'>
              <IonButton
                onClick={() => {
                  handleLike(postId, "report");
                }}
                className='theme-button primary-btn'
              >
                {translation("yes")}
              </IonButton>
              <IonButton
                onClick={() => setShowModal(false)}
                className='theme-button primary-outline-btn'
              >
                {translation("no")}
              </IonButton>
            </div>
          </div>
        </div>
      </IonModal>
    </>
  );
};

export default ForumTopic;
