import { IonButton, IonContent } from "@ionic/react";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";

import {
  IForum,
  IForumInterface,
} from "../../interfaceModules/IForumInterface";
import "./Forum.scss";
import {
  addNewForumAction,
  getForumListAction,
  getUserForumAction,
} from "../../redux/action-creators/forum";
import Header from "../../components/header/Header";

const Forum: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();

  const [forumList, setForumList] = useState<IForumInterface[]>([]);
  const [forumSaveList, setForumSaveList] = useState<string[]>([]);

  const [showLoader, setShowLoader] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  let user_id = authData._id;

  useEffect(() => {
    fetchForum();
    fetchUserForum();
  }, []);

  /**
   * @method to fetch Forum
   */
  const fetchForum = async () => {
    const res = await getForumListAction();
    setForumList(res?.data?.data);
  };

  /**
   * @method to fetch User Forum
   */
  const fetchUserForum = async () => {
    const res = await getUserForumAction({ _id: authData._id });
    let tempForumList: string[] = [];

    res?.data?.data?.map((item: IForum, index: number) => {
      tempForumList.push(item?._id);
    });

    setForumSaveList(tempForumList);
  };

  /**
   * @method to handle Forum
   * @param _id
   */
  const handleForum = (_id: string) => {
    let tempForumList = [...forumSaveList];
    if (tempForumList.includes(_id)) {
      tempForumList.splice(tempForumList.indexOf(_id), 1);
    } else {
      tempForumList.push(_id);
    }
    setForumSaveList(tempForumList);
  };

  /**
   * @method to add new Forum when clicked on Submit
   */
  const onSubmit = async () => {
    setShowLoader(true);
    setButtonDisable(true);

    const res = await addNewForumAction({ forumSaveList, user_id });
    // if (res?.data?.success) {
    //   present(translation("forum_added_successfully"), 2000);
    // }
    setTimeout(() => history.push("/forum-main"), 2000);

    setShowLoader(false);
    setButtonDisable(false);
  };

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            <div className="forum-card">
              <div className="heading">
                <h4>{translation("please_select_minimum_topic")}</h4>
              </div>
              <div className="item-list">
                <ul>
                  {forumList?.map((forum: IForumInterface, index: number) => {
                    return (
                      <li key={index}>
                        <a
                          className={
                            forumSaveList.includes(forum._id) ? "active" : ""
                          }
                          onClick={() => {
                            handleForum(forum._id);
                          }}
                        >
                          {forum.title}
                        </a>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
            <div>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={onSubmit}
                disabled={forumSaveList.length < 3}
              >
                {translation("save")}
              </IonButton>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Forum;
