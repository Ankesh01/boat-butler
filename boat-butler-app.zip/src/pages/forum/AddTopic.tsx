import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonTextarea,
  useIonToast,
} from "@ionic/react";
import { useHistory } from "react-router";
import { RootStateOrAny, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

import { cameraOutline, closeCircleOutline } from "ionicons/icons";
import "./Forum.scss";

import Header from "../../components/header/Header";
import { isImageFile, uploadFileOnS3 } from "../../utils/Helper";
import { getForumListAction } from "../../redux/action-creators/forum";
import { createPostAction } from "../../redux/action-creators/postsAction";
import { deleteFile } from "../../redux/action-creators/FileUpload";
import { IPostInterface } from "../../interfaceModules/IPostInterface";
import { IAddTopicInterface } from "../../interfaceModules/IForumInterface";

const AddTopic: React.FC = () => {
  const { t: translation } = useTranslation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const history = useHistory();
  const [spin, setSpin] = useState(false);
  const [postState, setPostState] = useState<IPostInterface>();
  const [topicList, setTopicList] = useState([]);
  const [loader, setLoader] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  let [errorMessage, setErrorMessage] = useState({
    title: "",
    description: "",
    type_item_id: "",
  });
  const [present, dismiss] = useIonToast();

  useEffect(() => {
    fetchForum();
  }, []);

  /**
   * @method to fetch Forum Data
   */
  const fetchForum = async () => {
    const res = await getForumListAction();
    setTopicList(res?.data?.data);
  };

  /**
   * @method to handle Change
   * @param event
   * @param key
   */
  const handleChange = (event: any, key: string) => {
    const { value } = event.detail;
    setErrorMessage((prevState) => ({
      ...prevState,
      [key]: undefined,
    }));
    setPostState((prevState: any) => ({ ...prevState, [key]: value }));
  };

  /**
   * @method to handle Uploaded images
   * @param event
   */
  const handleUpload = async (event: any) => {
    setSpin(true);
    const { files } = event.target;
    const fileUrlList = await uploadFileOnS3(files, "posts");
    setPostState((prevState: any) => ({
      ...prevState,
      media_file: fileUrlList[0],
    }));
    setSpin(false);
  };

  /**
   * @method to handle Removed Images
   */
  const handleRemoveImage = () => {
    setSpin(true);
    const file: any = [postState?.media_file];
    deleteFile(file);

    setPostState((prevState: any) => ({
      ...prevState,
      media_file: "",
    }));
    setSpin(false);
  };

  /**
   * @method to validate User Info
   * @returns
   */
  const validateUserInfo = () => {
    let isFormValid = true;

    if (postState?.title == null || postState?.title == "") {
      isFormValid = false;
      errorMessage.title = "Title is required";
    }
    if (postState?.type_item_id == null || postState?.type_item_id == "") {
      isFormValid = false;
      errorMessage.type_item_id = "Option is required";
    }

    if (postState?.description == null || postState?.description == "") {
      isFormValid = false;
      errorMessage.description = "description is required";
    }
    setPostState((prevState: any) => ({
      ...prevState,
    }));
    return isFormValid;
  };

  /**
   * @method to create Post Forum when clicked on Submit
   */
  const handleSubmit = async () => {
    setButtonDisable(true);
    setLoader(true);
    setPostState((prevState: any) => ({
      ...prevState,
    }));

    if (validateUserInfo()) {
      const response = await createPostAction({
        ...postState,
        user_id: authData._id,

        type: "forum",
      });
      if (response?.data?.message && response?.data?.success) {
        present(response?.data?.message, 1000);
        setTimeout(() => {
          history.goBack();
        }, 2000);
      } else {
        present(response?.data?.message, 1000);
      }
    }
    setLoader(false);
    setButtonDisable(false);
  };

  return (
    <>
      <Header title={"New Post"} />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            <div className="form-group input-label">
              <IonLabel>{translation("post_topic")}</IonLabel>
              <IonSelect
                className="form-control"
                interface="popover"
                placeholder="— Select —"
                value={postState?.type_item_id}
                onIonChange={(e) => handleChange(e, "type_item_id")}
              >
                {topicList.map((topic: IAddTopicInterface) => (
                  <IonSelectOption value={topic.id}>
                    {topic.title}
                  </IonSelectOption>
                ))}
              </IonSelect>
              <div className="message error">
                {errorMessage && errorMessage?.type_item_id && (
                  <p>{errorMessage?.type_item_id}</p>
                )}
              </div>
            </div>
            <div className="form-group input-label">
              <IonLabel>{translation("title")}</IonLabel>
              <IonInput
                type="text"
                className="form-control"
                placeholder="Lorem Ipsum is simply"
                onIonChange={(e) => handleChange(e, "title")}
                value={postState?.title}
              />
              <div className="message error">
                {errorMessage && errorMessage?.title && (
                  <p>{errorMessage?.title}</p>
                )}
              </div>
            </div>
            <div className="form-group input-label">
              <IonLabel>{translation("description")}</IonLabel>
              <IonTextarea
                rows={18}
                className="form-control"
                placeholder="Lorem Ipsum is simply"
                onIonChange={(e) => handleChange(e, "description")}
                value={postState?.description}
              />
              <div className="message error">
                {errorMessage && errorMessage?.description && (
                  <p>{errorMessage?.description}</p>
                )}
              </div>
            </div>

            <div className="form-group mb-30">
              {postState?.media_file && postState?.media_file.length > 0 ? (
                <div className="uploaded-file mt-15">
                  {isImageFile(postState?.media_file.toLowerCase()) ? (
                    <IonImg src={postState?.media_file} />
                  ) : (
                    <video width="100%" height="230" controls>
                      <source src={postState?.media_file}></source>
                    </video>
                  )}

                  <div className="action-btn">
                    <IonButton
                      type="button"
                      className="icon-btn primary-icon-btn "
                      onClick={() => handleRemoveImage()}
                    >
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>
                </div>
              ) : (
                <>
                  <IonLabel>{translation("add_media")}</IonLabel>
                  <div className="file-upload-card">
                    <div className="card-inner">
                      <IonIcon icon={cameraOutline} />
                      <p>{translation("tap_to_upload")}</p>
                    </div>
                    <input
                      className="file-input"
                      accept="image/*,video/*"
                      type="file"
                      onChange={(e) => {
                        handleUpload(e);
                      }}
                    />
                    {spin && (
                      <span>
                        <IonSpinner />
                      </span>
                    )}
                  </div>
                </>
              )}
            </div>

            <div>
              <IonButton
                expand="block"
                className="theme-button primary-btn"
                onClick={handleSubmit}
              >
                {translation("create")}
                {loader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
              </IonButton>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default AddTopic;
