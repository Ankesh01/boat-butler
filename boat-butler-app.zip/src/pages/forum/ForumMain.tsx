import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonRow,
  IonSpinner,
} from "@ionic/react";
import { useHistory } from "react-router-dom";
import { RootStateOrAny, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

import {
  addCircleOutline,
  bookmarkOutline,
  chatbubbleEllipsesOutline,
  chevronDownOutline,
  helpCircleOutline,
  peopleOutline,
  starOutline,
} from "ionicons/icons";
import "./Forum.scss";

import Header from "../../components/header/Header";
import { getPostListAction } from "../../redux/action-creators/postsAction";
import { IPost } from "../../interfaceModules/IPost";
import PostsCard from "../../components/PostsCard";
import { IPostInterface } from "../../interfaceModules/ICommunityInterface";
import { IForumMain } from "../../interfaceModules/IForumInterface";

const ForumMain: React.FC = () => {
  const history = useHistory();
  const { t: translation } = useTranslation();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [postList, setPostList] = useState<IPost[]>([]);
  const [showLoader, setShowLoader] = useState(false);
  const [isInfiniteDisabled, setInfiniteDisabled] = useState(false);
  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });
  const [showDropdown, setShowDropDown] = useState(false);
  useEffect(() => {
    fetchPostList(true, 0);
  }, []);

  /**
   * @method to load more Data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchPostList(false, paginationState.offset);
      ev.target.complete();
    }, 500);
  };
  const refreshPostList = () => {
    console.log("Refreshing---");
    fetchPostList(true, 0);
  };

  /**
   * @method to update like on Post
   * @param data
   * @param type
   * @param index
   */
  const updatePostLike = (data: IForumMain, type: string, index: number) => {
    let postListTemp = [...postList];
    postListTemp[index] = data;
    setPostList(postListTemp);
  };

  /**
   * @method to fetch List of Post
   * @param firstLoad
   */
  const fetchPostList = async (firstLoad: boolean, offset: number) => {
    setShowLoader(true);
    if (offset !== paginationState.prevOffset || firstLoad) {
      if (paginationState.hasMore || firstLoad) {
        let result = await getPostListAction(authData._id, offset);
        console.log("fetchPostList---", result);
        if (result?.data?.success) {
          setPaginationState((prevState) => ({
            ...prevState,
            prevOffset:
              result?.data?.data.length > 0 ? offset : offset ? offset - 10 : 0,
            offset:
              result?.data?.data.length > 0 ? prevState.offset + 10 : offset,
            hasMore: result?.data?.data.length > 0,
          }));
          setPostList(
            firstLoad
              ? result?.data?.data
              : (prevState) => [...prevState, ...result?.data?.data]
          );
          // setShowLoader(false);
        } else {
          // setShowLoader(false);
          setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
        }
      } else {
        // setShowLoader(false);
        setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
      }
    } else {
      setPaginationState((prevState) => ({ ...prevState, hasMore: false }));
      // setShowLoader(false);
    }
    setShowLoader(false);
  };

  return (
    <>
      <Header title={"What's new"} />
      <IonContent fullscreen>
        <div className="forum-page">
          <div className="main-container">
            <form>
              <div className="form-group">
                <div className="drop-select">
                  <div
                    className="right-icon-input primary-group"
                    onClick={() => setShowDropDown(!showDropdown)}
                  >
                    <IonInput
                      className="form-control primary-control"
                      placeholder="— Select —"
                    ></IonInput>
                    <a>
                      <IonIcon icon={chevronDownOutline} />
                    </a>
                  </div>
                  {showDropdown && (
                    <div className="drop-select-box">
                      <IonGrid>
                        <IonRow>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                              onClick={() => history.push("/add-topic")}
                            >
                              {translation("add_new")}{" "}
                              <IonIcon icon={addCircleOutline} />
                            </IonButton>
                          </IonCol>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                              onClick={() => history.push("/saved-post")}
                            >
                              {translation("view_saved")}{" "}
                              <IonIcon icon={bookmarkOutline} />
                            </IonButton>
                          </IonCol>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                            >
                              {translation("replied")}{" "}
                              <IonIcon icon={chatbubbleEllipsesOutline} />
                            </IonButton>
                          </IonCol>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                            >
                              {translation("featured")}{" "}
                              <IonIcon icon={starOutline} />
                            </IonButton>
                          </IonCol>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                            >
                              {translation("posted")}{" "}
                              <IonIcon icon={helpCircleOutline} />
                            </IonButton>
                          </IonCol>
                          <IonCol size="6">
                            <IonButton
                              expand="block"
                              className="theme-button dark-outline-btn right-icon-btn"
                              onClick={() => history.push("/community-list")}
                            >
                              {translation("community")}{" "}
                              <IonIcon icon={peopleOutline} />
                            </IonButton>
                          </IonCol>
                        </IonRow>
                      </IonGrid>
                    </div>
                  )}
                </div>
              </div>

              <div>
                {showLoader && (
                  <span>
                    <IonSpinner />
                  </span>
                )}
                {postList && postList.length > 0 ? (
                  postList.map((post, index) => (
                    <PostsCard
                      post={post as IPostInterface}
                      index={index}
                      updatePostLike={(data: IForumMain, type: string) =>
                        updatePostLike(data, type, index)
                      }
                      refreshPostList={refreshPostList}
                    />
                  ))
                ) : (
                  <>{showLoader ? "" : "No Posts Found"}</>
                )}

                {/*<div className="news-card">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="7">
                        <div className="content">
                          <div className="date">
                            <span>Post: Jan 12, 2021 at 10:30 AM</span>
                          </div>
                          <div className="brif">
                            <p>
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry.
                            </p>
                          </div>
                          <div className="status">
                            <p>
                              Comment:
                              <span>7.9K</span>
                            </p>
                            <p>
                              Like:
                              <span>27.3K</span>
                            </p>
                          </div>
                        </div>
                      </IonCol>
                      <IonCol size="5">
                        <div className="card-img">
                          <IonImg src={boatGalleryImg} />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>*/}
              </div>
            </form>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={!paginationState.hasMore}
            >
              <IonInfiniteScrollContent
                loadingSpinner="bubbles"
                loadingText="Loading more data..."
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default ForumMain;
