import {
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonLabel,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  SelectChangeEventDetail,
  useIonToast,
} from "@ionic/react";
import React, { useEffect, useRef, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useHistory, useLocation } from "react-router";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import "./AddBoat.scss";
import Header from "../../components/header/Header";
import { yupResolver } from "@hookform/resolvers/yup";
import { AddBoatSchema } from "../../utils/validationschema";
import { add_Boat, IEquipment } from "../../interfaceModules/IBoatInterface";
import {
  downloadFile,
  formatDate,
  formatDBTimestamp,
  getPicture,
  uploadFileOnS3,
} from "../../utils/Helper";
import {
  Engine_hp_option,
  Engine_option,
  Engine_year_option,
} from "../../utils/constants";
import {
  addBoatAction,
  editBoatAction,
  getBoatByIdAction,
  getBoatCountByUserId,
  getEngineMakeListAction,
} from "../../redux/action-creators/boat";
import {
  addCircleOutline,
  closeCircleOutline,
  downloadOutline,
} from "ionicons/icons";
import { deleteFile } from "../../redux/action-creators/FileUpload";

const AddBoat: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const location = useLocation();
  const boatId = location.pathname.includes("/edit-boat")
    ? location.pathname.split("/")?.[2]
    : undefined;
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [present, dismiss] = useIonToast();
  const [Img, setImg] = React.useState<any>({
    boat_image: [],
    engine_image: [],
    engine_manual: [],
    equipmentImages: {},
  });
  const [engineMakeList, setEngineMakeList] = useState<
    { _id: string; models?: string[] }[]
  >([]);
  const [engineModalList, setEngineModalList] = useState<string[]>([]);
  const [isOtherMake, setIsOtherMake] = useState(false);
  const [boatCount, setBoatCount] = useState<number>(0);
  const [isOtherModel, setIsOtherModel] = useState(false);
  const [buttonDisable, setButtonDisable] = useState(false);
  const [deletedFiles, setDeletedFile] = useState<string[]>([]);

  const {
    control,
    resetField,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<add_Boat>({
    mode: "onChange",
    resolver: yupResolver(AddBoatSchema(isOtherMake, isOtherModel)),
  });
  const inputRef: any = useRef();
  const { fields, append, remove } = useFieldArray({
    control,
    name: "otherEquip",
  });
  const [spin, setSpin] = useState(false);

  useEffect(() => {
    if (boatId) {
      fetchBoatDetail();
    }
    fetchEngineModelData();
    fetchBoatCount();
  }, []);

  /**
   * @method to fetch detail of Boat
   */
  const fetchBoatDetail = async () => {
    const response = await getBoatByIdAction(boatId as string);
    if (response?.data?.data) {
      const boatData = response.data.data;
      let equipmentImages: { string: string[] } | {} = {};
      boatData.other_equipments.map((equipment: IEquipment, index: number) => {
        let newObj = {
          [index]: equipment.img?.map((i: string) => ({ data: i, format: "" })),
        };
        equipmentImages = { ...equipmentImages, ...newObj };
      });
      setImg({
        boat_image: boatData.photos.map((i: string) => ({
          data: i,
          format: "",
        })),
        engine_image: boatData.engine.photos.map((i: string) => ({
          data: i,
          format: "",
        })),
        engine_manual: boatData.engine.manual.map((i: string) => ({
          data: i,
          format: "",
        })),
        equipmentImages: equipmentImages,
      });
      reset({
        title: boatData.title,
        date: formatDBTimestamp(boatData.date_of_bought),
        phone_number: boatData.seller_phone,
        RegId: boatData.registration_id,
        vin: boatData.vin,
        boat_make: boatData.make,
        boat_model: boatData.model,
        year_hull: formatDBTimestamp(boatData.year_of_hull),
        engine_no: boatData.engine.number_of_engines,
        engine_make: boatData.engine.make,
        engine_model: boatData.engine.model,
        engine_hours: boatData.engine.hours,
        engine_year: boatData.engine.year,
        engine_SN: boatData.engine.serial_number,
        otherEquip: boatData.other_equipments,
      });
    }
  };

  /**
   * @method to fetch data of model of Engine
   */
  const fetchEngineModelData = async () => {
    const response = await getEngineMakeListAction();
    setEngineMakeList([...response?.data?.data, { _id: "other" }]);
  };
  /**
   * @method to fetch count of boat
   */
  const fetchBoatCount = async () => {
    const response = await getBoatCountByUserId(authData._id);
    if (response?.data?.success) {
      setBoatCount(response.data.data);
    }
  };
  console.log("boat-Count", boatCount);

  /**
   * @method to handle Images
   * @param number
   * @param type
   * @param name
   * @param index
   * @returns
   */
  const handleImages = async (
    number: string,
    type: string,
    name: string,
    index?: string
  ) => {
    let images = await getPicture(number, type);
    if (!images) {
      return null;
    }
    const temp = { ...Img };
    if (name === "equipmentImages") {
      index = index ? index : "0";
      let indexItems = temp[name][index] ? temp[name][index] : [];
      temp[name] = {
        ...temp[name],
        [index]: [...indexItems, images],
      };
    } else {
      temp[name] = [...temp[name], images];
    }
    setImg(temp);
  };

  /**
   * @method to edit and add Boat
   * @param data
   */
  const onSubmit = async (data: add_Boat) => {
    let response;
    setButtonDisable(true);
    if (boatId) {
      response = await editBoatAction(boatId as string, {
        ...data,
        ...Img,
        isOtherMake,
        isOtherModel,
        user_id: authData._id,
      });
    } else {
      response = await addBoatAction({
        ...data,
        ...Img,
        isOtherMake,
        isOtherModel,
        user_id: authData._id,
      });
    }

    if (response?.data?.success) {
      if (deletedFiles.length > 0) {
        deleteFile(deletedFiles);
      }
      history.goBack();
    }
    setButtonDisable(false);
  };

  const addEquipment = () => {
    append({
      equip_make: "",
      equip_model: "",
      year_bought: "",
      equip_SN: "",
      img: [],
    });
  };

  /**
   * @method to remove Image File
   * @param index
   * @param name
   */
  const removeImageFile = (index: number, name: string) => {
    const img = Img[name];
    let galleryImages = [...img];
    if (name === "engine_manual") {
      let deletedFile = [...galleryImages][index];
      setDeletedFile((prevState) => [
        ...prevState,
        deletedFile?.data as string,
      ]);
    }
    galleryImages.splice(index, 1);
    setImg((prevState: any) => ({
      ...prevState,
      [name]: galleryImages,
    }));
  };

  /**
   * @method to remove Equipment Image
   * @param imageIndex
   * @param index
   */
  const removeEquipmentImage = (imageIndex: number, index: number) => {
    const img = Img.equipmentImages;
    let galleryImages = [img];
    galleryImages[0][index].splice(imageIndex, 1);
    setImg((prevState: any) => ({
      ...prevState,
      equipmentImages: Object.assign(galleryImages[0]),
    }));
  };

  /**
   * @method to handle Engine Make
   * @param event
   */
  const handleEngineMakeChange = (
    event: CustomEvent<SelectChangeEventDetail>
  ) => {
    const { value } = event.detail;
    if (value === "other") {
      setIsOtherMake(true);
      setIsOtherModel(true);
      resetField("engine_make");
    } else {
      let modalList = engineMakeList.filter((modal) => modal._id === value)[0];
      setEngineModalList(
        modalList["models"] ? [...modalList["models"], "other"] : ["other"]
      );
    }
  };

  /**
   * @method to handle Changes in Model
   * @param event
   */
  const handleModelChange = (event: CustomEvent<SelectChangeEventDetail>) => {
    const { value } = event.detail;
    if (value === "other") {
      setIsOtherModel(true);
      resetField("engine_model");
    }
  };

  /**
   * @method to handle Uploded file
   * @param event
   */
  const handleFileUpload = async (event: any) => {
    let { files } = event.target;
    setSpin(true);
    const fileUrlList = await uploadFileOnS3(files, "engine_manual");
    let state = { ...Img };
    state.engine_manual = [
      ...state.engine_manual,
      ...fileUrlList.map((i: string) => ({ data: i, format: "" })),
    ];
    setImg({ ...state });
    setSpin(false);
  };

  /**
   * @method to Download File when clicked
   * @param data
   */
  const handleDownloadClick = async (data: string) => {
    const fileUri = await downloadFile(data);
    present(
      `File Downloaded ${fileUri ? `in ${fileUri?.toString()}` : ""}`,
      3000
    );
  };

  return (
    <>
      <Header title={boatId ? "Edit Boat" : "Add New Boat"} />
      <IonContent fullscreen>
        <div className='addboat-page-inner'>
          <div className='main-container'>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className='form-inner'>
                <div className='mb-30'>
                  <div className='inner-heading'>
                    <h3>
                      {boatId ? "Edit" : "Add New"} {translation("boat_info")}
                    </h3>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("title")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Title'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='title'
                      control={control}
                    />
                    <div className='message error'>
                      {errors && errors.title && (
                        <p>{errors?.title?.message}</p>
                      )}
                    </div>
                  </div>

                  <div className='form-group input-label'>
                    <IonLabel>{translation("date_bought")}</IonLabel>
                    <div className='right-icon-input'>
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type='date'
                            className='form-control'
                            placeholder='DD - MM - YYYY'
                            max={formatDate(new Date())}
                            onIonChange={(e) => {
                              field.onChange(e);
                            }}
                          />
                        )}
                        name='date'
                        control={control}
                      />

                      <div className='message error'>
                        {errors && errors.date && (
                          <p>{errors?.date?.message}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className='form-group input-label'>
                    <IonLabel>{translation("seller_no")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='number'
                          className='form-control'
                          placeholder='Seller’s Phone Number'
                          onIonChange={field.onChange}
                          maxlength={10}
                        />
                      )}
                      name='phone_number'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.phone_number && (
                        <p>{errors?.phone_number?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("reg_no")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Registration ID'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='RegId'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.RegId && (
                        <p>{errors?.RegId?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("vin")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='VIN'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='vin'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.vin && <p>{errors?.vin?.message}</p>}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("boat_make")}</IonLabel>

                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Boat Make'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='boat_make'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.boat_make && (
                        <p>{errors?.boat_make?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("boat_model")}</IonLabel>

                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Boat Model'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='boat_model'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.boat_model && (
                        <p>{errors?.boat_model?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("year_of_hull")}</IonLabel>
                    <div className='right-icon-input'>
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type='date'
                            className='form-control'
                            placeholder='DD - MM - YYYY'
                            onIonChange={field.onChange}
                            max={formatDate(new Date())}
                          />
                        )}
                        name='year_hull'
                        control={control}
                      />

                      <div className='message error'>
                        {errors && errors.year_hull && (
                          <p>{errors?.year_hull?.message}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className='form-group'>
                    {Img.boat_image.length > 0 &&
                      Img.boat_image.map((i: any, index: number) => (
                        <div key={index} className='upload-image'>
                          <IonImg src={i?.data} alt='' />
                          <IonButton
                            className='icon-btn primary-icon-btn'
                            type='button'
                            onClick={() => removeImageFile(index, "boat_image")}
                          >
                            <IonIcon icon={closeCircleOutline} />
                          </IonButton>
                        </div>
                      ))}
                    <div className='file-upload-btn'>
                      <IonButton
                        expand='block'
                        className='theme-button dark-outline-btn'
                        onClick={() =>
                          handleImages("single", "base64", "boat_image")
                        }
                      >
                        {translation("add_photos_of_boat")}
                      </IonButton>
                    </div>
                  </div>
                </div>

                <div className='mb-30'>
                  <div className='inner-heading'>
                    <h3>{translation("ad_engine")}</h3>
                  </div>

                  <div className='form-group input-label'>
                    <IonLabel>{translation("type_engine_no")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Type Engine Number'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='engine_no'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.engine_no && (
                        <p>{errors?.engine_no?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("engine_make")}</IonLabel>
                    {isOtherMake ? (
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type='text'
                            className='form-control'
                            placeholder='Type Engine Make'
                            onIonChange={field.onChange}
                          />
                        )}
                        name='engine_make'
                        control={control}
                      />
                    ) : (
                      <Controller
                        render={({ field }) => (
                          <IonSelect
                            {...field}
                            placeholder='— Select —'
                            className='form-control'
                            onIonChange={(e) => {
                              field.onChange(e);
                              handleEngineMakeChange(e);
                            }}
                            value={field.value}
                          >
                            {engineMakeList.length > 0 &&
                              engineMakeList?.map((engine_make, index) => {
                                return (
                                  <IonSelectOption
                                    key={index}
                                    value={engine_make._id}
                                  >
                                    {engine_make._id}
                                  </IonSelectOption>
                                );
                              })}
                          </IonSelect>
                        )}
                        name={"engine_make"}
                        control={control}
                      />
                    )}

                    {errors && errors.engine_make && (
                      <div className='message error'>
                        <p> {errors?.engine_make?.message}</p>
                      </div>
                    )}
                  </div>

                  <div className='form-group input-label'>
                    <IonLabel>{translation("engine_model")}</IonLabel>
                    {isOtherMake || isOtherModel ? (
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type='text'
                            className='form-control'
                            placeholder='Type Engine Model'
                            onIonChange={field.onChange}
                          />
                        )}
                        name='engine_model'
                        control={control}
                      />
                    ) : (
                      <Controller
                        render={({ field }) => (
                          <IonSelect
                            {...field}
                            placeholder='— Select —'
                            className='form-control'
                            onIonChange={(e) => {
                              field.onChange(e);
                              handleModelChange(e);
                            }}
                            value={field.value}
                          >
                            {engineModalList.length > 0 &&
                              engineModalList?.map((engine_model, index) => {
                                return (
                                  <IonSelectOption
                                    key={index}
                                    value={engine_model}
                                  >
                                    {engine_model}
                                  </IonSelectOption>
                                );
                              })}
                          </IonSelect>
                        )}
                        name={"engine_model"}
                        control={control}
                      />
                    )}

                    {errors && errors.engine_model && (
                      <div className='message error'>
                        <p> {errors?.engine_model?.message}</p>
                      </div>
                    )}
                  </div>
                  {isOtherModel && (
                    <div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("engine_hp")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_hp_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_hp'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_hp && (
                            <p>{errors?.engine_hp?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("engine_dry_weight")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type='text'
                              className='form-control'
                              placeholder='Add Engine Dry Weight'
                              onIonChange={field.onChange}
                            />
                          )}
                          name='engine_dry_weight'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_dry_weight && (
                            <p>{errors?.engine_dry_weight?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("engine_start_type")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_start_type'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_start_type && (
                            <p>{errors?.engine_start_type?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("engine_tilt")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_tilt_trim'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_tilt_trim && (
                            <p>{errors?.engine_tilt_trim?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("engine_fuel")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_fuel_type'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_fuel_type && (
                            <p>{errors?.engine_fuel_type?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("year")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_year_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_year_model'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_year_model && (
                            <p>{errors?.engine_year_model?.message}</p>
                          )}
                        </div>
                      </div>
                      <div className='form-group input-label'>
                        <IonLabel>
                          {translation("engine_strock_series")}
                        </IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonSelect
                              {...field}
                              placeholder='— Select —'
                              className='form-control'
                              onIonChange={(e) => field.onChange(e)}
                              value={field.value}
                            >
                              {Engine_option.map((option, index) => {
                                return (
                                  <IonSelectOption key={index} value={option}>
                                    {option}
                                  </IonSelectOption>
                                );
                              })}
                            </IonSelect>
                          )}
                          name='engine_strock_series'
                          control={control}
                        />

                        <div className='message error'>
                          {errors && errors.engine_strock_series && (
                            <p>{errors?.engine_strock_series?.message}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  <div className='form-group input-label'>
                    <IonLabel>{translation("engine_hour")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Add Hours'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='engine_hours'
                      control={control}
                    />

                    <div className='message error'>
                      {errors && errors.engine_hours && (
                        <p>{errors?.engine_hours?.message}</p>
                      )}
                    </div>
                  </div>
                  <div className='form-group input-label'>
                    <IonLabel>{translation("engine_year")}</IonLabel>
                    <div className='right-icon-input'>
                      <Controller
                        render={({ field }) => (
                          <IonInput
                            {...field}
                            type='date'
                            className='form-control'
                            placeholder='DD - MM - YYYY'
                            onIonChange={field.onChange}
                            max={formatDate(new Date())}
                          />
                        )}
                        name='engine_year'
                        control={control}
                      />

                      <div className='message error'>
                        {errors && errors.engine_year && (
                          <p>{errors?.engine_year?.message}</p>
                        )}
                      </div>
                      {/* <IonInput
                        type="text"
                        className="form-control"
                        placeholder="DD - MM - YYYY"
                      ></IonInput> */}
                      {/* <a>
                        <IonIcon icon={calendarClearOutline} />
                      </a> */}
                    </div>
                  </div>

                  <div className='form-group input-label'>
                    <IonLabel>{translation("sn")}</IonLabel>
                    <Controller
                      render={({ field }) => (
                        <IonInput
                          {...field}
                          type='text'
                          className='form-control'
                          placeholder='Engine Number'
                          onIonChange={field.onChange}
                        />
                      )}
                      name='engine_SN'
                      control={control}
                    />

                    {errors && errors.engine_SN && (
                      <div className='message error'>
                        <p>{errors?.engine_SN?.message}</p>
                      </div>
                    )}

                    {/* <IonInput
                      type="text"
                      className="form-control"
                      placeholder="Engine Number"
                    ></IonInput> */}
                  </div>
                  <div className='form-group'>
                    {Img.engine_manual.length > 0 &&
                      Img.engine_manual.map((i: any, index: number) => (
                        <div key={index}>
                          <div className='file-card'>
                            <svg
                              xmlns='http://www.w3.org/2000/svg'
                              width='19.43'
                              height='24'
                              viewBox='0 0 19.43 24'
                            >
                              <path
                                id='Union_22'
                                data-name='Union 22'
                                d='M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z'
                                transform='translate(-23740.998 -12058.001)'
                              />
                            </svg>

                            <div className='action-btn'>
                              <IonButton
                                type='button'
                                className='icon-btn primary-icon-btn '
                                onClick={() => handleDownloadClick(i.data)}
                              >
                                <IonIcon icon={downloadOutline} />
                              </IonButton>
                              <IonButton
                                type='button'
                                className='icon-btn primary-icon-btn '
                                onClick={() =>
                                  removeImageFile(index, "engine_manual")
                                }
                              >
                                <IonIcon icon={closeCircleOutline} />
                              </IonButton>
                            </div>
                          </div>
                        </div>
                        // <div key={index} className="upload-image">
                        //   <div className="file-card">
                        //     <svg
                        //       xmlns="http://www.w3.org/2000/svg"
                        //       width="19.43"
                        //       height="24"
                        //       viewBox="0 0 19.43 24"
                        //     >
                        //       <path
                        //         id="Union_22"
                        //         data-name="Union 22"
                        //         d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                        //         transform="translate(-23740.998 -12058.001)"
                        //       />
                        //     </svg>

                        //     <div className="action-btn">
                        //       <IonButton
                        //         type="button"
                        //         className="icon-btn primary-icon-btn "
                        //         onClick={() => downloadFile(i.data)}
                        //       >
                        //         {/* <IonIcon icon={downloadOutline} /> */}
                        //       </IonButton>
                        //       <IonButton
                        //         type="button"
                        //         className="icon-btn primary-icon-btn "
                        //         onClick={() =>
                        //           removeImageFile(index, "engine_manual")
                        //         }
                        //       >
                        //         <IonIcon icon={closeCircleOutline} />
                        //       </IonButton>
                        //     </div>
                        //   </div>

                        //   {/* <IonImg src={i.data} alt="" /> */}
                        //   {/* <IonButton
                        //     className="icon-btn primary-icon-btn"
                        //     type="button"
                        //     onClick={() =>
                        //       removeImageFile(index, "engine_manual")
                        //     }
                        //   >
                        //     <IonIcon icon={closeCircleOutline} />
                        //   </IonButton> */}
                        // </div>
                      ))}

                    <div className='file-upload-btn'>
                      <input
                        type='file'
                        style={{ display: "none" }}
                        ref={inputRef}
                        onChange={handleFileUpload}
                      />
                      <IonButton
                        expand='block'
                        className='theme-button dark-outline-btn'
                        onClick={() => inputRef.current.click()}
                      >
                        {translation("upload_engine_manual")}
                        {spin && (
                          <span>
                            <IonSpinner />
                          </span>
                        )}
                      </IonButton>
                    </div>
                  </div>
                  <div className='form-group'>
                    {Img.engine_image.length > 0 &&
                      Img.engine_image.map((i: any, index: number) => (
                        <div key={index} className='upload-image'>
                          <IonImg src={i.data} alt='' />
                          <IonButton
                            className='icon-btn primary-icon-btn'
                            type='button'
                            onClick={() =>
                              removeImageFile(index, "engine_image")
                            }
                          >
                            <IonIcon icon={closeCircleOutline} />
                          </IonButton>
                        </div>
                      ))}
                    <div className='file-upload-btn'>
                      <IonButton
                        expand='block'
                        className='theme-button dark-outline-btn'
                        onClick={() =>
                          handleImages("single", "base64", "engine_image")
                        }
                      >
                        {translation("add_photos_of_engine")}
                      </IonButton>
                    </div>
                  </div>
                </div>

                {/* {equip.map((equipment, index) => ( */}
                <div className='mb-30'>
                  <div className='inner-heading'>
                    <h3>{translation("other_equipment")}</h3>
                    <IonButton
                      expand='block'
                      className='icon-btn primary-icon-btn'
                      onClick={() => addEquipment()}
                    >
                      <IonIcon icon={addCircleOutline} />
                    </IonButton>
                  </div>

                  {/* <button onClick={() => addEquipment()}>Add</button> */}

                  {fields.map((equipment, index) => (
                    <div key={index}>
                      <div className='form-group input-label'>
                        <IonLabel>{translation("equipment_make")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type='text'
                              className='form-control'
                              placeholder='Company Name'
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_make`}
                          control={control}
                        />

                        <div className='message error'>
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_make"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_make?.message}
                              </p>
                            )}
                        </div>
                      </div>

                      <div className='form-group input-label'>
                        <IonLabel>{translation("equipment_model")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type='text'
                              className='form-control'
                              placeholder='Model Number'
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_model`}
                          control={control}
                        />

                        <div className='message error'>
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_model"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_model?.message}
                              </p>
                            )}
                        </div>
                      </div>

                      <div className='form-group input-label'>
                        <IonLabel>{translation("year_install")}</IonLabel>
                        <div className='right-icon-input'>
                          <Controller
                            render={({ field }) => (
                              <IonInput
                                {...field}
                                type='date'
                                className='form-control'
                                placeholder='DD - MM - YYYY'
                                onIonChange={field.onChange}
                                max={formatDate(new Date())}
                              />
                            )}
                            name={`otherEquip.${index}.year_bought`}
                            control={control}
                          />
                          {/*     <a>*/}
                          {/*  <IonIcon icon={calendarClearOutline} />*/}
                          {/*</a>*/}
                        </div>
                      </div>

                      <div className='form-group input-label'>
                        <IonLabel>{translation("sn")}</IonLabel>
                        <Controller
                          render={({ field }) => (
                            <IonInput
                              {...field}
                              type='text'
                              className='form-control'
                              placeholder='Serial Number'
                              onIonChange={field.onChange}
                            />
                          )}
                          name={`otherEquip.${index}.equip_SN`}
                          control={control}
                        />

                        <div className='message error'>
                          {errors &&
                            errors.otherEquip &&
                            errors.otherEquip[index] &&
                            errors.otherEquip[index]["equip_SN"] && (
                              <p>
                                {errors.otherEquip[index]?.equip_SN?.message}
                              </p>
                            )}
                        </div>
                        <div className='form-group'>
                          {Img.equipmentImages?.[index.toString()]?.map(
                            (i: any, imageIndex: number) => (
                              <div key={imageIndex} className='upload-image'>
                                <IonImg src={i.data} alt='' />
                                <IonButton
                                  className='icon-btn primary-icon-btn'
                                  onClick={() =>
                                    removeEquipmentImage(imageIndex, index)
                                  }
                                >
                                  <IonIcon icon={closeCircleOutline} />
                                </IonButton>
                              </div>
                            )
                          )}
                          <div className='file-upload-btn'>
                            <IonButton
                              expand='block'
                              className='theme-button dark-outline-btn'
                              onClick={() =>
                                handleImages(
                                  "single",
                                  "base64",
                                  "equipmentImages",
                                  index.toString()
                                )
                              }
                            >
                              {translation("add_equipment_photos")}
                            </IonButton>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* ))} */}

                  <div className='profile-btn'>
                    <IonButton
                      expand='block'
                      className='theme-button primary-btn'
                      onClick={handleSubmit(onSubmit)}
                      disabled={
                        buttonDisable
                          ? buttonDisable
                          : boatCount >
                            authData?.paymentInfo?.plan_info?.boat_count
                          ? true
                          : false
                      }
                    >
                      {translation("save_boat")}
                    </IonButton>
                  </div>
                  <>
                    {boatCount <
                    authData?.paymentInfo?.plan_info?.boat_count ? (
                      ""
                    ) : (
                      <div className='message error'>
                        You have reached the limit of your Plan. Please Upgrade
                        your Plan for adding new boats
                      </div>
                    )}
                  </>
                </div>
              </div>
            </form>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default AddBoat;
