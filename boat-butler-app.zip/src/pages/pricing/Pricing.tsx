import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonInput,
  IonRow,
} from "@ionic/react";
import { Link } from "react-router-dom";

import {
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
} from "ionicons/icons";

import "./Pricing.scss";
import pricingBg from "../../images/pricing-bg.png";
import logo from "../../images/logo.png";
import {
  InAppPurchase2,
  IAPProduct,
  IAPError,
} from "@ionic-native/in-app-purchase-2";
import { Capacitor } from "@capacitor/core";

import {MutableRefObject, useEffect, useMemo, useRef, useState} from "react";
import { isPlatform } from "@ionic/react";
import {createPaymentAction, getPlanListAction} from "../../redux/action-creators/paymentAction";
import { IPlan } from "../../interfaceModules/IPlan";
import moment from "moment";

const Pricing: React.FC = () => {
  const [planList, setPlanList] = useState<IPlan[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [paymentConfirmation, setPaymentConfirmation] = useState<string>("");
  const [selectedPlan, setSelectedPlan] = useState<IPlan | null>(null);
  const paymentRef = useRef<HTMLDivElement>(null);
  useOutsideAlerter(paymentRef.current as HTMLElement);

  function useOutsideAlerter(element: any) {
    useEffect(() => {
      function handleClickOutside(event: any) {
        if (!paymentRef.current?.contains(event.target)) {
          setShowCheckout(false);
        }
      }

      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [element]);
  }

  useEffect(() => {
    fetchPlans();
  }, []);

  useEffect(() => {
    if (planList.length > 0) {
      IntializeInAppPurchase();
    }
  }, [planList]);

  useEffect(() => {
    if (paymentConfirmation.length > 0) {
      const plan = planList.filter(
        (plan) => plan.slug === paymentConfirmation
      )[0];
      setSelectedPlan(plan);
    }
  }, [paymentConfirmation]);

  useEffect(()=>{
    console.log(" useEffect paymentRef.current ",paymentRef.current)})

  const fetchPlans = async () => {
    const response = await getPlanListAction();
    if (response?.data?.data) {
      setPlanList(response?.data?.data);
    }
  };

  const IntializeInAppPurchase = async () => {
    InAppPurchase2.verbosity = InAppPurchase2.DEBUG;
    await registerProducts();
    await setupListeners();
    await InAppPurchase2.ready(() => {
      console.log("Product details", InAppPurchase2.products);
    });
  };

  const registerProducts = async () => {
    for (let plan of planList) {
      console.log(
        "registerProducts ",
        plan.slug,
        plan.price > 0 ? "PAID_SUBSCRIPTION" : "FREE_SUBSCRIPTION"
      );
      await InAppPurchase2.register({
        id: plan.slug,
        type:
          plan.price > 0
            ? InAppPurchase2.PAID_SUBSCRIPTION
            : InAppPurchase2.FREE_SUBSCRIPTION,
      });
    }
    refresh();
  };

  /**
   * Setting up listeners & making API call for update user details
   */
  const setupListeners = () => {
    console.log("setupListeners called ");
    InAppPurchase2.when("product")
      .approved(async (p: IAPProduct) => {
        // p["user_id"] = localStorage.getItem("userId");
        // p["price"] = 90;
        console.log("Product info in listener PURCHASED!!!!!!!!!!!!!!! ", p);
        p.verify();
        // setIsLoading(true);
        let timeAmount = 30;
        let unit = "days"
        if(p.id.includes("month")){
          timeAmount = 1;
          unit = "month";
        }else if(p.id.includes("year")){
          timeAmount = 1;
          unit = "year";
        }
        const end_date = moment()
            .add(timeAmount, unit as "days" | "month" | "year")
            .format("YYYY-MM-DD hh:mm:ss");
        const response = await createPaymentAction(
            {
              user_id : localStorage.getItem("userId") as string,
              product : p,
              end_date : end_date
            }
        )
        /*const response = await dispatch(
              isPlatform("android")
                  ? buyAndroidSubscription(p)
                  : buyIosSubscription(p)
          );*/
        /*if (response) {
            const subscription_end_date = moment()
                .add(30, "days")
                .format("YYYY-MM-DD hh:mm:ss");
            dispatch({
              type: "LOGIN",
              payload: {
                data: {
                  message: "",
                  user: {
                    ...authData,
                    subscription_end_date: subscription_end_date,
                  },
                },
              },
            });
            setIsLoading(false);
            setToast({
              show: true,
              message: "Successfully Subscribed!",
              class: "alert-success",
            });
          } else {
            setToast({
              show: true,
              message: "Something went wrong!",
              class: "alert-danger",
            });
            setIsLoading(false);
          }*/
      })
      .verified(async (p: IAPProduct) => {
        p.finish();
      });

    /* if (isPlatform("android")) {
        dispatch(buyAndroidSubscription(prod))
          .then((res) => {

          })
          .catch((error) => {
            console.log("API response error android", error);
            setToast({
              show: true,
              message: "Something went wrong",
              class: "alert-danger",
            });
          });
      } else {
        dispatch(buyIosSubscription(prod))
          .then((res) => {
            console.log("API response result ios", res);
            setToast({
              show: true,
              message: "Successfully Subscribed!",
              class: "alert-success",
            });
          })
          .catch((error) => {
            console.log("API response error ios", error);
            setToast({
              show: true,
              message: "Something went wrong",
              class: "alert-danger",
            });
          });
      }*/
    // InAppPurchase2.when(productId).owned((p) => {
    //   console.log("Inside SetupListeners owned ", p);
    //   p.finish();
    // });
  };

  const registerHandlersForPurchase = (productId: string) => {
    console.log("registerHandlersForPurchase ", productId);
    let self = InAppPurchase2;
    InAppPurchase2.when(productId).updated(function (product: IAPProduct) {
      console.log("Product !!!!!!!!!", product);
      if (
        product.loaded &&
        product.valid &&
        product.state === self.APPROVED &&
        product.transaction != null
      ) {
        product.finish();
      }
    });
  };

  /**
   * Ordering subscription
   */
  const handleSubscriptionPayment = (plan: IPlan) => {
    try {
      setupListeners();
      registerHandlersForPurchase(plan.slug);
      console.log("ordering ", plan["slug"]);
      InAppPurchase2.order(plan["slug"]).then(
        (p: IAPProduct) => {
          console.log("Product response", p);
        },
        (e: IAPError) => {
          console.log("Error Ordering From Store", e);
        }
      );
    } catch (err) {
      console.error("Error Ordering ", err);
    }
  };

  const refresh = () => {
    InAppPurchase2.refresh();
  };

  const changeFrequency = (frequency: "monthly" | "yearly") => {
    let swapFrequency = {
      monthly: "yearly",
      yearly: "monthly",
    };
    setPaymentConfirmation(
      paymentConfirmation.replace(swapFrequency[frequency], frequency)
    );
  };

  // console.log("paymentConfirmation ******* ", paymentConfirmation, selectedPlan)

  const formatText = (text: string) =>
    text.charAt(0).toUpperCase() + text.slice(1);

  return (
    <IonContent fullscreen>
      <div
        className="pricing-page"
        style={{ backgroundImage: `url(${pricingBg})` }}
      >
        <div className="main-container">
          <div className="pricing-heading">
            <h2>Pricing</h2>
            <p>
              Lorem Ipsum has been the industry’s standard dummy text ever since
              the 1500s.
            </p>
          </div>

          <div className="pricing-card-list">
            <div className="pricing-card">
              <a
                className={
                  paymentConfirmation.includes("personal") ? "active" : ""
                }
                onClick={() => setPaymentConfirmation("personal_yearly")}
              >
                <div className="name">
                  <h3>Personal</h3>
                  <p>
                    $
                    {
                      planList.filter(
                        (plan) => plan.slug === "personal_yearly"
                      )?.[0]?.["price"]
                    }{" "}
                    billed yearly
                  </p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>
                    {
                      planList.filter(
                        (plan) => plan.slug === "personal_monthly"
                      )?.[0]?.["price"]
                    }
                    <sub>/mo</sub>
                  </p>
                </div>
              </a>
            </div>

            <div className="pricing-card">
              <a
                className={
                  paymentConfirmation.includes("professional") ? "active" : ""
                }
                onClick={() => setPaymentConfirmation("professional_yearly")}
              >
                <div className="name">
                  <h3>Professional</h3>
                  <p>
                    $
                    {
                      planList.filter(
                        (plan) => plan.slug === "professional_yearly"
                      )?.[0]?.["price"]
                    }{" "}
                    billed yearly
                  </p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>
                    {
                      planList.filter(
                        (plan) => plan.slug === "professional_monthly"
                      )?.[0]?.["price"]
                    }
                    <sub>/mo</sub>
                  </p>
                </div>
              </a>
            </div>

            <div className="pricing-card">
              <a
                className={
                  paymentConfirmation.includes("business") ? "active" : ""
                }
                onClick={() => setPaymentConfirmation("business_yearly")}
              >
                <div className="name">
                  <h3>Business</h3>
                  <p>
                    $
                    {
                      planList.filter(
                        (plan) => plan.slug === "business_yearly"
                      )?.[0]?.["price"]
                    }{" "}
                    billed yearly
                  </p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>
                    {
                      planList.filter(
                        (plan) => plan.slug === "business_monthly"
                      )?.[0]?.["price"]
                    }
                    <sub>/mo</sub>
                  </p>
                </div>
              </a>
            </div>

            <div className="pricing-card">
              <a
                className={paymentConfirmation.includes("free") ? "active" : ""}
                onClick={() => setPaymentConfirmation("free")}
              >
                <div className="name">
                  <h3>Free trial</h3>
                  <p>30 days free trial</p>
                </div>
                <div className="amount">
                  <p>
                    <sup>$</sup>0<sub>/mo</sub>
                  </p>
                </div>
              </a>
            </div>
          </div>

          {paymentConfirmation.length > 0 && (
            <div className="pricing-bottom-btn">
              <IonButton
                expand="block"
                className="theme-button white-outline-btn right-icon-btn"
                onClick={() => setShowCheckout(true)}
              >
                Continue <IonIcon icon={arrowForwardOutline} />
              </IonButton>
            </div>
          )}
        </div>

        {/* Confirm Payment start */}
        {showCheckout && (
          <div
              className="price-payemnt-card"
              ref={paymentRef}>
            <div className="main-container">
              <div className="price-payemnt-card-inner">
                <div className="card-top">
                  <span className="blank-border"></span>
                  <h2>Confirm Payment</h2>
                  <p>Lorem Ipsum has been the industry’s.</p>
                </div>
                <div className="card-mid">
                  <div className="card-tab">
                    <div className="card-tab-menu">
                      <ul>
                        <li>
                          <a
                            className={
                              paymentConfirmation.includes("monthly")
                                ? "active"
                                : ""
                            }
                            onClick={() => changeFrequency("monthly")}
                          >
                            Monthly
                          </a>
                        </li>
                        <li>
                          <a
                            className={
                              paymentConfirmation.includes("yearly")
                                ? "active"
                                : ""
                            }
                            onClick={() => changeFrequency("yearly")}
                          >
                            Yearly
                          </a>
                        </li>
                      </ul>
                    </div>

                    <div className="card-tab-content">
                      <div className="price-table">
                        <table>
                          <thead>
                            <tr>
                              <td>Plan</td>
                              <td>
                                <b>
                                  {formatText(
                                    paymentConfirmation.split("_")[0]
                                  )}
                                </b>
                              </td>
                            </tr>
                            <tr>
                              <td>Billing Cycle</td>
                              <td>
                                <b>
                                  {formatText(
                                    paymentConfirmation.split("_")[1]
                                  )}
                                </b>
                              </td>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Plan</td>
                              <td>${selectedPlan?.["price"]}.00</td>
                            </tr>
                            <tr>
                              <td>Tax</td>
                              <td>$2.00</td>
                            </tr>
                            <tr>
                              <td>Total</td>
                              <td>$10.00</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="auth-btn">
                  <IonButton
                    expand="block"
                    className="theme-button right-icon-btn primary-btn"
                    onClick={() =>
                      handleSubscriptionPayment(selectedPlan as IPlan)
                    }
                  >
                    Continue <IonIcon icon={arrowForwardOutline} />
                  </IonButton>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Confirm Payment end */}

        {/* Checkout start */}
        {false && (
          <div className="price-payemnt-card">
            <div className="main-container">
              <div className="price-payemnt-card-inner">
                <div className="card-top">
                  <span className="blank-border"></span>
                  <h2>Checkout</h2>
                  <p>
                    There are many variations of passages of Lorem Ipsum
                    available, but the majority have suffered alteration in
                    some.
                  </p>
                </div>
                <div className="card-mid">
                  <IonGrid className="p-0">
                    <IonRow>
                      <IonCol size="12">
                        <div className="form-group mb-0">
                          <IonInput
                            type="number"
                            className="form-control"
                            placeholder="Card Number"
                          />
                        </div>
                      </IonCol>
                      <IonCol size="6">
                        <div className="form-group mb-0">
                          <IonInput
                            type="number"
                            className="form-control"
                            placeholder="MM/ YY"
                          />
                        </div>
                      </IonCol>
                      <IonCol size="6">
                        <div className="form-group mb-0">
                          <IonInput
                            type="number"
                            className="form-control"
                            placeholder="CVV"
                          />
                        </div>
                      </IonCol>
                      <IonCol size="12">
                        <div className="form-group mb-0">
                          <IonInput
                            type="number"
                            className="form-control"
                            placeholder="Card Holder"
                          />
                        </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>

                  <div className="total-status" onClick={refresh}>
                    <div className="total-heading">
                      <h3>Total</h3>
                    </div>
                    <div className="total-price">
                      <span>$90.00 USD</span>
                    </div>
                  </div>
                </div>
                <div className="auth-btn">
                  <IonButton
                    expand="block"
                    className="theme-button right-icon-btn primary-btn"
                    onClick={() => handleSubscriptionPayment(planList[0])}
                  >
                    Confirm Payments <IonIcon icon={arrowForwardOutline} />
                  </IonButton>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Checkout end */}
      </div>
    </IonContent>
  );
};

export default Pricing;
