import {
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonSpinner,
  IonSkeletonText,
  IonThumbnail,
  IonLabel,
  IonItem,
} from "@ionic/react";
import React, { useEffect, useState } from "react";
import { locateOutline, locationOutline } from "ionicons/icons";
import { Link } from "react-router-dom";
import "./BusinessDirectory.scss";
import { useTranslation } from "react-i18next";
import Header from "../../components/header/Header";
import {
  getServiceProviderAction,
  GooglePlacesDetail,
} from "../../redux/action-creators/businessDirectory";
import { IServiceProviderInterface } from "../../interfaceModules/IServiceProvider";
import { Geolocation } from "@capacitor/geolocation";
import GoogleMapReact, { Position } from "google-map-react";
import { InputChangeEventDetail } from "@ionic/core";

interface Coords {
  lat: number;
  lng: number;
}

interface IMarker {
  icon: any;
  lat?: number;
  lng?: number;
  draggable?: boolean;
  text?: string;
  color: "blue" | "red";
}

const BusinessDirectory: React.FC = () => {
  const [loadingService, setLoadingService] = useState(false);
  const [enableGoogleSearch, setEnableGoogleSearch] = useState(true);
  const { t: translation } = useTranslation();
  const [predictions, setPredictions] = useState<any>([]);
  const [coordinates, setCoordinates] = useState<null | Coords>(null);
  const [selectedPlace, setselectedPlace] = useState("");
  const [serviceProvider, setserviceProvider] = useState<
    IServiceProviderInterface[]
  >([]);
  const [timeOutState, setTimeOutState] = useState(null);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    getCurrentLocation();
  }, []);

  useEffect(() => {
    if (selectedPlace.trim().length > 0 && enableGoogleSearch) {
      googleSearch(selectedPlace);
    } else {
      setTimeout(() => {
        setPredictions([]);
      }, 1000);
    }
  }, [selectedPlace]);

  useEffect(() => {
    if (coordinates) {
      fetchServiceProvider(coordinates);
    }
  }, [coordinates]);

  /**
   * @method to get Current Location
   */
  const getCurrentLocation = async () => {
    try {
      const coordinates = await Geolocation.getCurrentPosition();
      const coords = {
        lat: coordinates.coords.latitude,
        lng: coordinates.coords.longitude,
      };
      setselectedPlace("");
      setCoordinates(coords);
      fetchServiceProvider(coords);
      setErrorMsg("");
    } catch (e) {
      setErrorMsg("Please enable GPS to load Google Map!");
    }
  };

  /**
   * @method to fetch Service Provider
   * @param coordinates
   */
  const fetchServiceProvider = async (coordinates: Coords) => {
    setLoadingService(true);
    const response = await getServiceProviderAction(coordinates);
    setserviceProvider(response?.data?.data ? response?.data?.data : []);
    setLoadingService(false);
  };

  /**
   * @method to selectedPlace
   * @param e
   * @param place
   */
  const onPlaceSelected = async (e: any, place: any) => {
    e.preventDefault();
    setEnableGoogleSearch(false);
    setselectedPlace(place.description);

    const response = await GooglePlacesDetail(place.place_id);
    if (response?.data?.success) {
      setTimeout(() => setCoordinates(response?.data?.data), 200);
    }
    setTimeout(() => setEnableGoogleSearch(true), 500);
  };

  /**
   * @method to handle data when searched
   * @param event
   */
  const handleSearchChange = async (
    event: CustomEvent<InputChangeEventDetail>
  ) => {
    event.preventDefault();
    const { value } = event.detail;
    setselectedPlace(value as string);
  };

  /**
   * @method to Google search
   * @param value
   */
  const googleSearch = async (value: string) => {
    if (timeOutState) {
      clearInterval(timeOutState);
    }
    const result = setTimeout(async () => {
      const results = await googleAutocomplete(value);
      setPredictions(results);
    }, 1000);

    setTimeOutState(result as any);
  };

  /**
   * @method to do AutoComplete by Google
   * @param text
   * @returns
   */
  const googleAutocomplete = async (text: string) =>
    new Promise((resolve, reject) => {
      if (!text) {
        return reject("Need valid text input");
      }
      if (typeof window === "undefined") {
        return reject("Need valid window object");
      }
      try {
        new window.google.maps.places.AutocompleteService().getPlacePredictions(
          { input: text, componentRestrictions: { country: ["us"] } },
          resolve
        );
      } catch (e) {
        reject(e);
      }
    });

  const Marker = (props: IMarker) => (
    <div>
      <IonIcon style={{ color: props.color }} icon={props.icon} />
      <span>{props.text}</span>
    </div>
  );

  return (
    <>
      <Header title={"Business Directory"} />
      <IonContent fullscreen>
        <div className="business-directory-page">
          <div className="main-container">
            <div className="form-group search-drop">
              <div className="right-icon-input">
                <IonInput
                  type="text"
                  className="form-control"
                  placeholder="Search Address"
                  value={selectedPlace}
                  onIonChange={(e) => handleSearchChange(e)}
                />

                <a onClick={getCurrentLocation}>
                  <IonIcon icon={locateOutline} />
                </a>
              </div>
              {predictions.length !== 0 && (
                <div className="search-drop-list">
                  {predictions?.map((prediction: any, index: number) => (
                    <a
                      key={prediction?.place_id}
                      onClick={(e) => onPlaceSelected(e, prediction)}
                    >
                      {prediction?.description || "Not found"}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <div className="map">
              {coordinates ? (
                <GoogleMapReact
                  bootstrapURLKeys={{
                    key: "AIzaSyD9guG6ZID_cWtX_pMilg7wheKFj_8hJ6A",
                  }}
                  draggable
                  zoom={16}
                  center={coordinates as Coords}
                  options={{
                    fullscreenControl: false,
                    zoomControl: false,
                    draggable: true,
                  }}
                >
                  <Marker
                    lat={coordinates?.lat}
                    lng={coordinates?.lng}
                    color={"blue"}
                    text={"Target Location"}
                    icon={locationOutline}
                  />

                  {serviceProvider.map(
                    (service: IServiceProviderInterface, index) => (
                      <Marker
                        key={index}
                        color={"red"}
                        lat={service.location.coordinates[0]}
                        lng={service.location.coordinates[1]}
                        text={service.business_name}
                        icon={locationOutline}
                      />
                    )
                  )}
                </GoogleMapReact>
              ) : errorMsg.length > 0 ? (
                <p>{errorMsg}</p>
              ) : (
                <IonSpinner />
              )}
            </div>

            <div>
              <div className="common-heading">
                <div className="heading w-100">
                  <h2>{translation("service_providers")}</h2>
                </div>
              </div>

              <div>
                {/* Service Providers start */}
                {loadingService ? (
                  <IonItem>
                    <IonThumbnail slot="start">
                      <IonSkeletonText animated />
                    </IonThumbnail>
                    <IonLabel>
                      <h3>
                        <IonSkeletonText animated style={{ width: "50%" }} />
                      </h3>
                      <p>
                        <IonSkeletonText animated style={{ width: "80%" }} />
                      </p>
                      <p>
                        <IonSkeletonText animated style={{ width: "60%" }} />
                      </p>
                    </IonLabel>
                  </IonItem>
                ) : (
                  <>
                    {" "}
                    {serviceProvider.map(
                      (service: IServiceProviderInterface, index: number) => {
                        return (
                          <Link to={`/service-provider/${service._id}`}>
                            <div className="service-providers-card" key={index}>
                              <div className="card-img">
                                <IonImg src={service.photos[0]} />
                              </div>
                              <div className="card-detail">
                                <div className="heading">
                                  <h3>{service.business_name}</h3>
                                  <span>{service.owner_name}</span>
                                </div>
                                <div className="mid">
                                  <p>{service.location?.city}</p>
                                </div>
                                <div className="bottom">
                                  <span>
                                    {translation("distance")}
                                    {Math.floor(Number(service?.distance))}KM
                                  </span>
                                </div>
                              </div>
                            </div>
                          </Link>
                        );
                      }
                    )}
                  </>
                )}

                {/* Service Providers end */}
              </div>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};
export default BusinessDirectory;
