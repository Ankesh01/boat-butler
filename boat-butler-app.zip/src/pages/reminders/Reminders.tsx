import {
  IonButton,
  IonCheckbox,
  IonContent,
  IonIcon,
  IonToggle,
  ToggleChangeEventDetail,
  useIonToast,
} from "@ionic/react";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import React from "react";
import { RootStateOrAny, useSelector } from "react-redux";
import moment from "moment";
import { useTranslation } from "react-i18next";

import { addCircleOutline, trashOutline } from "ionicons/icons";
import "./Reminders.scss";

import Header from "../../components/header/Header";
import {
  deleteReminderByIdAction,
  getAllReminderAction,
  reminderNotificationAction,
} from "../../redux/action-creators/reminder";
import { IReminderInterface } from "../../interfaceModules/IReminderInterface";

const Reminders: React.FC = () => {
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [present, dismiss] = useIonToast();
  const { t: translation } = useTranslation();
  const [reminder, setReminder] = React.useState<IReminderInterface[]>([]);
  const [showLoader, setShowLoader] = React.useState(false);
  const [deleteReminderIdList, setDeleteReminderIdList] = React.useState<
    string[]
  >([]);

  useEffect(() => {
    fetchReminders();
  }, []);

  /**
   * @method to fetch reminder
   */
  const fetchReminders = async () => {
    setShowLoader(true);
    const response = await getAllReminderAction(authData._id);
    if (response?.data?.data) {
      setReminder(response?.data?.data);
    }
    setShowLoader(false);
  };

  /**
   * @method to delete reminder
   */
  const deleteReminders = async () => {
    const response: any = await deleteReminderByIdAction(deleteReminderIdList);

    if (response?.data) {
      setReminder(response?.data);
    }
    if (response?.data?.success) {
      present(translation("reminder_deleted_successfully"), 2000);
      fetchReminders();
    }
  };

  /**
   * @method to handle change on checklist icon
   * @param id
   */
  const handleChangeCheckList = async (id: string) => {
    let deleteIdList = [...deleteReminderIdList];
    if (deleteIdList.includes(id)) {
      deleteIdList.splice(deleteIdList.indexOf(id), 1);
    } else {
      deleteIdList.push(id);
    }
    setDeleteReminderIdList(deleteIdList);
  };

  /**
   * @method to handle change in toggle
   * @param e
   * @param reminder_id
   */
  const handleToggleChange = async (
    e: CustomEvent<ToggleChangeEventDetail>,
    reminder_id: string
  ) => {
    const { checked } = e.detail;
    const status = checked ? "Pending" : "Completed";
    await reminderNotificationAction({
      reminder_id: reminder_id,
      send_status: checked ? 0 : 1,
      status,
    });
    let reminderList = [...reminder];
    for (let reminder of reminderList) {
      if (reminder._id === reminder_id) {
        reminder["status"] = status;
      }
    }
    setReminder(reminderList);
  };

  return (
    <>
      <Header title={"Reminders"} />
      <IonContent fullscreen>
        <div className="reminders-page">
          <div className="main-container">
            <div className="reminders-list">
              {/* item */}

              {reminder.length > 0 ? (
                <>
                  <div className="delete-reminders">
                    <IonButton
                      className="icon-btn danger-icon-btn-outline icon-btn-outline"
                      onClick={deleteReminders}
                    >
                      <IonIcon icon={trashOutline} />
                    </IonButton>
                  </div>

                  <>
                    {reminder.map(
                      (items: IReminderInterface, index: number) => {
                        return (
                          <div className="reminders-item">
                            <div className="check-reminder" key={index}>
                              <div className="form-group">
                                <IonCheckbox
                                  slot="end"
                                  checked={deleteReminderIdList.includes(
                                    items.id
                                  )}
                                  value={items.id}
                                  onIonChange={() =>
                                    handleChangeCheckList(items.id)
                                  }
                                />
                              </div>
                            </div>
                            <div className="info" key={index}>
                              <div className="name">
                                <h4>{items?.title}</h4>
                              </div>
                              <div className="time">
                                <span>
                                  {items?.due_start_datetime
                                    ? moment(items?.due_start_datetime).format(
                                        "DD/MM/YYYY"
                                      )
                                    : ""}
                                </span>
                                <span>
                                  {items?.due_start_datetime
                                    ? moment(items?.due_start_datetime).format(
                                        "hh:mm A"
                                      )
                                    : ""}
                                </span>
                              </div>
                            </div>
                            <div className="pending-toggle">
                              <IonToggle
                                value={items.id}
                                checked={items.status === "Pending"}
                                onIonChange={(e) =>
                                  handleToggleChange(e, items.id)
                                }
                              />
                            </div>
                          </div>
                        );
                      }
                    )}
                  </>
                </>
              ) : null}
            </div>

            <div className="new-reminders-link">
              <Link
                to="/new-reminder"
                className="link-btn primary-link-btn left-icon-link"
              >
                <IonIcon icon={addCircleOutline} />
                {translation("new_reminder")}
              </Link>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Reminders;
