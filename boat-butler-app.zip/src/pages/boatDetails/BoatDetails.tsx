import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonRow,
} from "@ionic/react";
import { pencilOutline } from "ionicons/icons";
import { useHistory } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

import { getBoatByIdAction } from "../../redux/action-creators/boat";
import { BoatDb } from "../../interfaceModules/IBoatInterface";
import { formatTimestamp } from "../../utils/Helper";

import "./BoatDetails.scss";
import boatImg from "../../images/boat.png";
import boatGalleryImg from "../../images/boat-gallery-img.jpg";

import Header from "../../components/header/Header";
import {
  getBoatServicesByUserId,
  getServicesHistory,
} from "../../redux/action-creators/boatServices";
import ServiceCard from "../../components/ServiceCard";

const BoatDetails: React.FC = (props: any) => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [upcomingService, setUpcomingService] = useState([]);
  const [serviceHistory, setServiceHistory] = useState([]);
  const [boatState, setBoatState] = useState<BoatDb>({
    user_id: "",
    title: "",
    date_of_bought: new Date(),
    seller_phone: "",
    registration_id: "",
    vin: "",
    make: "",
    model: "",
    year_of_hull: 0,
    engine: {},
    other_equipments: [],
    photos: [],
  });
  const boatId = props.location.pathname.split("/")[2];

  useEffect(() => {
    fetchBoat();
    fetchBoatServices();
    fetchBoatServicesHistory();
  }, []);

  /**
   * @method to fetch services of Boat
   */
  const fetchBoatServices = async () => {
    const response = await getBoatServicesByUserId(authData._id, { boatId });
    setUpcomingService(response?.data?.data ? response?.data?.data : []);
  };

  /**
   * @method to fetch History of Boat Services
   */
  const fetchBoatServicesHistory = async () => {
    const response = await getServicesHistory(authData._id, { boatId });
    setServiceHistory(response?.data?.data ? response?.data?.data : []);
  };

  /**
   * @method to fetch Boat
   */
  const fetchBoat = async () => {
    const res = await getBoatByIdAction(boatId);
    setBoatState(res?.data?.data);
  };

  return (
    <>
      <Header title={"Boat Details"} />
      <IonContent fullscreen>
        <div className="boat-details-page">
          <div className="main-container">
            {/* detail-section start */}
            <div className="detail-section">
              <IonGrid className="p-0">
                <IonRow>
                  <IonCol size="4">
                    <div className="my-boats-box">
                      <div className="box-inner">
                        <div className="boats-img">
                          <IonImg
                            className="m-auto w-100"
                            src={
                              boatState.photos && boatState.photos[0]
                                ? boatState.photos[0]
                                : boatImg
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </IonCol>
                  <IonCol size="8">
                    <div className="boat-info">
                      <div className="heading">
                        <h4>{boatState.title}</h4>
                        <span>
                          {boatState.engine?.number_of_engines}{" "}
                          {translation("engine")}
                        </span>
                      </div>
                      <div className="boat-info-detail">
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("modal")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("reg_id")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.registration_id}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("vin")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.vin}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("make")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("hull")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>
                              {boatState.year_of_hull
                                ? formatTimestamp(boatState.year_of_hull)
                                : `-`}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </IonCol>
                  <IonCol size="12">
                    <div className="boat-info mb-30">
                      <div className="boat-info-detail">
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_no")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{translation("double")}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_make")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_model")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_hour")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.hours}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_year")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>2003</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("engine_sn")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState.engine?.serial_number}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("equipment_make")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState?.other_equipments[0]?.equip_make}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("equipment_model")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>{boatState?.other_equipments[0]?.equip_model}</p>
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("install")}</p>
                          </div>
                          <div className="item-contnet">
                            {/* <p>{boatState?.other_equipments}</p> */}
                          </div>
                        </div>
                        {/* item */}
                        <div className="info-item">
                          <div className="item-contnet">
                            <p>{translation("sn")}</p>
                          </div>
                          <div className="item-contnet">
                            <p>YU786-7676777</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </IonCol>
                </IonRow>
              </IonGrid>
            </div>
            {/* detail-section end */}

            {/* boat gallery section start */}
            <div className="boat-gallery-section">
              <IonGrid className="p-0">
                <IonRow>
                  {boatState?.photos?.map((photo: any, index: number) => {
                    return (
                      <IonCol size="4" key={index}>
                        <div className="gallery-card">
                          <IonImg src={photo ? photo : boatGalleryImg} />
                          {/* <Link to="/" className="edit-icon"> */}
                          <div
                            className="edit-icon"
                            onClick={() => history.push(`/edit-boat/${boatId}`)}
                          >
                            <IonIcon icon={pencilOutline} />
                          </div>
                          {/* </Link> */}
                        </div>
                      </IonCol>
                    );
                  })}

                  {/* <IonCol size="4">
                    <div className="gallery-card">
                      <IonImg src={boatGalleryImg} />
                      <Link to="/" className="edit-icon">
                        <IonIcon icon={pencilOutline} />
                      </Link>
                    </div>
                  </IonCol> */}
                </IonRow>
              </IonGrid>
            </div>
            {/* boat gallery section end */}
          </div>

          {/* Upcoming Services start */}
          <div className="upcoming-services mb-30">
            <div className="main-container">
              <div className="common-heading">
                <div className="heading">
                  <h2>{translation("upcoming_services")}</h2>
                </div>
              </div>
              <div className="upcoming-services-inner mb-30">
                {/* card start */}
                {upcomingService && upcomingService.length > 0
                  ? upcomingService.map((service: any, Bindex: number) => {
                      return <ServiceCard serviceData={service} key={Bindex} />;
                    })
                  : "No Upcoming Services Found."}

                {/* card end */}
              </div>
              <div>
                <IonButton
                  expand="block"
                  className="theme-button primary-btn"
                  onClick={() => history.push(`/new-services/${boatState._id}`)}
                >
                  {translation("create_service_list")}
                </IonButton>
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}

          {/* Upcoming Services start */}
          <div className="upcoming-services">
            <div className="main-container">
              <div className="common-heading">
                <div className="heading">
                  <h2>{translation("service_history")}</h2>
                </div>
                {/* <div className="btn-inline">
                  <Link className="link-btn dark-link-btn" to="/">
                    View All
                  </Link>
                </div> */}
              </div>
              <div className="upcoming-services-inner">
                {/* card start */}
                {serviceHistory && serviceHistory.length > 0
                  ? serviceHistory.map((service: any, Bindex: number) => {
                      return <ServiceCard serviceData={service} key={Bindex} />;
                    })
                  : "No Service History Found."}
                {/* card end */}
              </div>
            </div>
          </div>
          {/* Upcoming Services end */}
        </div>
      </IonContent>
    </>
  );
};

export default BoatDetails;
