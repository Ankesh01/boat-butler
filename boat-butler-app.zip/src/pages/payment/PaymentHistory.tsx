import {
  IonButton,
  IonCheckbox,
  IonCol,
  IonContent,
  IonFab,
  IonFabButton,
  IonGrid,
  IonIcon,
  IonImg,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonLabel,
  IonProgressBar,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonSlide,
  IonSlides,
  IonSpinner,
  useIonToast,
} from "@ionic/react";
import { useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom";

import {
  addCircleOutline,
  addOutline,
  arrowForwardOutline,
  keyOutline,
  logoApple,
  logoFacebook,
  logoGoogle,
  pencilOutline,
  searchOutline,
} from "ionicons/icons";

import "./Payment.scss";

import Header from "../../components/header/Header";
import {
  downloadFile,
  formatTimestamp,
  newDateWithoutTime,
} from "../../utils/Helper";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import { useTranslation } from "react-i18next";
import { RootStateOrAny, useSelector } from "react-redux";
import { getPaymentHistory } from "../../redux/action-creators/paymentAction";
import { IPaymentHistory } from "../../interfaceModules/IPlan";

const PaymentHistory: React.FC = () => {
  const { t: translation } = useTranslation();
  const history = useHistory();
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [present, dismiss] = useIonToast();
  // const [selectedDate, setSelectedDate] = useState(newDateWithoutTime());
  const [paymentHistory, setpaymentHistory] = useState<IPaymentHistory[]>([]);
  const [showLoader, setShowLoader] = useState(false);
  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });

  useEffect(() => {
    fetchPaymentHistory(true, 0);
  }, []);

  /**
   * @method to fetch payment history
   */
  const fetchPaymentHistory = async (firstLoad: boolean, offset: number) => {
    setShowLoader(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      const response = await getPaymentHistory(offset, authData._id);
      console.log("fetchPaymentHistory", response);
      if (response?.data?.success) {
        setpaymentHistory(
          firstLoad
            ? response?.data?.data
            : (prevState) => [...prevState, ...response?.data?.data]
        );

        setPaginationState((prevState) => ({
          ...prevState,
          prevOffset:
            response?.data?.data?.length > 0 ? offset : offset ? offset - 5 : 0,
          offset:
            response?.data?.data?.length > 0 ? prevState.offset + 5 : offset,
          hasMore: response?.data?.data?.length > 0,
        }));
      } else {
        setPaginationState((prevState) => ({
          ...prevState,
          hasMore: false,
        }));
      }
    } else {
      setPaginationState((prevState) => ({
        ...prevState,
        hasMore: false,
      }));
    }
    setShowLoader(false);
  };
  const handleDownloadClick = async (data: string) => {
    const fileUri = await downloadFile(data);
    present(
      `File Downloaded ${fileUri ? `in ${fileUri?.toString()}` : ""}`,
      3000
    );
  };

  /**
   * @method to load more data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchPaymentHistory(false, paginationState.offset);
      ev.target.complete();
      // if (data.length == 1000) {
      //   setInfiniteDisabled(true);
      // }
    }, 500);
  };
  return (
    <>
      <Header title={"Payment History"} />
      <IonContent fullscreen>
        <div className='payment-page'>
          {/* services-filter start */}
          {/* <div className="services-filter mb-30">
            <div className="filter-body">
              <div className="upcoming-calendar">
                <ThemeCalendar
                  value={selectedDate}
                  onChange={(e: any) => setSelectedDate(new Date(e))}
                />
              </div>
            </div>
          </div> */}
          {/* services-filter end */}
          <div className='payment-history-inner'>
            <div className='main-container'>
              {/* membership-card start */}
              {showLoader ? (
                <IonSpinner />
              ) : paymentHistory.length > 0 ? (
                paymentHistory.map((payment: any, index: number) => (
                  <div className='membership-card'>
                    <div className='card-icon'>
                      <svg
                        xmlns='http://www.w3.org/2000/svg'
                        viewBox='0 0 24 24'
                      >
                        <path
                          id='Union_21'
                          data-name='Union 21'
                          d='M23758.42,12081.857l-1.58-1.582-1.58,1.582a.481.481,0,0,1-.68,0l-1.58-1.582-1.58,1.582a.483.483,0,0,1-.342.141.477.477,0,0,1-.338-.141l-1.58-1.582-1.58,1.582a.481.481,0,0,1-.68,0l-1.92-1.919a.488.488,0,0,1-.141-.341v-14.879h-.48a3.36,3.36,0,0,1,0-6.721h17.281a3.36,3.36,0,0,1,0,6.721h-.48v14.879a.488.488,0,0,1-.141.341v0l-1.922,1.921a.47.47,0,0,1-.338.141A.478.478,0,0,1,23758.42,12081.857Zm-1.24-2.6,1.58,1.582,1.439-1.438v-17.561h-14.4v17.561l1.439,1.438,1.58-1.582a.483.483,0,0,1,.68,0h0l1.58,1.582,1.582-1.582a.483.483,0,0,1,.68,0l1.58,1.582,1.58-1.582a.483.483,0,0,1,.68,0Zm3.98-15.5h.48a2.4,2.4,0,0,0,0-4.8h-17.281a2.4,2.4,0,0,0,0,4.8h.48v-1.919h-.48a.481.481,0,0,1,0-.962h17.281a.481.481,0,0,1,0,.962l-.48,0Zm-12.961,12.479a.48.48,0,1,1,0-.96h6.721a.48.48,0,1,1,0,.96Zm0-1.922a.478.478,0,0,1-.48-.479v-1.92a.481.481,0,0,1,.48-.48h9.6a.483.483,0,0,1,.48.48v1.92a.482.482,0,0,1-.143.339.476.476,0,0,1-.338.14Zm.48-.959h8.641v-.96h-8.641Zm4.32-3.839a.48.48,0,1,1,0-.96h1.92a.48.48,0,1,1,0,.96Zm-4.32-.48v-.089a1.441,1.441,0,0,1-.961-1.352.48.48,0,0,1,.961,0,.48.48,0,1,0,.48-.48,1.44,1.44,0,0,1-.48-2.791v-.088a.48.48,0,0,1,.961,0v.088a1.438,1.438,0,0,1,.959,1.352.479.479,0,1,1-.959,0,.479.479,0,1,0-.48.479,1.44,1.44,0,0,1,.48,2.792v.089a.48.48,0,0,1-.961,0Zm4.32-1.44a.48.48,0,1,1,0-.96h4.8a.48.48,0,1,1,0,.96Zm0-1.92a.479.479,0,1,1,0-.959h4.8a.479.479,0,1,1,0,.959Z'
                          transform='translate(-23741 -12057.998)'
                        />
                      </svg>
                    </div>

                    <div className='detail'>
                      <div className='detail-top'>
                        <div className='heading'>
                          <h3>{payment?.plan_info[0]?.title}</h3>
                        </div>
                        <p className='date'>
                          {/* Jan 19, 2022 09:41:41 */}
                          {payment?.end_date
                            ? formatTimestamp(payment?.end_date)
                            : `-`}
                        </p>
                      </div>
                      <div className='detail-bottom'>
                        <div className='price'>
                          <p>${payment?.amount} USD</p>
                        </div>
                        <div
                          className='download-link'
                          onClick={() =>
                            handleDownloadClick(
                              "https://boat-buttler-media.s3.us-east-2.amazonaws.com/receipt/b3.jpg"
                            )
                          }
                        >
                          {/* <Link to="/"> */}

                          <svg
                            xmlns='http://www.w3.org/2000/svg'
                            width='19.43'
                            height='24'
                            viewBox='0 0 19.43 24'
                          >
                            <path
                              id='Union_22'
                              data-name='Union 22'
                              d='M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z'
                              transform='translate(-23740.998 -12058.001)'
                            />
                          </svg>
                          {/* </Link> */}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p>{translation("no_services_found")}</p>
              )}

              {/* <div className="membership-card">
                <div className="card-icon">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path
                      id="Union_21"
                      data-name="Union 21"
                      d="M23758.42,12081.857l-1.58-1.582-1.58,1.582a.481.481,0,0,1-.68,0l-1.58-1.582-1.58,1.582a.483.483,0,0,1-.342.141.477.477,0,0,1-.338-.141l-1.58-1.582-1.58,1.582a.481.481,0,0,1-.68,0l-1.92-1.919a.488.488,0,0,1-.141-.341v-14.879h-.48a3.36,3.36,0,0,1,0-6.721h17.281a3.36,3.36,0,0,1,0,6.721h-.48v14.879a.488.488,0,0,1-.141.341v0l-1.922,1.921a.47.47,0,0,1-.338.141A.478.478,0,0,1,23758.42,12081.857Zm-1.24-2.6,1.58,1.582,1.439-1.438v-17.561h-14.4v17.561l1.439,1.438,1.58-1.582a.483.483,0,0,1,.68,0h0l1.58,1.582,1.582-1.582a.483.483,0,0,1,.68,0l1.58,1.582,1.58-1.582a.483.483,0,0,1,.68,0Zm3.98-15.5h.48a2.4,2.4,0,0,0,0-4.8h-17.281a2.4,2.4,0,0,0,0,4.8h.48v-1.919h-.48a.481.481,0,0,1,0-.962h17.281a.481.481,0,0,1,0,.962l-.48,0Zm-12.961,12.479a.48.48,0,1,1,0-.96h6.721a.48.48,0,1,1,0,.96Zm0-1.922a.478.478,0,0,1-.48-.479v-1.92a.481.481,0,0,1,.48-.48h9.6a.483.483,0,0,1,.48.48v1.92a.482.482,0,0,1-.143.339.476.476,0,0,1-.338.14Zm.48-.959h8.641v-.96h-8.641Zm4.32-3.839a.48.48,0,1,1,0-.96h1.92a.48.48,0,1,1,0,.96Zm-4.32-.48v-.089a1.441,1.441,0,0,1-.961-1.352.48.48,0,0,1,.961,0,.48.48,0,1,0,.48-.48,1.44,1.44,0,0,1-.48-2.791v-.088a.48.48,0,0,1,.961,0v.088a1.438,1.438,0,0,1,.959,1.352.479.479,0,1,1-.959,0,.479.479,0,1,0-.48.479,1.44,1.44,0,0,1,.48,2.792v.089a.48.48,0,0,1-.961,0Zm4.32-1.44a.48.48,0,1,1,0-.96h4.8a.48.48,0,1,1,0,.96Zm0-1.92a.479.479,0,1,1,0-.959h4.8a.479.479,0,1,1,0,.959Z"
                      transform="translate(-23741 -12057.998)"
                    />
                  </svg>
                </div>

                <div className="detail">
                  <div className="detail-top">
                    <div className="heading">
                      <h3>Membership</h3>
                    </div>
                    <p className="date">Jan 19, 2022 09:41:41</p>
                  </div>
                  <div className="detail-bottom">
                    <div className="price">
                      <p>$8.09 USD</p>
                    </div>
                    <div className="download-link">
                      <Link to="/">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="19.43"
                          height="24"
                          viewBox="0 0 19.43 24"
                        >
                          <path
                            id="Union_22"
                            data-name="Union 22"
                            d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                            transform="translate(-23740.998 -12058.001)"
                          />
                        </svg>
                      </Link>
                    </div>
                  </div>
                </div>
              </div> */}
              {/* membership-card end */}
            </div>
          </div>
        </div>
        <IonInfiniteScroll
          onIonInfinite={loadData}
          threshold='100px'
          disabled={!paginationState.hasMore}
        >
          <IonInfiniteScrollContent
            loadingSpinner='bubbles'
            loadingText='Loading more data...'
          ></IonInfiniteScrollContent>
        </IonInfiniteScroll>
      </IonContent>
    </>
  );
};

export default PaymentHistory;
