import {
  InputChangeEventDetail,
  IonButton,
  IonContent,
  IonIcon,
  IonImg,
  IonInfiniteScroll,
  IonInfiniteScrollContent,
  IonInput,
  IonModal,
  IonSpinner,
} from "@ionic/react";
import { searchOutline } from "ionicons/icons";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

import "./Members.scss";
import userProfileImg from "../../images/user-profile-img.png";

import Header from "../../components/header/Header";
import {
  getCommunityDetails,
  deleteMember,
} from "../../redux/action-creators/communities";
import { ICommunityMembersInterface } from "../../interfaceModules/ICommunityInterface";

const Members: React.FC = () => {
  const [communityMembers, setcommunityMembers] = useState<
    ICommunityMembersInterface[]
  >([]);
  const [disabled, setDisabled] = useState(false);
  const [searchKeyword, setsearchKeyword] = useState("");
  const [spin, setSpin] = useState(false);
  const { t: translation } = useTranslation();
  const [showModal, setShowModal] = useState({ open: false, data: "" });
  const [paginationState, setPaginationState] = useState({
    offset: 0,
    prevOffset: 0,
    hasMore: true,
  });
  const community_id = location.pathname.includes("/members")
    ? location.pathname.split("/")?.[2]
    : "";

  useEffect(() => {
    if (searchKeyword?.length === 0) {
      setcommunityMembers([]);
    }

    fetchCommunity(true, 0);
  }, [searchKeyword]);

  /**
   * @method to fetch Community
   * @param firstLoad
   * @param offset
   */
  const fetchCommunity = async (firstLoad: boolean, offset: number) => {
    setSpin(true);
    if (
      offset !== paginationState.prevOffset ||
      firstLoad ||
      paginationState.hasMore
    ) {
      const result = await getCommunityDetails({
        _id: community_id,
        status: "Accepted",
        offset: offset,
        query: searchKeyword,
      });
      console.log("members page result", result);
      if (result?.data?.success) {
        setcommunityMembers(
          firstLoad
            ? result?.data?.data?.res
            : (prevState) => [...prevState, ...result?.data?.data?.res]
        );

        // setPaginationState((prevState) => ({
        //   ...prevState,
        //   prevOffset: offset,
        //   offset: prevState.offset + 5,
        //   hasMore: true,
        // }));
        setPaginationState((prevState) => ({
          ...prevState,
          prevOffset:
            result?.data?.data?.res.length > 0
              ? offset
              : offset
              ? offset - 5
              : 0,
          offset:
            result?.data?.data?.res.length > 0 ? prevState.offset + 5 : offset,
          hasMore: result?.data?.data?.res.length > 0,
        }));
      } else {
        setPaginationState((prevState) => ({
          ...prevState,
          hasMore: false,
        }));
      }
    } else {
      setPaginationState((prevState) => ({
        ...prevState,
        hasMore: false,
      }));
    }
    setSpin(false);
  };

  /**
   * @method to handle delete the members
   * @param user_id
   */
  const handleDelete = async (user_id: string) => {
    setShowModal((prevState) => ({ ...prevState, open: false }));
    setDisabled(true);
    const response = await deleteMember(user_id, community_id);
    if (response?.data?.success) {
      fetchCommunity(true, 0);
    }
    setDisabled(false);
  };

  /**
   * @method to load more data
   * @param ev
   */
  const loadData = (ev: any) => {
    setTimeout(() => {
      fetchCommunity(false, paginationState.offset);
      ev.target.complete();
    }, 500);
  };

  /**
   * @method to handle search
   * @param e
   */
  const handleSearch = (e: CustomEvent<InputChangeEventDetail>) => {
    e.preventDefault();
    let target = e.target as HTMLSelectElement;
    setTimeout(() => setsearchKeyword(target.value), 500);
  };
  return (
    <>
      <Header title={"Members"} />
      <IonContent fullscreen>
        <div className="members-page">
          <div className="main-container">
            {/* search start */}
            <div className="form-group">
              <div className="right-icon-input">
                <IonInput
                  className="form-control"
                  placeholder="Search"
                  onIonChange={(e) => handleSearch(e)}
                />
                <a>
                  <IonIcon icon={searchOutline} />
                </a>
              </div>
            </div>
            {/*search end */}
            {spin && (
              <span>
                <IonSpinner />
              </span>
            )}
            <div className="members-card-list">
              {communityMembers && communityMembers?.length > 0 ? (
                communityMembers.map(
                  (member: ICommunityMembersInterface, index: number) => {
                    return (
                      <div className="members-card">
                        {member.community_user_details.image &&
                        member.community_user_details.image.length > 0 ? (
                          <div className="card-img">
                            <IonImg
                              src={member?.community_user_details?.image}
                            />
                          </div>
                        ) : (
                          <div className="card-img">
                            <IonImg src={userProfileImg} />
                          </div>
                        )}
                        <div className="card-info">
                          <div className="name">
                            <h2>{member?.community_user_details?.name}</h2>
                          </div>
                        </div>
                        <div className="action-btn">
                          <IonButton
                            type="button"
                            className="theme-button white-btn"
                            onClick={() =>
                              setShowModal({
                                open: true,
                                data: member?.community_user_details?._id,
                              })
                            }
                          >
                            {translation("remove")}
                          </IonButton>
                        </div>
                        {/* Theme modal */}
                      </div>
                    );
                  }
                )
              ) : (
                <>{spin ? "" : "No Members"}</>
              )}
            </div>
            <IonInfiniteScroll
              onIonInfinite={loadData}
              threshold="100px"
              disabled={!paginationState.hasMore}
            >
              <IonInfiniteScrollContent
                loadingSpinner="bubbles"
                loadingText="Loading more data..."
              ></IonInfiniteScrollContent>
            </IonInfiniteScroll>
          </div>
          <IonModal
            className="theme-modal delete-account-modal"
            isOpen={showModal.open}
            breakpoints={[0.1, 0.5, 1]}
            initialBreakpoint={0.9}
          >
            <div className="modal-inner">
              <div className="modal-header text-center">
                <div className="modal-heading">
                  <h3>
                    {translation("are_you_sure_you_want_to_remove_this_member")}
                  </h3>
                </div>
              </div>
              <div className="modal-body">
                <div className="d-flex justify-content-center">
                  <IonButton
                    onClick={() => {
                      handleDelete(showModal.data);
                    }}
                    className="theme-button primary-btn"
                  >
                    {translation("yes")}
                  </IonButton>
                  <IonButton
                    onClick={() => setShowModal({ open: false, data: "" })}
                    className="theme-button primary-outline-btn"
                  >
                    {translation("no")}
                  </IonButton>
                </div>
              </div>
            </div>
          </IonModal>
        </div>
      </IonContent>
    </>
  );
};

export default Members;
