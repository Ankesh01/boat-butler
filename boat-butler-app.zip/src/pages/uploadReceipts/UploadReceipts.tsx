import {
  IonButton,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonLabel,
  IonProgressBar,
  IonRow,
  IonSelect,
  IonSelectOption,
} from "@ionic/react";
import { useTranslation } from "react-i18next";

import {
  cameraOutline,
  checkmarkCircleOutline,
  closeCircleOutline,
  imageOutline,
} from "ionicons/icons";
import "./Receipts.scss";
import boatImg from "../../images/boat.png";

import Header from "../../components/header/Header";

const UploadReceipts: React.FC = () => {
  const { t: translation } = useTranslation();

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="receipts-page">
          <div className="main-container">
            {/* my-boats-box start */}
            <div className="my-boats-box mb-15">
              <div className="box-inner">
                <IonGrid className="p-0">
                  <IonRow>
                    <IonCol size="4">
                      <div className="boats-img">
                        <IonImg className="w-100 pr-10" src={boatImg} />
                      </div>
                    </IonCol>
                    <IonCol size="8">
                      <div className="boat-info">
                        <div className="heading">
                          <h4>{translation("centurion")}</h4>
                          <span>{translation("single_engine")}</span>
                        </div>
                        <div className="boat-info-detail">
                          {/* item */}
                          <div className="info-item">
                            <div className="item-contnet">
                              <p>{translation("service_date")}</p>
                            </div>
                            <div className="item-contnet">
                              <p>JAN 15, 2021</p>
                            </div>
                          </div>
                        </div>
                        <div className="brif">
                          <p>
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry’s standard dummy text ever since the 1500s,
                            when an unknown.
                          </p>
                        </div>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            </div>
            {/* my-boats-box start */}

            <div className="form-group input-label">
              <IonLabel>{translation("select_service")}</IonLabel>
              <IonSelect
                className="form-control"
                interface="popover"
                placeholder="— Select —"
              >
                <IonSelectOption value="Loream Ipusme">
                  Loream Ipusme
                </IonSelectOption>
                <IonSelectOption value="Loream Ipusme">
                  Loream Ipusme
                </IonSelectOption>
              </IonSelect>
            </div>

            <div className="form-group mb-30">
              <div className="file-upload-card">
                <div className="card-inner">
                  <IonIcon icon={cameraOutline} />
                  <p>
                    Tap to upload from the camera and browse from the photo
                    gallery.
                  </p>
                </div>
                <input className="file-input" type="file"></input>
              </div>
            </div>

            <div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn danger-icon-btn">
                      <IonIcon icon={closeCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
              {/* upload-status */}
              <div className="upload-status">
                <div className="status-top">
                  <div className="file-detail">
                    <div className="icon">
                      <IonIcon icon={imageOutline} />
                    </div>
                    <div className="name">
                      <h3>DICM_0959.jpg</h3>
                      <span>431 KB</span>
                    </div>
                  </div>
                  <div className="action-btn">
                    <IonButton className="icon-btn success-icon-btn">
                      <IonIcon icon={checkmarkCircleOutline} />
                    </IonButton>
                  </div>
                </div>
                <div className="status-mid">
                  <IonProgressBar value={0.5}></IonProgressBar>
                </div>
              </div>
            </div>

            <IonButton expand="block" className="theme-button primary-btn">
              {translation("save")}
            </IonButton>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default UploadReceipts;
