import {
  IonAccordion,
  IonAccordionGroup,
  IonButton,
  IonCheckbox,
  IonCol,
  IonContent,
  IonGrid,
  IonIcon,
  IonImg,
  IonItem,
  IonLabel,
  IonList,
  IonRow,
  IonSlide,
  IonSlides,
  IonSpinner,
  useIonToast,
} from "@ionic/react";
import React, { useEffect, useState } from "react";
import { RootStateOrAny, useSelector } from "react-redux";

import {
  addCircleOutline,
  closeCircleOutline,
  downloadOutline,
} from "ionicons/icons";
import "./Receipts.scss";

import Header from "../../components/header/Header";
import ThemeCalendar from "../../components/themeCalendar/ThemeCalendar";
import {
  getServicesHistory,
  updateBoatService,
} from "../../redux/action-creators/boatServices";
import { IServiceInterface } from "../../interfaceModules/IServiceInterface";
import { downloadFile, uploadFileOnS3 } from "../../utils/Helper";
import { deleteFile } from "../../redux/action-creators/FileUpload";

const myBoatsSlideOpts = {
  initialSlide: 1,
  slidesPerView: 2,
  speed: 400,
  spaceBetween: 10,
};

const Receipts: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const authData = useSelector(
    (state: RootStateOrAny) => state.authReducer.user
  );
  const [serviceList, setServiceList] = useState<IServiceInterface[]>([]);
  const [selectedService, setSelectedService] = useState<
    IServiceInterface | any
  >({});
  const [loading, setLoading] = useState(false);
  const [updateService, setUpdateService] = useState(false);
  const [present, dismiss] = useIonToast();

  useEffect(() => {
    let date = new Date();
    date.setHours(0);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    setSelectedDate(date);
  }, []);

  useEffect(() => {
    if (selectedDate) {
      fetchServiceHistory();
    }
  }, [selectedDate]);

  useEffect(() => {
    if (updateService) {
      handleSave();
      setUpdateService(false);
    }
  }, [updateService]);

  const fetchServiceHistory = async () => {
    setLoading(true);
    const response = await getServicesHistory(authData._id, {
      date: selectedDate as Date,
    });
    if (response?.data?.data) {
      const services = response?.data?.data;
      services.forEach((service: any) => {
        service.receipts = service.receipts.map((i: string) => ({
          data: i,
          format: "",
        }));
      });
      setServiceList(services);
      setSelectedService(services.length > 0 ? services[0] : {});
    }
    setLoading(false);
  };

  const handleUpload = async (event: any) => {
    const { files } = event.target;

    const fileUrlList = await uploadFileOnS3(files, "receipt");

    let state = { ...selectedService } as any;

    state.receipts = [
      ...state.receipts,
      ...fileUrlList.map((i: string) => ({ data: i, format: "" })),
    ];

    setSelectedService({ ...state });

    setUpdateService(true);
  };

  const handleBoatCheck = (event: any, service: IServiceInterface) => {
    const { checked } = event.detail;
    if (!checked) {
      return null;
    }
    if (service._id === selectedService._id) {
      return null;
    }
    setSelectedService(service);
  };

  const handleRemoveImage = (index: number) => {
    let state = { ...selectedService } as any;
    const file = [...state.receipts][index];
    state.receipts.splice(index, 1);
    setSelectedService({ ...state });
    setUpdateService(true);
    deleteFile([file]);
  };

  const handleSave = async () => {
    dismiss();
    const res = await updateBoatService(selectedService._id, selectedService);
    if (res?.data?.success) {
      present("Receipt Updated Successfully!", 3000);
    }
  };

  const handleDownloadClick = async (data: string) => {
    const fileUri = await downloadFile(data);
    present(
      `File Downloaded ${fileUri ? `in ${fileUri?.toString()}` : ""}`,
      3000
    );
  };

  return (
    <>
      <Header title={"Receipts"} />
      <IonContent fullscreen>
        <div className="receipts-page">
          <div className="main-container">
            <div className="receipts-calendar">
              <ThemeCalendar
                value={selectedDate}
                onChange={(e: Date) => setSelectedDate(e)}
              />
            </div>

            <div>
              {loading ? (
                <IonSpinner />
              ) : serviceList.length > 0 ? (
                <IonSlides pager={false} options={myBoatsSlideOpts}>
                  {serviceList.map((service, index) => (
                    <IonSlide key={index}>
                      <div className="my-boats-box">
                        <div className="box-inner">
                          <div className="box-top">
                            <div className="heading">
                              <h2>{service["boatInfo"][0]["title"]}</h2>
                              <p>
                                {
                                  service?.boatInfo[0]?.["engine"]
                                    .number_of_engines
                                }{" "}
                                Engine
                              </p>
                            </div>
                            <div className="btn-inline">
                              <div className="form-group">
                                <IonCheckbox
                                  checked={
                                    service?._id === selectedService?._id
                                  }
                                  onIonChange={(e) =>
                                    handleBoatCheck(e, service)
                                  }
                                />
                              </div>
                            </div>
                          </div>
                          <div className="boats-img">
                            <IonImg src={service["boatInfo"][0]["photos"][0]} />
                          </div>
                        </div>
                      </div>
                    </IonSlide>
                  ))}
                </IonSlides>
              ) : (
                <p>No Service Found!</p>
              )}
            </div>

            {!loading && !!selectedService?._id && (
              <div className="boat-gallery-section">
                <IonGrid className="p-0">
                  <IonRow>
                    {selectedService?.receipts &&
                      selectedService?.receipts?.length > 0 &&
                      selectedService?.receipts.map((i: any, index: number) => (
                        <div key={index}>
                          <div className="file-card">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="19.43"
                              height="24"
                              viewBox="0 0 19.43 24"
                            >
                              <path
                                id="Union_22"
                                data-name="Union 22"
                                d="M23743.855,12082a2.858,2.858,0,0,1-2.857-2.858v-18.285a2.857,2.857,0,0,1,2.857-2.856h7.156a2.868,2.868,0,0,1,1.859.687l6.559,5.624a2.85,2.85,0,0,1,1,2.17v12.661a2.858,2.858,0,0,1-2.857,2.858Zm-1.715-21.144v18.285a1.715,1.715,0,0,0,1.715,1.714h13.715a1.715,1.715,0,0,0,1.715-1.714v-12.661a1.715,1.715,0,0,0-.07-.479h-5.074a2.857,2.857,0,0,1-2.855-2.859v-3.977a1.6,1.6,0,0,0-.273-.022h-7.156A1.715,1.715,0,0,0,23742.141,12060.857Zm10.287,2.285a1.714,1.714,0,0,0,1.713,1.715h4.17l-5.883-5.043Zm-6.287,15.43v-1.143h9.145v1.143Zm4.168-3.6-3.428-3.428.807-.81,2.455,2.454v-5.477h1.143v5.475l2.453-2.452.807.81-3.428,3.428a.573.573,0,0,1-.809,0Z"
                                transform="translate(-23740.998 -12058.001)"
                              />
                            </svg>

                            <div className="action-btn">
                              <IonButton
                                type="button"
                                className="icon-btn primary-icon-btn "
                                onClick={() => handleDownloadClick(i.data)}
                              >
                                <IonIcon icon={downloadOutline} />
                              </IonButton>
                              <IonButton
                                type="button"
                                className="icon-btn primary-icon-btn "
                                onClick={() => handleRemoveImage(index)}
                              >
                                <IonIcon icon={closeCircleOutline} />
                              </IonButton>
                            </div>
                          </div>
                        </div>
                      ))}
                    <IonCol size="4">
                      <div className="form-group mb-0">
                        <div className="imagee-upload-card">
                          <IonIcon icon={addCircleOutline} />

                          <input
                            className="file-input"
                            type="file"
                            onChange={handleUpload}
                          />
                        </div>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </div>
            )}

            <div className="theme-accordion">
              <div className="accordion-brif">
                <p>Lorem Ipsum is simply dummy text of the printing.</p>
              </div>

              {!!selectedService?._id && (
                <IonAccordionGroup>
                  {selectedService.items?.map((item: any, index: number) => (
                    <IonAccordion
                      value={item.name}
                      toggleIcon={addCircleOutline}
                    >
                      <IonItem slot="header">
                        <IonLabel>{item.name}</IonLabel>
                      </IonItem>
                      <IonList slot="content">
                        <IonItem>
                          <p>{item.status}</p>
                        </IonItem>
                      </IonList>
                    </IonAccordion>
                  ))}
                </IonAccordionGroup>
              )}
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default Receipts;
