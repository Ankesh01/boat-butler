import {
  InputChangeEventDetail,
  IonAccordion,
  IonAccordionGroup,
  IonContent,
  IonIcon,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
} from "@ionic/react";
import { Link } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

import { addCircleOutline, searchOutline } from "ionicons/icons";
import "./HelpAndSupport.scss";
import supportImg from "../../images/help-support-img.svg";

import Header from "../../components/header/Header";
import { getAllQuestionnaireAction } from "../../redux/action-creators/pages";
import { IPagesInterface } from "../../interfaceModules/IPagesInterface";

const HelpAndSupport: React.FC = () => {
  const { t: translation } = useTranslation();
  const [questionnairesState, setQuestionnairesState] = useState<
    IPagesInterface[]
  >([]);
  const [filterQuestionState, setFilteredQuestionState] = useState<
    IPagesInterface[]
  >([]);
  const [searchKeyword, setSearchKeyword] = useState("");

  useEffect(() => {
    fetchQuestionnaires();
  }, []);

  /**
   * @method to fetch Questionnaires
   */
  const fetchQuestionnaires = async () => {
    const response = await getAllQuestionnaireAction();
    if (response?.data?.data) {
      setQuestionnairesState(
        response?.data?.data?.map((question: IPagesInterface) => ({
          ...question,
          open: false,
        }))
      );
    }
  };

  /**
   * @method to toggle Questionnaires
   * @param index
   */
  const toggleQuestionnaire = async (index: number) => {
    const questions = [...questionnairesState];
    questions[index]["open"] = !questions[index]["open"];
    setQuestionnairesState(questions);
  };

  /**
   * @method to handle Filter Questionaries
   * @param event
   * @returns
   */
  const handleChange = (event: CustomEvent<InputChangeEventDetail>) => {
    let { value } = event.detail as HTMLSelectElement;
    setSearchKeyword(value);
    if (value === "" || value.length === 0) {
      setFilteredQuestionState([]);
      return null;
    }
    let questions: IPagesInterface[] = [];
    value = value.toLowerCase();
    questionnairesState.forEach((question) => {
      if (question.title.toLowerCase().includes(value)) {
        questions.push(question);
      } else if (question.content.toLowerCase().includes(value)) {
        questions.push(question);
      }
    });
    setFilteredQuestionState(questions);
  };

  return (
    <>
      <Header />
      <IonContent fullscreen>
        <div className="help-and-support-page">
          {/* support-banner start */}
          <div className="support-banner">
            <div className="main-container">
              <div className="support-banner-inner">
                <div className="banner-img">
                  <IonImg src={supportImg} />
                </div>
                <div className="banner-content">
                  <h2>
                    {translation("help")} &<br></br> {translation("support")}
                  </h2>
                </div>
              </div>
            </div>
          </div>
          {/* support-banner end */}

          <div className="main-container">
            <div className="support-search-section">
              <div className="heading">
                <h4>{translation("we_are_here_for_help")}</h4>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p>
              </div>
              <div className="search-inner">
                <div className="form-group">
                  <div className="right-icon-input">
                    <IonInput
                      className="form-control"
                      placeholder="Search Boat"
                      value={searchKeyword}
                      onIonChange={(e) => handleChange(e)}
                    />
                    <Link to="/">
                      <IonIcon icon={searchOutline} />
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            <div className="theme-accordion">
              <IonAccordionGroup>
                {filterQuestionState.length > 0
                  ? filterQuestionState.map((questionnaire, index) => (
                      <IonAccordion
                        value={questionnaire?.slug}
                        toggleIcon={addCircleOutline}
                        key={index}
                        onClick={() => toggleQuestionnaire(index)}
                      >
                        <IonItem slot="header">
                          <IonLabel>{questionnaire.title}</IonLabel>
                        </IonItem>
                        <IonList slot="content">
                          <IonItem>
                            <p
                              dangerouslySetInnerHTML={{
                                __html: questionnaire.content,
                              }}
                            ></p>
                          </IonItem>
                        </IonList>
                      </IonAccordion>
                    ))
                  : questionnairesState.map((questionnaire, index) => (
                      <IonAccordion
                        // value={questionnaire?.slug}
                        toggleIcon={addCircleOutline}
                        key={index}
                        onClick={() => toggleQuestionnaire(index)}
                      >
                        <IonItem slot="header">
                          <IonLabel>{questionnaire.title}</IonLabel>
                        </IonItem>
                        <IonList slot="content">
                          <IonItem>
                            <p
                              dangerouslySetInnerHTML={{
                                __html: questionnaire.content,
                              }}
                            ></p>
                          </IonItem>
                        </IonList>
                      </IonAccordion>
                    ))}
              </IonAccordionGroup>
            </div>
          </div>
        </div>
      </IonContent>
    </>
  );
};

export default HelpAndSupport;
