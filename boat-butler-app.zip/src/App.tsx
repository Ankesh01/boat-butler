import {
    IonApp,
    IonRouterOutlet,
    IonSplitPane,
    setupIonicReact, useIonAlert,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import { Redirect, Route } from "react-router-dom";
import Menu from "./components/Menu";

/* Core CSS required for Ionic components to work properly */
import "@ionic/react/css/core.css";

/* Basic CSS for apps built with Ionic */
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";

/* Optional CSS utils that can be commented out */
import "@ionic/react/css/padding.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/display.css";

/* Theme variables */
import "./theme/variables.scss";
import "./theme/App.scss";
import PublicRoutes from "./routes/PublicRoutes";
import {
  ActionPerformed,
  PushNotificationSchema,
  PushNotifications,
  Token,
} from '@capacitor/push-notifications';
import {RootStateOrAny, useSelector} from "react-redux";
import {useEffect} from "react";
import { updateUserTimezoneAction} from "./redux/action-creators";

setupIonicReact();



const App: React.FC = () => {
    const [present] = useIonAlert();
    const authData = useSelector((state: RootStateOrAny) => state.authReducer.user);

    // update user's timezone on app loads
    useEffect(()=>{
        if(authData?.id){
            const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            updateUserTimezoneAction(authData.id, timezone)
        }
    }, [authData])

    // Request permission to use push notifications
// iOS will prompt user and return if they granted permission or not
// Android will just grant without prompting
    PushNotifications.requestPermissions().then(result => {
        if (result.receive === 'granted') {
            // Register with Apple / Google to receive push via APNS/FCM
            PushNotifications.register();
        } else {
            // Show some error
        }
    });

// On success, we should be able to receive notifications
    PushNotifications.addListener('registration',
        (token: Token) => {
            console.log('Push registration success, token: ' + token.value);
            localStorage.setItem("fcm_token", token.value)
        }
    );

// Some issue with our setup and push will not work
    PushNotifications.addListener('registrationError',
        (error: any) => {
            console.log('Error on registration: ' + JSON.stringify(error));
        }
    );

// Show us the notification payload if the app is open on our device
    PushNotifications.addListener('pushNotificationReceived',
        (notification: PushNotificationSchema) => {
            console.log('Push received: ' + JSON.stringify(notification));
            present({
                // cssClass: 'my-css',
                header: 'Reminder Notification!',
                message: `${notification.title} : ${notification.body}`,
                buttons: [
                    'ok'
                ],
            })
        }
    );

// Method called when tapping on a notification
    PushNotifications.addListener('pushNotificationActionPerformed',
        (notification: ActionPerformed) => {
            console.log('Push action performed: ' + JSON.stringify(notification));
        }
    );

  return (
    <IonApp>
      <IonReactRouter>
        <IonSplitPane contentId="main">
          <Menu />
          <IonRouterOutlet id="main">
            <Route path="/" component={PublicRoutes} />
          </IonRouterOutlet>
        </IonSplitPane>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;
