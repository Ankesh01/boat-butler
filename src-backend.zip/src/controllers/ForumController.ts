import { Request, Response } from "express";

import { ResponseObject } from "../Interfaces/commonInterfaces";
import ForumService from "../services/ForumService";
/**
 * Create Boat
 * @param req
 * @param res
 */

export const getAllForum = async (req: Request, res: Response) => {
  const response: ResponseObject = await ForumService.getAllForum();
  res.status(200).send(response);
};
