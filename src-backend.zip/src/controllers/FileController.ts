import { Request, response, Response } from "express";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { deleteFileFromS3, getPresignedUrlFromS3 } from "../utils/fileUpload";

/**
 * Create job post
 * @param req
 * @param res
 */
export const getPresignedUrl = async (
  req: Request & { id?: string },
  res: Response
) => {
  console.log("presignedurl", req.body);
  const files: { filePath: string; fileFormat: string }[] = req.body.files;
  let signedUrlList = [];
  for (let file of files) {
    signedUrlList.push(
      await getPresignedUrlFromS3(file.filePath, file.fileFormat)
    );
  }
  const response: ResponseObject = {
    success: true,
    message: "success",
    data: signedUrlList,
  };
  res.status(200).send(response);
};

export const deleteFiles = async (req: Request, res: Response) => {
  const urlList = req.body;
  for (let url of urlList as string[]) {
    const response = await deleteFileFromS3(url);
    console.log("deleteFile response ", response);
  }
  const response: ResponseObject = {
    success: true,
    message: "success",
  };
  res.status(200).send(response);
};
