import { Request, Response } from "express";

import { ResponseObject } from "../Interfaces/commonInterfaces";
import PageServices from "../services/PageService";
/**
 * Create Boat
 * @param req
 * @param res
 */

export const getAllQuestionnaire = async (req: Request, res: Response) => {
  const slug: any = req?.query.slug;
  const response: ResponseObject = await PageServices.getAllQuestionnaire(slug);
  res.status(200).send(response);
};
