import { Request, Response } from "express";

import BusinessesServices from "../services/BusinessesServices";
import { Businesses } from "../models/businesses";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";

export const getServiceProvidersList = async (req: Request, res: Response) => {
  console.log("req.body", req.body);
  const response = await BusinessesServices.getServiceProvidersList(req.body);
  res.status(200).send(response);
};

export const getServiceProviderById = async (req: Request, res: Response) => {
  // console.log("serviceID--->", req.params);
  const service_id = req?.params?.id;

  const response = await BusinessesServices.getServiceProviderById(service_id);
  res.status(200).send(response);
};

export const createBusiness = async (req: Request, res: Response) => {
  console.log("req.body", req.body);
  const response = await BusinessesServices.create(req.body);

  res.status(200).send(response);
};
export const getGooglePlaceDetail = async (req: Request, res: Response) => {
  const placeId = req?.params?.placeId;
  // req.get(url, (req, res) => {});
  const response: ResponseObject =
    await BusinessesServices.getGooglePlaceDetail(placeId);
  res.status(200).send(response);
};

export const editBusiness = async (req: Request, res: Response) => {
  console.log("updateServiceProvider", req.body);
  console.log("params", req.params.businessId);
  const response = await BusinessesServices.update(
    req.body,
    req.params.businessId
  );
  res.status(200).send(response);
};
