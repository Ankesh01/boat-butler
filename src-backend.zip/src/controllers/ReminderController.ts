import { Request, Response } from "express";
import ReminderServices from "../services/ReminderServices";
import {ResponseObject} from "../Interfaces/commonInterfaces";
import {sendNotification} from "../utils/fcmNotification";

/**
 * Create Boat
 * @param req
 * @param res
 */

export const create = async (req: Request, res: Response) => {
  const response = await ReminderServices.create(req.body);
  res.status(200).send(response);
};

export const getReminderbyUserId = async (req: Request, res: Response) => {
  const user_id = req?.params?.user_id;
  const response = await ReminderServices.getReminderServicesbyUserId(user_id);
  res.status(200).send(response);
};

export const deleteReminder = async (req: Request, res: Response) => {
  const _id = req?.params._id.split(",");
  const response = await ReminderServices.deleteReminderById(_id);
  res.status(200).send(response);
};

export const updateRemindersNotification = async (
  req: Request,
  res: Response
) => {
  const response = await ReminderServices.updateRemindersNotification(req.body);
  res.status(200).send(response);
};

export const sendTestNotification = async (req : Request, res : Response) => {
  const token = req.body.token
  console.log("token ", token)
  let response: ResponseObject;
  const result = await sendNotification([token], "Test Notification", "this notification is for testing purpose")
  response = {
    success : true,
    message : "ok",
    data : result
  }
  res.status(200).send(response);
}
