import { Request, Response } from "express";

import CommunityAdminServices from "../../services/adminservices/CommunityAdminServices";


import { ResponseObject} from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const getcommunitylist = async (req: Request, res: Response) => {
  const response: ResponseObject = await CommunityAdminServices.getcommunitylist(req.query);
  console.log("req.body", response)
  res.status(200).send(response);
};

export const searchcommunitylist = async (req: Request, res: Response) => {
  // console.log("hjhjh", req.query)
  const response = await CommunityAdminServices.searchcommunitylist(req.query);
  res.status(200).send(response);
};

export const getcommunitydetail = async (req: Request, res: Response) => {
  console.log("hjhjh", req.params)
  const response = await CommunityAdminServices.getcommunitydetail(req.params);
  res.status(200).send(response);
};

