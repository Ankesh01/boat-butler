import { Request, Response } from "express";
import BusinessesServices from "../../services/adminservices/BusinessDirectoryAdminService";

export const getServiceProvidersList = async (req: Request, res: Response) => {
  let query = req.query.searchKeyword as string;

  const response = await BusinessesServices.getServiceProvidersList(query);
  res.status(200).send(response);
};

export const getGooglePlaceDetail = async (req: Request, res: Response) => {
  const placeId = req?.params?.placeId;
  // req.get(url, (req, res) => {});
  const response = await BusinessesServices.getGooglePlaceDetail(placeId);
  res.status(200).send(response);
};
