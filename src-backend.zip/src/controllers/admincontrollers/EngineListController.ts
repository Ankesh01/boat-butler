import { Request, Response } from "express";

import EngineAdminServices from "../../services/adminservices/EngineAdminServices";


import { ResponseObject} from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const getenginelist = async (req: Request, res: Response) => {
  const response: ResponseObject = await EngineAdminServices.getenginelist(req.query);
  console.log("req.body", response)
  res.status(200).send(response);
};

export const searchenginelist = async (req: Request, res: Response) => {
  // console.log("hjhjh", req.query)
  const response = await EngineAdminServices.searchenginelist(req.query);
  res.status(200).send(response);
};

export const createEngines = async (req: Request, res: Response) => {
    console.log("req.body", req.body);
    const response = await EngineAdminServices.create(req.body);
  
    res.status(200).send(response);
  };

  export const getEngineById = async (req: Request, res: Response) => {
    // console.log("serviceID--->", req.params);
    const engine_id = req?.params?.id;
  
    const response = await EngineAdminServices.getEngineById(engine_id);
    res.status(200).send(response);
  };

  
export const editEngine = async (req: Request, res: Response) => {

  const response = await EngineAdminServices.editEngine(
    req.body,
    req.params.engineId
  );
  res.status(200).send(response);
};
