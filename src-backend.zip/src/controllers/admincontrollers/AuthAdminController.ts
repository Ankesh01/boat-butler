import { Request, Response } from "express";

import AuthServices from "../../services/adminservices/AuthAdminServices";


import { ResponseObject, DataFromHeader } from "../../Interfaces/commonInterfaces";

/**
 * Login
 */
export const login = async (req: Request, res: Response) => {
  const response: ResponseObject = await AuthServices.login(req.body);
  console.log("req.body", req.body)

  res.status(response.success? 200: 202).send(response);
};

export const forgotPassword = async (req: Request, res: Response) => {
  const response: ResponseObject = await AuthServices.forgotPassword(req.body);
  console.log("req.body", req.body)

  res.status(200).send(response);
};

export const resetPassword = async (req: Request, res: Response) => {
  const response = await AuthServices.resetPassword(req.body);
  console.log("req.body", req.body)

  res.status(200).send(response);
};


