import { Request, Response } from "express";
import BoatServicesServices from "../services/BoatServicesServices";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";

export const create = async (req: Request, res: Response) => {
    const response: ResponseObject = await BoatServicesServices.create(req.body);
    res.status(200).send(response);
}
export const update = async (req: Request, res: Response) => {
    const serviceId = req.params.serviceId
    const response: ResponseObject = await BoatServicesServices.update(serviceId, req.body);
    res.status(200).send(response);
}

export const getServiceById = async (req: Request, res: Response) => {
    const serviceId = req.params.serviceId
    const response: ResponseObject = await BoatServicesServices.getServiceById(serviceId);
    res.status(200).send(response);
}

export const getServiceHistory = async (req: Request, res: Response) => {
    const userId = req.params.userId
    const response: ResponseObject = await BoatServicesServices.getServiceHistory(userId, req.query);
    res.status(200).send(response);
}
export const getBoatServicesByUserId = async (req : Request, res : Response) => {
    const userId = req.params.userId;
    const response: ResponseObject = await BoatServicesServices.getBoatServicesByUserId(userId, req.query);
    res.status(200).send(response);
}