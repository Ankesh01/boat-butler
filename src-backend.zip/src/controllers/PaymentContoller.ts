import { Request, Response } from "express";

import PaymentServices from "../services/PaymentServices";


import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";


/**
 * Create Boat 
 * @param req
 * @param res
 */
 
export const create = async (req: Request, res: Response) => {
  const response: ResponseObject = await PaymentServices.create(req.body);

  res.status(200).send(response);
};