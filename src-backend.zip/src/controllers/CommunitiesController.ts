import { Request, Response } from "express";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import CommunitiesServices from "../services/CommunitiesServices";
/**
 * Create Community
 * @param req
 * @param res
 */

export const create = async (req: Request, res: Response) => {
  const response = await CommunitiesServices.create(req.body);

  res.status(200).send(response);
};

/**
 * Get Community by @id
 * @param req
 * @param res
 */

export const getCommunityById = async (req: Request, res: Response) => {
  const _id = req?.params?.id;
  const response = await CommunitiesServices.getCommunityById(_id);

  res.status(200).send(response);
};

export const getCommunityPosts = async (req: Request, res: Response) => {
  const _id = req?.params?.id;
  const response = await CommunitiesServices.getCommunityPosts(_id);

  res.status(200).send(response);
};
