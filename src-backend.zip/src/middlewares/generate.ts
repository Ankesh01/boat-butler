import jwt from "jsonwebtoken";

import config from "./../config/envConfig";
import { UserSchema } from "../Interfaces/schemaInterfaces";
import { envData } from "../Interfaces/commonInterfaces";
const envConfig: envData = config();

const createToken = (user: UserSchema): string => {
  const expiresIn = "7d";
  console.log("Inside token ");
  return jwt.sign({ ...user }, envConfig.jwtSecret, { expiresIn  });
};

export default createToken;
