import { NextFunction, Response, Request } from "express";
import * as jwt from "jsonwebtoken";

import config from "./../config/envConfig";
import { envData } from "../Interfaces/commonInterfaces";

const Auth = (request: Request, response: Response, next: NextFunction) => {
  const envConfig: envData = config();
  let token =
    <string>request.headers["auth"] || <string>request.headers["authorization"];

  token = token.split(" ")[1];
  try {
    if (token) {
      console.log("envConfig.jwtSecret ", envConfig.jwtSecret, token)
      const verify = jwt.verify(token, envConfig.jwtSecret);
      if (verify) {
        request["user_id"] = verify._id;
        request["token"] = token;
        next();
      }
    }
  } catch (error) {
    console.log("Error in verifying auth ", error);
    response.status(401).send({
      message: "YOUR SESSION HAS EXPIRED. PLEASE LOGIN AGAIN.",
      success: false,
      error: "token-expired",
    });
  }
};

export default Auth;
