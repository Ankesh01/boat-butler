import { ResponseObject } from "../Interfaces/commonInterfaces";
import { BoatSchema } from "../Interfaces/schemaInterfaces";
import { BoatService } from "../models/boatServices";
import { uploadImage } from "../utils/fileUpload";
import { ObjectId } from "mongodb";
import moment from "moment";

interface createService {
    user_id: string;
    serviceDate: Date;
    selectedBoat: BoatSchema;
    items: string[]
}
interface updateService {
    receipts: { data: string, format: string }[];
    items: { name: string; status: string }[],
    serviceStatus: string;
}


class BoatServicesServices {
    private response: ResponseObject;

    async create(body: createService) {
        console.log("createService function called")
        const dueDate = moment(body.serviceDate).format("YYYY-MM-DD")
        const result = await BoatService.create({
            user_id: body.user_id,
            items: body.items.map((item) => ({ name: item, status: "Pending" })),
            due_date: new Date(dueDate),
            status: "Pending",
            boat_id: body.selectedBoat._id
        })
        this.response = {
            success: true,
            data: result,
            message: "Service Added Successfully!",
        };
        return this.response
    }

    async update(serviceId: string, body: updateService) {

        let receiptList = [];
        for (let receipt of body.receipts) {
            if (receipt.data.includes("base64")) {
                const recp = await uploadImage(receipt.data, "boat-buttler-media", `service/${Date.now()}`, receipt.format)
                receiptList.push(recp)
            } else {
                receiptList.push(receipt.data)
            }
        }
        const result = await BoatService.updateOne({
            _id: new ObjectId(serviceId)
        }, {
            items: body.items,
            receipts: receiptList,
            status: body.serviceStatus
        })
        this.response = {
            success: true,
            data: result,
            message: "Service Added Successfully!",
        };
        return this.response

    }

    async getServiceById(serviceId: string) {
        console.log("find service ", { _id: new ObjectId(serviceId) })
        // const result = await BoatService.findOne({_id : new ObjectId(serviceId)})
        const result = await BoatService.aggregate([
            {
                $match: { _id: new ObjectId(serviceId) },
            },
            {
                $lookup: {
                    from: "boats",
                    localField: "boat_id",
                    foreignField: "_id",
                    as: "boatInfo",
                },
            }
        ])
        this.response = {
            success: true,
            data: result,
            message: "Service Found Successfully!",
        };
        return this.response
    }

    async getServiceHistory(userId: string, queryObject: any) {
        const matchObject = {
            user_id: new ObjectId(userId),
            status: "Completed"
        }
        if (queryObject.boatId) {
            matchObject["boat_id"] = new ObjectId(queryObject.boatId)
        }
        if (queryObject.date) {
            matchObject["due_date"] = new Date(queryObject.date)
        }
        console.log("Get service history query : ", matchObject)
        const boatServices = await BoatService.aggregate([
            {
                $match: matchObject,
            },
            {
                $lookup: {
                    from: "boats",
                    localField: "boat_id",
                    foreignField: "_id",
                    as: "boatInfo",
                },
            },
            {
                $sort: {
                    'due_date': 1,
                }
            }
        ]);
        this.response = {
            success: true,
            data: boatServices,
            message: "Service Found Successfully!",
        };
        return this.response
    }

    async getBoatServicesByUserId(userId: string, queryObject: any) {
        let boatServices;

        console.log("getBoatServices called ! ", userId, queryObject);
        const currentDate = moment().format("YYYY-MM-DD")
        const matchObject = {
            user_id: new ObjectId(userId),
            status: "Pending"
        };
        if (queryObject.boatId && queryObject.boatId.length > 0) {
            matchObject["boat_id"] = new ObjectId(queryObject.boatId);
        }
        if (queryObject.serviceId && queryObject.serviceId.length > 0) {
            matchObject["_id"] = new ObjectId(queryObject.serviceId);
        }
        if (queryObject.date && queryObject.date.length > 0) {
            const date = moment(queryObject.date).format("YYYY-MM-DD")
            matchObject["due_date"] = new Date(date);
        } else {
            matchObject["due_date"] = { $gte: new Date(currentDate) };
        }


        console.log("matchObject : ", matchObject);

        try {
            boatServices = await BoatService.aggregate([
                {
                    $match: matchObject,
                },
                {
                    $lookup: {
                        from: "boats",
                        localField: "boat_id",
                        foreignField: "_id",
                        as: "boatInfo",
                    },
                },
                {
                    $sort: {
                        'due_date': 1,
                    }
                }
            ]);
        } catch (e) {
            console.log("error ", e)
            this.response = {
                success: false,
                message: "Could_not_find_boatService",
            };
            return this.response;
        }

        this.response = {
            success: true,
            message: "boatServices found",
            data: boatServices,
        };
        return this.response;
    }
}

export default new BoatServicesServices();