import { Pages } from "../../models/pages";
class PageManagementServices {
  private response: any;
  /**
   * @method to create new faq
   * @param body
   * @returns
   */
  async create(body) {
    const result = await Pages.create({
      title: body?.title,
      content: body?.content,
      is_faq: body?.is_faq,
      status: body?.status,
    });

    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "New Faqs Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  /**
   * @method to get all list of faqs
   * @param data
   * @param user_id
   * @returns
   */
  async getfaqslist(data: any, user_id?) {
    const { offset } = data;
    let res;
    let count;

    try {
      res = await Pages.find({ is_faq: 1, user_id: user_id })
        .skip(offset)
        .limit(5)
        .sort({ created_ts: -1 });
     
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_faqs",
      };

      return this.response;
    }
    if (res) {
      count = await Pages.find({ is_faq: 1, user_id: user_id }).count();
      res={res: res, count: count}
      this.response = {
        success: true,
        message: "Faqs_found",
        data: res,
        
      };
    } else {
      this.response = {
        success: false,
        message: "faqs_not_found",
      };
    }

    return this.response;
  }

  /**
   * @method to update faq
   * @param body
   * @param _id
   * @returns
   */
  async updateFaqs(body, _id: string) {
    let result;
    try {
      result = await Pages.updateMany(
        {
          _id: _id,
        },
        { $set: body }
      );
    } catch (err) {
      this.response = {
        success: false,
        message: "updation_failed",
      };
    }

    if (result) {
      this.response = {
        success: true,
        message: "page_updated_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  /**
   * @method to fetch faq by id
   * @param _id
   * @returns
   */
  async getPageProviderById(_id: string) {
    let res;
    try {
      res = await Pages.findOne({ _id: _id });
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_faq",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "faq_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "faq_not_found",
      };
    }

    return this.response;
  }

  /**
   * @method to fetch list of web pages
   * @param data
   * @param user_id
   * @returns
   */
  async getWebPageslist(data, user_id?) {
    const { offset } = data;
    let res;

    try {
      res = await Pages.find({ is_faq: 0, user_id: user_id })
        .skip(offset)
        .limit(5);
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_webpages",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "webpages_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "webpages_not_found",
      };
    }

    return this.response;
  }
}

export default new PageManagementServices();
