import bcrypt from "bcryptjs";
import { Types } from "mongoose";
import { Communities } from "../../models/communities";
import { Post } from "../../models/posts";
import { Users } from "../../models/users";
import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";

import { ObjectId } from "mongodb";


class CommunityAdminServices {
  private response: ResponseObject;

  async getcommunitylist(data: any) {
    const { offset } = data;
    const limit = Number(offset);
    let communityInfo;

    communityInfo = await Communities.aggregate([
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
    ])
      .skip(limit)
      .limit(10);
    if (communityInfo.length === 0) {
      this.response = {
        success: false,
        message: "no_community_exist",
        data: "",
      };
      return this.response;
    }

    if (communityInfo) {
      const count = await Communities.find().count();
      communityInfo = { communityInfo: communityInfo, count: count };
      this.response = {
        success: true,
        message: "community_exist",
        data: communityInfo,
      };
    }
    return this.response;
  }

  async searchcommunitylist(data: any) {
    const { offset, search } = data;
    const limit = Number(offset);
    let communityInfo;

    if (search) {
      communityInfo = await Communities.aggregate([
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $match: {
            $or: [
              { title: { $regex: search, $options: "i" } },
              { status: { $regex: search, $options: "i" } },
            ],
          },
        },
      ])
        .limit(10)
        .skip(limit);
      const count = await Communities.find().count();

      if (communityInfo.length > 0) {
        communityInfo = { communityInfo: communityInfo, count: count };
        this.response = {
          success: true,
          data: communityInfo,
          message: "communities_found",
        };
      } else {
        this.response = {
          success: false,
          message: "communities_doesnt_exist",
          data: "",
        };
      }
    }

    return this.response;
  }

  async getcommunitydetail(data: any) {
    const { _id } = data;
    let resultData;
    // let reportedUserInfo ;
    const matchObject = {
      _id: new ObjectId(_id),
    };
 
    resultData = await Communities.aggregate([
      {
        $match: matchObject,
      },
      {
        $lookup: {
          from: "users",
          localField: "user_id",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $lookup: {
          from: "posts",
          pipeline: [
            {
              $match: {
                type: "community",
                type_item_id: `${_id}`,
                status: "Reported"
              },
            },
           
            {
              $sort: {
                created_ts: -1,
              },
            },
          ],
          as: "reportedPosts",
          
        },
      },
      {
        $lookup: {
          from: "posts",
          pipeline: [
            {
              $match: {
                type: "community",
                type_item_id: `${_id}`,
              },
            },
            {
            $sort: {
              created_ts: -1,
            },
          },
          ],
          as: "allPosts",
        },
      },
     
     
    ]);

    // reportedUserInfo = await Users.aggregate([
     
    //         {
    //           $match: {
    //             is_reported: 1,
    //             account_type: "Member",
              
    //           },
            
    //         },
    //         { $lookup: {
    //           from: "users",
    //           localField: "reported_by",
    //           foreignField: "_id",
    //           as: "reportedByUser"
    //         }},
    //         {
    //         $sort: {
    //           created_ts: -1,
    //         },
      
        
    //   },
    // ])

    if (resultData) {
      resultData = { communityData: resultData};
      this.response = {
        success: true,
        message: "found_communities",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "Could_not_find_communities",
        data: "",
      };
    }

    return this.response;
  }
}

export default new CommunityAdminServices();
