import bcrypt from "bcryptjs";
import { Types } from "mongoose";
import { Users } from "../../models/users";
import { BoatService } from "../../models/boatServices";
import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";
import { ObjectId } from "mongodb";

interface UserDetail {
  userId: string;
}

class UserAdminServices {
  private response: ResponseObject;

  async getuserslist(data: any) {
    const { offset } = data;
    const limit = Number(offset);
    const account_type = "Member";
    const query = { account_type };

    let accountInfo: any = await Users.find(query).limit(10).skip(limit);

    // console.log("accountInfo------", accountInfo);
    if (accountInfo.length === 0) {
      this.response = {
        success: false,
        message: "no_user_exist",
        data: "",
      };
      return this.response;
    }

    if (accountInfo) {
      this.response = {
        success: true,
        message: "user_exist",
        data: accountInfo,
      };
    }
    return this.response;
  }

  async searchuserslist(data: any) {
    const { offset, search } = data;
    const limit = Number(offset);
    const account_type = "Member";

    if (search && account_type) {
      const User = await Users.aggregate([
        {
          $match: {
            $or: [
              { email: { $regex: search, $options: "i" } },
              { name: { $regex: search, $options: "i" } },
         
            ],
          },
        },
      ])
        .limit(10)
        .skip(limit);

      if (User.length > 0) {
        this.response = {
          success: true,
          data: User,
          message: "User_found",
        };
      } else {
        this.response = {
          success: false,
          message: "user_doesnt_exist",
        };
      }
    }

    return this.response;
  }

  async userlistdetail(data: any) {
    //  console.log("data", data)
    const { userId } = data;
    const _id = userId;
    const account_type = "Member";

    let info = { _id, account_type };
    const resultData = await Users.find(info);
    // console.log(">>>>>>>>",resultData)
    if (resultData) {
      this.response = {
        success: true,
        message: "use_detail_found",
        data: resultData,
      };
    } else {
      this.response = {
        success: false,
        message: "user_detail_not_found",
        data: "",
      };
    }

    return this.response;
  }

  async userservicelist(data: any) {
    const { _id } = data;
    const account_type = "Member";
    let resultData ;
    const matchObject = {
      user_id: new ObjectId(_id),
    };

    const userData = await Users.find({ _id: _id, account_type: account_type });
 
    if (userData) {

       resultData = await BoatService.aggregate([
        {
          $match: matchObject,
        },
        {
          $lookup: {
            from: "boats",
            localField: "boat_id",
            foreignField: "_id",
            as: "boatInfo",
          },
        
        },
        {
          $sort: {
            due_date: -1,
          },
        },
      ]);
      console.log("resultData", resultData);
      if (resultData) {
   console.log("     resultData = [...resultData, userData]",      resultData = [...resultData, userData])
   resultData = {resultData:resultData,userData:userData};
        this.response = {
          success: true,
          message: "found_boatService",
          data: resultData,
        
        };
      } else {
        this.response = {
          success: false,
          message: "Could_not_find_boatService",
          data: resultData,
  
        };
      }
    } else {
      this.response = {
        success: false,
        message: "user_detail_not_found",
        data: "",
      };
    }

    return this.response;
  }
}

export default new UserAdminServices();
