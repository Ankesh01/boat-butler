import bcrypt from "bcryptjs";
import { Types } from "mongoose";
import { Engines } from "../../models/engines";

import createToken from "../../middlewares/generate";
import {
  ResponseObject,
  DataFromHeader,
} from "../../Interfaces/commonInterfaces";
import { ObjectId } from "mongodb";

interface IEngines {
    make: string;
    model: string;
    hp: number;
    dry_weight: number;
    start_type: string;
    tilt_trim: Object;
    fuel_type: Object;
    year: number;
    strock_series: string;
  
  }

class EngineAdminServices {
  private response: ResponseObject;

  async getenginelist(data: any) {
    const { offset } = data;
    const limit = Number(offset);
    


    let EngineList: any = await Engines.find().skip(limit).limit(10);

    // console.log("accountInfo------", accountInfo);
    if (EngineList.length === 0) {
  

      this.response = {
        success: false,
        message: "no_boat_exist",
        data: "",
        
      };
      return this.response;
    }

    if (EngineList) {
   
    const count = await Engines.find().count();
    const getBeginningOfTheWeek = (now) => {
      const days = (now.getDay() + 7 - 1) % 7;
      now.setDate(now.getDate() - days);
      now.setHours(0, 0, 0, 0);
      return now;
    };
        const result = await Engines.aggregate([
          {
            $match: {
              created_ts: {
                $gte: getBeginningOfTheWeek(new Date()),
                $lt: new Date(),
              },
            },
          },
          {
            $group: {
              _id: null,
              count: { $sum: 1 },
            },
          },
        ]);
        EngineList = {EngineList:EngineList, count:count, countInWeek:result}
      this.response = {
        success: true,
        message: "boat_exist",
        data: EngineList,
        
      };
    }
    return this.response;
  }

  async searchenginelist(data: any) {
    const { offset, search } = data;
    const limit = Number(offset);
    let Engine;
    let year;

    if(search.isNaN){
        year=0
    }else{
        year = parseInt(search);
    }
 
 
 

    if (search) {
        Engine = await Engines.aggregate([
        {
          $match: {
            $or: [
              { model: { $regex: search, $options: "i" } 
                },
                { start_type: { $regex: search, $options: "i" } 
                },
                { fuel_type: { $regex: search, $options: "i" } 
                },
                {year: year},
          
          
            ],
          },
        },
     
 
    ])
        .limit(10)
        .skip(limit);
        const count = await Engines.find().count();
        let date: any = new Date();
        const result  = await Engines.find({
          created_ts: {
            $gte: new Date(date - 7 * 60 * 60 * 24 * 1000),
          },
        }).count();
       
    

      if (Engine.length > 0) {
        Engine={EngineList:Engine, count:count, countInWeek:result}
        this.response = {
          success: true,
          data: Engine,
          message: "Boat_found",
        
        };
      } else {
        this.response = {
          success: false,
          message: "Boat_doesnt_exist",
          data:Engine,
        };
      }
    }

    return this.response;
  }

  
  async create(body: IEngines) {
    console.log("create--------------?", body);

    const result = await Engines.create({
      make: body?.make,
      model: body?.model,
      hp: body?.hp,
      tilt_trim: body?.tilt_trim,
      dry_weight: body?.dry_weight,
      start_type: body?.start_type,
      fuel_type: body?.fuel_type,
      year: body?.year,
      strock_series: body?.strock_series,
    });
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "Engines Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
 

  async getEngineById(engine_id: string) {
    let res;
    console.log("service_id", engine_id);
    try {
      res = await Engines.findOne({ _id: engine_id });
     
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_engine",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "engine_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "engine_not_found",
      };
    }

    return this.response;
  }


  async editEngine(body: IEngines, _id: string) {
 
    let result;
    try {
      result = await Engines.updateMany(
        {
          _id: _id,
        },
        { $set: body }
      );

   
    } catch (err) {
      this.response = {
        success: false,
        message: "updation_failed",
      };
    }

    if (result) {
      this.response = {
        success: true,
        message: "engine_updated_successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }
}

export default new EngineAdminServices();
