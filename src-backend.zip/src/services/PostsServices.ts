import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage } from "../utils/fileUpload";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { IPostActivityData } from "../Interfaces/PostsInterface";
import { PostComments } from "../models/post_comments";
import { Post } from "../models/posts";
import { UserPostActivities } from "../models/user_post_activities";
class PostsServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data) {
    let result;
    console.log("Post data", data);

    if (data) {
      try {
        result = await Post.create({
          user_id: data.user_id,
          media_file: data.image[0],
          title: data.title,
          type: data.type,
          type_item_id: data.type_item_id,
          description: data.description,
        });
        console.log("inside try", result);
      } catch (err) {
        this.response = {
          success: false,
          message: "failed",
        };
        return this.response;
      }
      if (result) {
        console.log("inside if", result);
        this.response = {
          success: true,
          message: "Post_added_succsessfully",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "no_data",
      };
    }
    return this.response;
  }

  
  async likeCommunityPost(data:IPostActivityData) {
    let response;
    console.log("Post new------- data", data);
    if (data.type === "post") {
      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          { $push: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "comment") {
      try {
        response = await PostComments.findByIdAndUpdate(
          data._id,
          { $push: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    }
    else if(data.type=== "bookmark"){
      let response;
      console.log("BookmarkPostPost data", data);
   
        try {
          response = await Post.findByIdAndUpdate(
            data._id,
            { $push: { "total.bookmarks": data.userId } },
            { new: true }
          );
        } catch (error) {
          this.response = {
            success: false,
            message: "failed",
          };
  
          return this.response;
        }
      
  
      // this.response = {
      //   success: true,
      //   message: "successfully_bookmarked",
      //   data: response,
      // };
  
    }

    this.response = {
      success: true,
      message: "successfully_liked",
      data: response,
    };

    return this.response;
  }
  async unlikeCommunityPost(data:IPostActivityData) {
    let response;
    console.log("Post data", data);
    if (data.type === "post") {
      try {
        response = await Post.findByIdAndUpdate(
          data._id,
          { $pull: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    } else if (data.type === "comment") {
      try {
        response = await PostComments.findByIdAndUpdate(
          data._id,
          { $pull: { "total.like": data.userId } },
          { new: true }
        );
      } catch (error) {
        this.response = {
          success: false,
          message: "failed",
        };

        return this.response;
      }
    }
    else if(data.type=== "bookmark"){
      let response;
      console.log("BookmarkPostPost data", data);
   
        try {
          response = await Post.findByIdAndUpdate(
            data._id,
            { $pull: { "total.bookmarks": data.userId } },
            { new: true }
          );
        } catch (error) {
          this.response = {
            success: false,
            message: "failed",
          };
  
          return this.response;
        }
      
  

  
    }
    this.response = {
      success: true,
      message: "successfully_unliked",
      data: response,
    };

    return this.response;
  }

  async reported(data:IPostActivityData) {
    console.log("reported data", data);
    try {
      await Post.findByIdAndUpdate(
        data._id,
        { $push: { "reported.reported_by": data.userId } },
        { new: true }
      );
    } catch (error) {
      this.response = {
        success: false,
        message: "failed",
      };
      
      return this.response;
    }
    this.response = {
      success: true,
      message: "post_reported_successfully",

    };

    return this.response;
  }




  // async addComment(data) {
  //   let comment = data.comment;
  //   let result = await Post.findByIdAndUpdate(
  //     data.postId,
  //     { $push: { "total.comments": comment } },
  //     { new: true }
  //   )
  //     .populate("post_comments.user_id", "_id name")
  //     .populate("postedBy", "_id name");
  // }


  async getpostDetailById(data: string) {
    const _id = data;
    console.log("getpostDetailById", _id);
    let res;
    try {
      // res = await Post.find({ _id : new ObjectId(_id)}).populate('user_id', '_id name')
      res = await Post.aggregate([
        {
          $match: {
            _id: new ObjectId(_id),
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $lookup: {
            from: "post_comments",
            let: { post__id: "$post__id" },
            pipeline: [
              {
                $match: {
                  
                  post_id: _id,
                },
              },
            ],
            as: "post_comments",
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_the_post",
      };
      return this.response;
    }

    if (res) {
      this.response = {
        success: true,
        message: "post_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "post_not_found",
      };
    }
    return this.response;
  }

  async postComment(data: any) {
    console.log("data", data);
    let result;
    if (data?.comment) {
      result = await PostComments.create({
        user_id: data?.user_id,
        post_id: data?.post_id,
        comment: data?.comment,
        status: data?.status,
      });
    } else {
      this.response = {
        success: true,
        data: "",
        message: "Empty comment",
      };
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "comment Added Successfully",
      };
    } else {
      this.response = {
        success: false,
        message: "Failed",
      };
    }
    return this.response;
  }

  async getComment(data: any) {
    console.log("data", data);
    const post_id = data.post_id;
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await PostComments.aggregate([
        {
          $match: {
            post_id: post_id,
          },
        },
        { $sort: { created_ts: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community_posts",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "community_posts_found",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "community_posts_not_found",
      };
    }

    return this.response;
  }

  async deleteCommentById(data:IPostActivityData) {
    console.log("data", data);
    const comment_id = data._id;
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await PostComments.deleteOne({_id:comment_id})
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_comment",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "comment_deleted_successfully",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "comment_not_found",
      };
    }

    return this.response;
  }
  async deletePostById(data) {
    console.log("data", data);
    const post_id = data._id;
    const user_id = data.userId;
    let result;
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      result = await Post.deleteOne({_id:post_id,user_id:user_id})
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_comment",
      };

      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        message: "comment_deleted_successfully",
        data: result,
      };
    } else {
      this.response = {
        success: false,
        message: "comment_not_found",
      };
    }

    return this.response;
  }
}

export default new PostsServices();
