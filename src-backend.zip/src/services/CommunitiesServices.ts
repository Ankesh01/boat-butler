import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage } from "../utils/fileUpload";
import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { Communities } from "../models/communities";
import { Post } from "../models/posts";
class CommunitiesServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data) {
    let result;
    console.log("communityt data", data);

    if (data.image && data.image.data && data.image.data.includes("base64")) {
      let imageUrl = await uploadImage(
        data.image.data,
        "boat-buttler-media",
        `community/${Date.now()}`,
        data.image.format
      );
      data.image = imageUrl;
    } else {
      data.image = "";
    }

    console.log("community Final data", data);
    if (data) {
      try {
        result = await Communities.create({
          user_id: data.user_id,
          image: data.image,
          title: data.title,
          description: data.description,
        });
        console.log("inside try", result);
      } catch (err) {
        this.response = {
          success: false,
          message: "failed",
        };
        return this.response;
      }
      if (result) {
        console.log("inside if", result);
        this.response = {
          success: true,
          message: "community_added_succsessfully",
          data: result,
        };
      }
    } else {
      this.response = {
        success: false,
        message: "no_data",
      };
    }
    return this.response;
  }

  async getCommunityById(_id: string) {
    let res;
    console.log("Community_id", _id);
    try {
      res = await Communities.findById(_id);
      console.log("Communities Response====", res);
      // res = await Communities.aggregate([
      //   {
      //     $match: {
      //       _id: new ObjectId(_id),
      //     },
      //   },
      //   {
      //     $lookup: {
      //       from: "posts",
      //       let: { type_item_id: "$type_item_id" },
      //       pipeline: [
      //         {
      //           $match: {
      //             type: "community",
      //             type_item_id: "6239cd2f479ab02523390d25",
      //           },
      //         },
      //       ],
      //       as: "posts",
      //     },
      //   },
      // ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "community_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "community_not_found",
      };
    }

    return this.response;
  }

  async getCommunityPosts(_id: string) {
    let res;
    console.log("Community_Posts_id", _id);
    try {
      // res = await Post.find({type:"community",type_item_id:_id}).populate('user_id', '_id name')
      res = await Post.aggregate([
        {
          $match: {
            type: "community",
            type_item_id: _id,
          },
        },
        { $sort: { created_ts: -1 } },
        {
          $lookup: {
            from: "users",
            localField: "user_id",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $lookup: {
            from: "post_comments",
            let: { post__id: "$post__id" },
            pipeline: [
              {
                $match: {
                  
                  post_id: _id,
                },
              },
            ],
            as: "post_comments",
          },
        },
      ]);
    } catch (e) {
      this.response = {
        success: false,
        message: "could_not_find_community_posts",
      };

      return this.response;
    }
    if (res) {
      this.response = {
        success: true,
        message: "community_posts_found",
        data: res,
      };
    } else {
      this.response = {
        success: false,
        message: "community_posts_not_found",
      };
    }

    return this.response;
  }
}

export default new CommunitiesServices();
