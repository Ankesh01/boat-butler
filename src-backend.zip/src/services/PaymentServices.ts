import bcrypt from "bcryptjs";

import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { uploadImage, deleteFileFromS3 } from "../utils/fileUpload";

import { Payments } from "../models/payments";
// import { Member } from "../models/members";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { Member } from "../models/members";


class PaymentServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Sign up
   */
  async create(data: any) {
    
    if (data) {
      const PaymentInfo = await Payments.create({
        user_id:"620b4a5f6aa32c6f14df7b50",
        amount: 2,
        model: "Standard",
        status: ""
      })
      

      if (PaymentInfo) {
        this.response = {
          success: true,
          data: PaymentInfo,
          message: "PaymentInfo Added Successfully",
        };
      } else {
        this.response = {
          success: false,
          message: "Failed",
        };
      }
    } 
    return this.response;
  }
}

export default new PaymentServices();
