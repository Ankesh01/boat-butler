import moment from "moment";
import { UserNotifications } from "../models/userNotifications";
import { ObjectId } from "mongodb";
import { sendNotification } from "../utils/fcmNotification";
const CronJob = require("cron").CronJob;

export const intializeCronJobs = () => {
  notificationCronJob();
};

const notificationCronJob = () => {
  const job = new CronJob(
    "*/1 * * * *",
    function () {
      console.log(
        `notificationCronJob started at : `,
        moment.utc().format("DD-MM-YYYY HH:mm:SS")
      );
      generateReminderNotification();
    },
    null,
    true,
    "America/Los_Angeles"
  );
  job.start();
};

const generateReminderNotification = async () => {
  const currentDateTime = new Date(moment.utc().format("MM-DD-YYYY HH:mm"));
  console.log(
    "checking for notifications at ",
    moment(currentDateTime).format("DD-MM-YYYY HH:mm:SS"),
    currentDateTime
  );
  const result = await UserNotifications.aggregate([
    {
      $match: {
        due_date: new Date(currentDateTime),
        send_status: 0,
      },
    },
    {
      $lookup: {
        from: "users",
        localField: "user_id",
        foreignField: "_id",
        as: "userInfo",
      },
    },
  ]);

  console.log("result UserNotifications", JSON.stringify(result));

  let updateSendStatusIdList = [];
  for (let data of result) {
    console.log("data.userInfo[0] ", data.userInfo);
    console.log("data.userInfo[0]?.fcm_token ", data.userInfo[0]?.fcm_token);
    if (data.userInfo[0]?.fcm_token) {
      await sendNotification(
        [data.userInfo[0]?.fcm_token],
        data.message.title,
        data.message.body
      );
      updateSendStatusIdList.push(data._id);
    }
  }

  if (updateSendStatusIdList.length > 0) {
    const updateResult = await UserNotifications.updateMany(
      {
        _id: {
          $in: updateSendStatusIdList.map((i) => new ObjectId(i)),
        },
      },
      {
        $set: {
          send_status: 1,
        },
      }
    );

    console.log(
      "result generateReminderNotification ---------- ",
      updateResult
    );
  }
};
