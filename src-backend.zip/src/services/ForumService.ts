import { ResponseObject } from "../Interfaces/commonInterfaces";
import { Forum } from "../models/forum";

class ForumService {
  private response: ResponseObject;

  async getAllForum() {
    let result;
    try {
      result = await Forum.find();
    } catch (err) {
      this.response = {
        success: false,
        message: "Forum_data_failed",
      };
      return this.response;
    }
    if (result) {
      this.response = {
        success: true,
        data: result,
        message: "forum_data_fetched_successfully",
      };
    } else {
      this.response = {
        success: false,
        data: result,
        message: "could_not_fetch",
      };
    }

    return this.response;
  }
}

export default new ForumService();
