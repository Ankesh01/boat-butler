import bcrypt from "bcryptjs";
import { HmacSHA256, enc } from "crypto-js";
import { ObjectId } from "mongodb";

import { Types } from "mongoose";
import { sendOtpEmail } from "../utils/emailService";
import config from "../config/envConfig";

import { Users, UserSchema } from "../models/users";
import { Payments } from "../models/payments";
import createToken from "../middlewares/generate";
import { sendMail } from "../utils/emailService";
import { uploadImage, deleteFileFromS3 } from "../utils/fileUpload";
// import { Member } from "../models/members";

import { ResponseObject, DataFromHeader } from "../Interfaces/commonInterfaces";
import { Member } from "../models/members";

const configObject: any = config();
var CryptoJS = require("crypto-js");
// var CryptoJS = require("crypto-js");

const googleClientId =
  "186999441008-t2oo88co3edcv116vka92mm0jnjo314a.apps.googleusercontent.com";

const { OAuth2Client } = require("google-auth-library");
const client = new OAuth2Client(googleClientId);

interface IChangePassword {
  oldPassword: string;
  newPassword: string;
  id: number;
}
interface LoginData {
  email: string;
  password: string;
  fcmToken: string;
  timezone: string;
}

interface ISignup {
  name: string;
  email: string;
  password: string;
  // addressLine1: string;
  // addressLine2?: string;
  // city: string;
  // state: string;
  // zip: number;
  // country: string;
  // website: string;
  // password: string;
  // phone: string;
  // branch: string;
  // ssn: string;
}

interface IImage {
  dataUrl?: string[];
  format?: string;
}
interface IProfile {
  name: string;
  email: string;
  phone: number;
  gender: string;
  image: IImage;
  address_line_1: string;
  address_line_2?: string;
  state: string;
  zipcode: number;
  city: string;
  country: string;
  oldImage?: string;
  imageType?: string;
}

const verifyGoogleIdToken = async (token: any, type: string) => {
  try {
    if (type === "google") {
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: googleClientId,
      });
      const payload = ticket.getPayload();

      console.log("payload for googleIdToken is", payload);
      return {
        isError: false,
        data: payload,
      };
    }
  } catch (error) {
    console.log("error at verifying token", error);
    return {
      isError: true,
      data: null,
    };
  }
};
class AuthServices {
  /**
   * Standard response object
   */
  private response: ResponseObject;

  /**
   * Login
   */
  async login(data: LoginData) {
    console.log("Login---------", data);
    const { email, password, fcmToken, timezone } = data;
    const query = { email };
    await Users.updateOne({ email }, { $set: { timezone: timezone } });
    // let userInfo: any = await Users.findOne(query)
    let userInfo: any = await Users.aggregate([
      {
        $match: {
          email,
        },
      },
      {
        $lookup: {
          from: "payments",
          localField: "_id",
          foreignField: "user_id",
          as: "paymentInfo",
        },
      },
    ]);
    console.log("UserInfo------", userInfo);
    if (userInfo.length === 0) {
      this.response = {
        success: false,
        message: "no_user_found",
      };
      return this.response;
    }
    userInfo = userInfo[0];

    if (userInfo) {
      if (await bcrypt.compare(password.trim(), userInfo.password as string)) {
        delete userInfo.password;
        const token = await createToken(userInfo);
        console.log("token  =>", token);
        userInfo["token"] = token;

        await Users.updateOne({ email }, { $set: { fcm_token: fcmToken } });
        this.response = {
          success: true,
          message: "login_successful",
          data: userInfo,
        };
      } else {
        this.response = {
          success: false,
          message: "credientials_not_match",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "no_user_found",
      };
    }
    return this.response;
  }

  /**
   * Sign up
   */
  async signup(data: ISignup) {
    const { name, email, password } = data;
    const hashedPassword = await bcrypt.hash(password, 8);
    const UserData = {
      name: name,
      email: email.toLowerCase(),
      password: hashedPassword,
    };

    console.log("User Data", UserData);
    console.log("*****test unique email validation******");
    if (UserData) {
      const UserInfo = await Users.create(UserData);

      if (UserInfo) {
        // const userMail:any = email;
        // const otp = await sendOtpEmail( userMail );
        // const encryptedOtp = enc.Base64.stringify(
        //   HmacSHA256(otp.toString(), configObject.crypto_key)
        // );
        // const info = Object.assign({ encOtp: encryptedOtp });
        // console.log(
        //   otp,
        //   typeof encryptedOtp,
        //   "----otp generate>>>---",
        //   encryptedOtp
        // );
        this.response = {
          success: true,
          message: "signup_successful",
        };
      } else {
        this.response = {
          success: false,
          message: "signup_failed",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "signup_failed",
      };
    }
    return this.response;
  }

  async socialLogin(data: any): Promise<any> {
    console.log("social data-----", data);

    const { email, type, idToken } = data;

    if (type === "google" || type === "Agoogle") {
      const verifyResponse = await verifyGoogleIdToken(idToken, type);
      console.log("verifyResponse---google Login", verifyResponse);

      if (verifyResponse && !verifyResponse.isError && verifyResponse.data) {
        if (verifyResponse.data.email_verified) {
          let email = verifyResponse.data.email;
          let name = verifyResponse.data.name;
          let searchUserResponse: any = await Users.findOne({ email });
          if (!searchUserResponse) {
            //TODO: create user function
            let googlUser = await Users.create({ name, email });
            searchUserResponse = await Users.findOne({ email });
          }
          if (searchUserResponse != null) {
            this.response = {
              success: true,
              message: "Social_login_successful",
              type: "google",
            };
          }
        } else {
          // google email not verified
          this.response = {
            success: false,
            message: "Email is not verified",
            isFound: false,
          };
        }
      } else {
        // google verifyResponse is error true
        this.response = {
          success: false,
          message: "Invalid token signature",
          isFound: false,
        };
      }
    } else if (type === "facebook") {
      // type is facebook
      let { email, first_name: name, last_name } = data;

      let searchUserResponse: any = await Users.findOne({ email });
      console.log("email-----Fb", searchUserResponse);

      if (!searchUserResponse) {
        //TODO: create user function
        let fbuser = await Users.create({ name, last_name, email });
        console.log("fbuserInside--------------");

        searchUserResponse = await Users.findOne({ email });
      }

      if (searchUserResponse != null) {
        this.response = {
          success: true,
          message: "Social_successful",
          type: "facebook",
          user: searchUserResponse,
          isFound: true,
        };
      } else {
        this.response = { success: false, message: searchUserResponse };
      }
    }
    return this.response;
  }

  async forgotpassword(data: any) {
    const { email } = data;

    // const newOtpEncryption = enc.Base64.stringify(
    //   HmacSHA256(otp?.toString(), configObject.crypto_key)
    // );

    // if (newOtpEncryption === enteredOtp) {
    //   const myQuery = { email: email }
    //   this.response = {
    //     success: true,
    //     message: "password_reset",
    //   };
    // } else {
    //   this.response = {
    //     success: false,
    //     message: "not_aothorize_to_reset_password",
    //   };
    // }
    return this.response;
  }
  async sendOtp(data: any) {
    const { email } = data;

    const query = { email };
    if (email) {
      const userDetail = await Users.findOne(query);
      if (userDetail && Object.keys(userDetail).length > 0) {
        const otp = await sendOtpEmail(email);
        if (otp) {
          const encryptedOtp = CryptoJS.AES.encrypt(
            otp.toString(),
            "My-Secret -Key"
          ).toString();
          console.log("encryptedOtp-----------", encryptedOtp);
          if (email === userDetail.email) {
            await Users.updateOne(
              { email },
              { $set: { encOtp: encryptedOtp } }
            );
          }
        }

        console.log(otp, typeof otp, "----otp generate>>>---", otp);

        this.response = {
          success: true,
          message: "otp_send",
          data: otp,
        };
      } else {
        this.response = {
          success: false,
          message: "no_user_found",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "Input validation failed. Please insert proper input",
      };
    }

    return this.response;
  }

  async otpVerification(data: any) {
    let { email, otp } = data;
    const userDetail = await Users.findOne({ email });
    const { encOtp } = userDetail;
    var bytes = CryptoJS.AES.decrypt(encOtp, "My-Secret -Key");
    var decryptedOtp = bytes.toString(CryptoJS.enc.Utf8);

    if (userDetail) {
      if (otp.toString() === decryptedOtp) {
        await Users.updateOne({ email }, { $set: { is_verified: 1 } });
        this.response = {
          success: true,
          message: "otp_match",
        };
      } else {
        this.response = {
          success: false,
          message: "otp_not_match",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "input_validation_failed_msg",
      };
    }
    return this.response;
  }

  async changePassword(data: any) {
    const { password, newpassword, email } = data;
    console.log("Data-----------", data);

    const user = await Users.findOne({ email: email });

    if (user) {
      const encryptedNewPassword = await bcrypt.hash(newpassword, 8);
      const query = { $set: { password: encryptedNewPassword } };
      // bcrypt.compareSync(myPlaintextPassword, hash);
      console.log("Change PAssword Query---", query);
      if (await bcrypt.compareSync(password.trim(), user.password as string)) {
        console.log("Inside bcryptCompare---");
        await Users.updateOne({ email: email }, query);
        this.response = {
          success: true,
          message: "password_changed",
        };
      } else {
        this.response = {
          success: false,
          message: "password_does_not_match",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "user_does_not_exist",
      };
    }
    return this.response;
  }

  // async changePassword(data: any) {
  //   const { password, newpassword,email } = data;

  //   const users = await Users.findOne({ email: email });
  //   if (users) {
  //     if (await bcrypt.compare(password.trim(), users.password as string)) {
  //       const encryptedNewPassword = await bcrypt.hash(newpassword, 8);
  //       const query = { $set: { password: encryptedNewPassword } };
  //       await Users.updateOne({ _id: data.id }, query);
  //       this.response = {
  //         success: true,
  //         message: "password_changed",
  //       };
  //     } else {
  //       this.response = {
  //         success: false,
  //         message: "not_authorize_to_change_password",
  //       };
  //     }
  //   }

  //   return this.response;
  // }

  /**
   * Validate the auth token
   * @param data DataFromHeader
   * @returns
   */
  async matchToken(data: DataFromHeader) {
    const { id, token } = data;
    const userInfo = (
      await Users.findOne({
        _id: id,
      })
    ).toJSON();
    // if (userInfo) {
    //   const providerInfo = await this.getProviderInfo(id);
    //   delete userInfo.password;
    //   this.response = {
    //     success: true,
    //     message: "token_matched",
    //     data: { ...userInfo, token: token, providerInfo: providerInfo[0] },
    //   };
    // }
    // else {
    //   this.response = {
    //     success: false,
    //     message: "user_not_found",
    //   };
    // }
    return this.response;
  }
  async profile(data: IProfile) {
    let {
      name,
      phone,
      email,
      gender,
      address_line_1,
      address_line_2,
      state,
      city,
      zipcode,
      image,
      oldImage,
    } = data;

    // const query = { email };
    // let userInfo: any = await Users.findOne(query);
    // const hashedPassword = await bcrypt.hash(password, 8);
    let imageUrl = image.dataUrl;
    if (image.dataUrl.includes("base64")) {
      imageUrl = (await uploadImage(
        image.dataUrl,
        "boat-buttler-media",
        `user/profile/${Date.now()}`
      )) as string[];
      deleteFileFromS3(oldImage);
    }

    const ProfileData = {
      name: name,
      email: email.toLowerCase(),
      phone: phone,
      gender: gender,
      address_line_1: address_line_1,
      address_line_2: address_line_2,
      state: state,
      city: city,
      zipcode: zipcode,
      image: imageUrl,
    };
    // if (userInfo) {
    //   userInfo = userInfo.toJSON();

    if (ProfileData) {
      const ProfileInfo = await Users.updateOne({ email }, { ...ProfileData });
      if (ProfileInfo) {
        this.response = {
          success: true,
          message: "Profile added successful",
          data: ProfileInfo,
        };
      } else {
        this.response = {
          success: false,
          message: "profile added failed",
        };
      }
    } else {
      this.response = {
        success: false,
        message: "profile added failed",
      };
    }
    // }
    // else {
    //   this.response = {
    //     success: false,
    //     message: 'no_user_found',
    //   };
    // }
    return this.response;
  }

  async getUserDetail(id: string) {
    let user;
    try {
      user = await Users.findById(id);
      console.log("USer----", user);
      if (user) {
        this.response = {
          success: true,
          message: "user_found",
          data: user,
        };
      } else {
        this.response = {
          success: false,
          message: "user_not_found",
        };
      }
    } catch (e) {
      this.response = {
        success: false,
        message: "Could_not_find_User",
      };
      return this.response;
    }

    return this.response;
  }

  async deleteUser(id: string) {
    console.log("Id To Delete----", id);
    var delUser;
    try {
      delUser = await Users.findById(id);

      if (delUser) {
        delUser.remove();
        this.response = {
          success: true,
          message: "user_deleted",
        };
      }
    } catch (err) {
      this.response = {
        success: false,
        message: "user_not_found",
      };
    }
    return this.response;
  }

  async clearFcmToken(userId: string) {
    try {
      await Users.updateOne({ _id: userId }, { $set: { fcm_token: null } });
      this.response = {
        success: true,
        message: "user_deleted",
      };
    } catch (err) {
      this.response = {
        success: false,
        message: "user_not_found",
      };
    }
    return this.response;
  }
}

export default new AuthServices();
