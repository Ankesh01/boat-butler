import express from "express";

import AuthRoutes from "./routes/AuthRoutes";
import BoatRoutes from "./routes/BoatRoutes";
import PaymentRoutes from "./routes/PaymentRoutes";
import BoatServicesRoutes from "./routes/BoatServicesRoutes";
import PagesRoutes from "./routes/PageRoutes";
import ForumRoutes from "./routes/ForumRoutes";
import FileRoutes from "./routes/FileRoutes";
import RemindersRoutes from "./routes/RemindersRoutes";
import BusinessesRoutes from "./routes/BusinessesRoutes";
import CommunititesRoutes from "./routes/CommunitiesRoutes";
import PostsRoutes from "./routes/PostsRoutes";
//admin routes
import AuthAdminRoutes from "./routes/adminroutes/AuthAdminRoutes";
import UserAdminRoutes from "./routes/adminroutes/UserAdminRoutes";
import BusinessesAdminRoutes from "./routes/adminroutes/BusinessAdminRoutes";
import BoatAdminRoutes from "./routes/adminroutes/BoatAdminRoutes";
import PageManagementRoutes from "./routes/adminroutes/PageManagementAdminRoutes";
import EngineAdminRoutes from "./routes/adminroutes/EngineAdminRoutes";

import CommunityAdminRoutes from "./routes/adminroutes/CommunityAdminRoutes";
const app = express();

app.use("/api/v1/auth", AuthRoutes);
app.use("/api/v1/boat", BoatRoutes);
app.use("/api/v1/payment", PaymentRoutes);
app.use("/api/v1/boat-services", BoatServicesRoutes);
app.use("/api/v1/pages", PagesRoutes);
app.use("/api/v1/forum", ForumRoutes);
app.use("/api/v1/files", FileRoutes);
app.use("/api/v1/reminders", RemindersRoutes);
app.use("/api/v1/businesses", BusinessesRoutes);
app.use("/api/v1/communities", CommunititesRoutes);
app.use("/api/v1/posts", PostsRoutes);
//admin routes
app.use("/api/v1/admin/users", UserAdminRoutes);
app.use("/api/v1/admin/boats", BoatAdminRoutes);
app.use("/api/v1/admin", AuthAdminRoutes);
app.use("/api/v1/admin/businesses", BusinessesAdminRoutes);
app.use("/api/v1/admin/page-management", PageManagementRoutes);
app.use("/api/v1/admin/engines", EngineAdminRoutes);
app.use("/api/v1/admin/community", CommunityAdminRoutes);
export default app;
