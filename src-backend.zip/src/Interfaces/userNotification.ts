export interface IUserNocation {
    user_id: boolean;
    message: string;
}