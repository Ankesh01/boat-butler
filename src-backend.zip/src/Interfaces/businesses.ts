import { Schema } from "mongoose";

export interface BusinessesSchema {
  owner_name: string;
  business_name: string;
  registration_number: string;
  contact_number: string;
  email: string;
  location: Object;
  business_hours: Object;
  business_days: string[];

  services: string;
  photos: [];
  geometry: Schema;
  status: string;
}
