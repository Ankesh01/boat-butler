import mongoose from "mongoose";

import config from "../config/envConfig";

const envConfig = config();

mongoose.connect(envConfig.mongoUri);
mongoose.connection.on("error", (error) => {
  console.log("error", error);
  throw new Error(`unable to connect to database: ${envConfig.mongoUri}`);
});
console.log("envConfig.mongoUri", envConfig.mongoUri);
