const sgMail = require('@sendgrid/mail');
const sendgridApiKey = "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"
const sendgridUsername = "narendra@biz4group.com"
sgMail.setApiKey(sendgridApiKey);

export const sendMail = async (email: string, content: any) => {
  console.log('Send email to ', email, content);
  const mailData = {
    from: sendgridUsername,
    to: email,
    subject: content.subject,
    text: content.text,
    html: content.html,
  };
  try {
    await sgMail.send(mailData);
    console.log(`Mail sent successfully to ${email}`);
    return {
      isError: false,
      message: 'Email sent successfully.',
    };
  } catch (error) {
    console.log('Mail send failed', JSON.stringify(error));
    return {
      isError: false,
      message: error,
    };
  }
};



export const sendOtpEmail = async (data: IArguments): Promise<any> => {
  const otp = Math.floor(10000 + Math.random() * 90000);
  const userMail:any = data;
  const message = "Please check below otp to reset your password.";
  const content = {
    from: sendgridUsername,
    to: userMail,
    text: `OTP : ${otp}`,
    html: `<html>
          <head>

          </head>
          <body>
              <div style="text-align: center;">
              <div style="margin-bottom: 20px;"><h1 style="color: blue">Boat-Butler</h1></div>
                  <h3 style="font-size: 28px;">Dear user</h3>
                  <p style=" max-width: 400px;
                  margin: 0 auto;
                  margin-bottom: 20px;
                  font-size: 20px;">${message}</p>

                 <h2>OTP: </h2> <p style = "font-size: 40px;">${otp}</p>

                  <p style=" max-width: 400px;
                  margin: 0 auto;
                  margin-bottom: 20px;
      
              </div>
          </body>
      </html> `,
      subject: "Verify your email",
  };
await sendMail(userMail,content)
  return otp;
};

