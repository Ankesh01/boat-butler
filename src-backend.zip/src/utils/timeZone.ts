class timeZone {
  convertTZ(date, tzString) {
    return new Date(
      (typeof date === "string" ? new Date(date) : date).toLocaleString(
        "en-US",
        { timeZone: tzString }
      )
    );
  }

  timeZoneList = () => {
    const timezoneList = [
      { tz: "AKDT", title: "Alaska Daylight Time - AKDT", tzDiff: -8 },
      { tz: "CDT", title: "Central Daylight Time - CDT", tzDiff: -5 },
      { tz: "EDT", title: "Eastern Daylight Time - EDT", tzDiff: -4 },
      { tz: "HST", title: "Hawaii-Aleutian Standard Time - HST", tzDiff: -10 },
      { tz: "MDT", title: "Mountain Daylight Time - MDT", tzDiff: -6 },
      { tz: "MST", title: "Mountain Standard Time - MST", tzDiff: -7 },
      { tz: "PDT", title: "Pacific Daylight Time - PDT", tzDiff: -7 },
    ];
    return timezoneList;
  };

  //add two times with HH and MM
  addTimes(startTime, endTime) {
    var times = [0, 0];
    var max = times.length;

    var a = (startTime || "").split(":");
    var b = (endTime || "").split(":");

    // normalize time values
    for (var i = 0; i < max; i++) {
      a[i] = isNaN(parseInt(a[i])) ? 0 : parseInt(a[i]);
      b[i] = isNaN(parseInt(b[i])) ? 0 : parseInt(b[i]);
    }

    // store time values
    for (var i = 0; i < max; i++) {
      times[i] = a[i] + b[i];
    }

    var hours = times[0];
    var minutes = times[1];
    console.log(hours);

    if (minutes >= 60) {
      var res = (minutes / 60) | 0;
      hours += res;
      minutes = minutes - 60 * res;
    }

    if (hours >= 24) {
      hours = hours % 24;
      hours = hours < 0 ? 24 + hours : +hours;
    }

    return ("0" + hours).slice(-2) + ":" + ("0" + minutes).slice(-2);
  }

  timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = [
      "01",
      "02",
      "03",
      "04",
      "05",
      "06",
      "07",
      "08",
      "09",
      "10",
      "11",
      "12",
    ];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time =
      year + "-" + month + "-" + date + " " + hour + ":" + min + ":" + sec;
    return time;
  }

  treatAsUTC(date: Date) {
    var result = new Date(date);
    result.setMinutes(result.getMinutes() - result.getTimezoneOffset());
    return result;
  }
}

export default new timeZone();

// function getRandomString(text) {
//   return text + Math.floor(Math.random() * 100000 + 1);
// }

// function getDate() {
//   return new Date().toISOString().substring(0, 10);
// }

// function daysInMonth(month, year) {
//   return new Date(year, month, 0).getDate();
// }

// function timeConverter(UNIX_timestamp) {
//   var a = new Date(UNIX_timestamp * 1000);
//   var months = [
//     "01",
//     "02",
//     "03",
//     "04",
//     "05",
//     "06",
//     "07",
//     "08",
//     "09",
//     "10",
//     "11",
//     "12",
//   ];
//   var year = a.getFullYear();
//   var month = months[a.getMonth()];
//   var date = a.getDate();
//   var hour = a.getHours();
//   var min = a.getMinutes();
//   var sec = a.getSeconds();
//   var time =
//     year + "-" + month + "-" + date + " " + hour + ":" + min + ":" + sec;
//   return time;
// }
const timeZoneList = () => {
  const timezoneList = [
    { tz: "AKDT", title: "Alaska Daylight Time - AKDT", tzDiff: -8 },
    { tz: "CDT", title: "Central Daylight Time - CDT", tzDiff: -5 },
    { tz: "EDT", title: "Eastern Daylight Time - EDT", tzDiff: -4 },
    { tz: "HST", title: "Hawaii-Aleutian Standard Time - HST", tzDiff: -10 },
    { tz: "MDT", title: "Mountain Daylight Time - MDT", tzDiff: -6 },
    { tz: "MST", title: "Mountain Standard Time - MST", tzDiff: -7 },
    { tz: "PDT", title: "Pacific Daylight Time - PDT", tzDiff: -7 },
  ];
  return timezoneList;
};

//add two times with HH and MM
function addTimes(startTime, endTime) {
  var times = [0, 0];
  var max = times.length;

  var a = (startTime || "").split(":");
  var b = (endTime || "").split(":");

  // normalize time values
  for (var i = 0; i < max; i++) {
    a[i] = isNaN(parseInt(a[i])) ? 0 : parseInt(a[i]);
    b[i] = isNaN(parseInt(b[i])) ? 0 : parseInt(b[i]);
  }

  // store time values
  for (var i = 0; i < max; i++) {
    times[i] = a[i] + b[i];
  }

  var hours = times[0];
  var minutes = times[1];
  console.log(hours);

  if (minutes >= 60) {
    var res = (minutes / 60) | 0;
    hours += res;
    minutes = minutes - 60 * res;
  }

  if (hours >= 24) {
    hours = hours % 24;
    hours = hours < 0 ? 24 + hours : +hours;
  }

  return ("0" + hours).slice(-2) + ":" + ("0" + minutes).slice(-2);
}

function treatAsUTC(date: Date) {
  var result = new Date(date);
  result.setMinutes(result.getMinutes() - result.getTimezoneOffset());
  return result;
}

// function dateRange(startDate, endDate, steps = 14) {
//   const dateArray = [];
//   let currentDate = new Date(startDate);

//   while (currentDate <= new Date(endDate)) {
//     dateArray.push(new Date(currentDate));
//     // Use UTC date to prevent problems with time zones and DST
//     currentDate.setUTCDate(currentDate.getUTCDate() + steps);
//   }

//   return dateArray;
// }

// function monthDiff(d1, d2) {
//   var months;
//   months = (d2.getFullYear() - d1.getFullYear()) * 12;
//   months -= d1.getMonth();
//   months += d2.getMonth();
//   return months <= 0 ? 0 : months;
// }

// function addMonths(date, months) {
//   var d = date.getDate();
//   date.setMonth(date.getMonth() + +months);
//   if (date.getDate() != d) {
//     date.setDate(0);
//   }
//   return date;
// }

// function timeDiffBetweenDates(startDate, endDate) {
//   startDate = new Date(startDate);
//   endDate = new Date(endDate);
//   let timeStampDifference = 0;
//   if (startDate.getTime() > endDate.getTime()) {
//     const nextNight = new Date(startDate);
//     nextNight.setDate(startDate.getDate() + 1);
//     nextNight.setHours(0, 0, 0, 0);
//     timeStampDifference = nextNight.getTime() - startDate.getTime();
//     endDate.setDate(nextNight.getDate());
//     timeStampDifference =
//       timeStampDifference + (endDate.getTime() - nextNight.getTime());
//   } else {
//     timeStampDifference = endDate.getTime() - startDate.getTime();
//   }
//   return timeStampDifference;
// }

// module.exports.timeZoneList = timeZoneList;
// module.exports.addTimes = addTimes;

// module.exports.dateRange = dateRange;
// module.exports.monthDiff = monthDiff;
// module.exports.addMonths = addMonths;
// module.exports.timeDiffBetweenDates = timeDiffBetweenDates;
