import * as admin from "firebase-admin";
import "../../boat-butler-c5750-firebase-adminsdk-4ki0j-e3f252f966.json"
const serviceAccount = require("../../boat-butler-c5750-firebase-adminsdk-4ki0j-e3f252f966.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
})

interface IMessage {
    notification : { title : string; body : any};
    tokens : string[];
    data? : any
}

export const sendNotification = async (tokenList : string[],title : string, body : any, data?:any) =>{
    console.log(' title -----', title)
    console.log(' data -----', data)
    console.log(' tokenList -----', tokenList)
    const message : IMessage = {
        notification : {title, body},
        tokens : tokenList
    }
    if(data && Object.keys(data).length!==0){
        message.data = data
    }
    const result = await admin.messaging().sendMulticast(message)
    console.log('notification result ', JSON.stringify(result))
}