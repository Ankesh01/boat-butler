import express from "express";

import HandleErrors from "../middlewares/handleError";

import {
  create,
  getCommunityById,
  getCommunityPosts,
} from "../controllers/CommunitiesController";
import Auth from "../middlewares/auth";

const CommunititesRoutes = express.Router();

CommunititesRoutes.post("/create", Auth, HandleErrors(create));
CommunititesRoutes.get("/:id", Auth, HandleErrors(getCommunityById));
CommunititesRoutes.get("/posts/:id", Auth, HandleErrors(getCommunityPosts));


export default CommunititesRoutes;
