import express from "express";

import Auth from "../middlewares/auth";
import HandleErrors from "../middlewares/handleError";

import {
  editProfile,
  fillOnboardingForm,
  communication,
  searchCandidates,
  getCommunicationTemplates,
  questionaries,
  createJobShift,
  jobShift,
  inviteCandidates,
} from "../controllers/ProviderController";

const providerRoutes = express.Router();

providerRoutes.put("/edit-profile", Auth, HandleErrors(editProfile));
providerRoutes.put(
  "/fill-onboarding-forms",
  Auth,
  HandleErrors(fillOnboardingForm)
);
providerRoutes.post("/communication", Auth, HandleErrors(communication));
providerRoutes.post("/search-candidates", Auth, HandleErrors(searchCandidates));
providerRoutes.get(
  "/get-communication-templates",
  Auth,
  HandleErrors(getCommunicationTemplates)
);
providerRoutes.post("/invite-candidates", Auth, HandleErrors(inviteCandidates));
providerRoutes.post("/questionaries", Auth, HandleErrors(questionaries));
providerRoutes.post("/job-shifts", HandleErrors(createJobShift));
providerRoutes.get("/jobs", jobShift);

export default providerRoutes;
