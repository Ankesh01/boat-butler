import express from "express";
import Auth from "../middlewares/auth";

import HandleErrors from "../middlewares/handleError";

import { getAllForum } from "../controllers/ForumController";

const ForumRoutes = express.Router();

ForumRoutes.get("/get-all", HandleErrors(getAllForum));
// Auth,

export default ForumRoutes;
