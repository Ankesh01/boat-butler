import express from "express";
import {
  create,
  getAllFaqList,
  editFaqs,
  getPageProviderById,
  getAllWebPagesList,
} from "../../controllers/admincontrollers/PageManagementAdminController";
import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";

const PageManagementRoutes = express.Router();
PageManagementRoutes.post("/create", Auth, HandleErrors(create));
PageManagementRoutes.get("/get-webPages",Auth, HandleErrors(getAllWebPagesList));
PageManagementRoutes.get("/get-faqs",Auth, HandleErrors(getAllFaqList));
PageManagementRoutes.patch("/edit/:pageId",Auth, HandleErrors(editFaqs));
PageManagementRoutes.get("/:id",Auth, HandleErrors(getPageProviderById));

export default PageManagementRoutes;
