import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";

import {
  getcommunitylist,
  searchcommunitylist,
  getcommunitydetail,
} from "../../controllers/admincontrollers/CommunityListController";

const CommunityAdminRoutes = express.Router();
CommunityAdminRoutes.get("/community-list", Auth, HandleErrors(getcommunitylist));
CommunityAdminRoutes.get("/search", Auth, HandleErrors(searchcommunitylist));
CommunityAdminRoutes.get("/detail/:_id", Auth, HandleErrors(getcommunitydetail));
export default CommunityAdminRoutes;
