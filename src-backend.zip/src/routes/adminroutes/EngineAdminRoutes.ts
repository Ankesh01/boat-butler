import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";
// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
    getenginelist,
    searchenginelist,
    createEngines,
    getEngineById,
    editEngine
} from "../../controllers/admincontrollers/EngineListController";


// import Validation from "../validationSchema/authSchema"

const EngineAdminRoutes = express.Router();
EngineAdminRoutes.get("/engine-list",Auth, HandleErrors(getenginelist));
EngineAdminRoutes.get("/search",Auth, HandleErrors(searchenginelist));
EngineAdminRoutes.post("/create", Auth, HandleErrors(createEngines));
EngineAdminRoutes.get("/:id", Auth, HandleErrors(getEngineById));

EngineAdminRoutes.patch("/edit/:engineId", Auth, HandleErrors(editEngine));
export default EngineAdminRoutes;