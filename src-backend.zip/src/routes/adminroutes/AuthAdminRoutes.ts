import express from "express";

import HandleErrors from "../../middlewares/handleError";
import Auth from "../../middlewares/auth";
// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
  login,
  forgotPassword,
  resetPassword,
} from "../../controllers/admincontrollers/AuthAdminController";


// import Validation from "../validationSchema/authSchema"

const authAdminRoutes = express.Router();
authAdminRoutes.post("/login", HandleErrors(login));
authAdminRoutes.post("/forgot-password", HandleErrors(forgotPassword));
authAdminRoutes.post("/reset-password", HandleErrors(resetPassword));   

export default authAdminRoutes;
