import express from "express";

import HandleErrors from "../middlewares/handleError";
// import HttpRequestValidation from "../middlewares/requestValidtion";

import {
  login,
  signup,
  matchToken,
  sendOtp,
  otpVerification,
  profile,
  getUserDetail,
  socialLogin,
  changePassword,
  deleteUser,
  clearFcmToken
} from "../controllers/AuthController";

import {
  loginValidation,
  signUpValidation,
  profileValidation,
  forgotPasswordValidation,
} from "../validationSchema/validation";
import Auth from "../middlewares/auth";
// import Validation from "../validationSchema/authSchema"

const authRoutes = express.Router();

authRoutes.post("/login", HandleErrors(login));
authRoutes.put("/password-reset", HandleErrors(sendOtp));
authRoutes.post("/signup", HandleErrors(signup));
authRoutes.patch("/change-password", HandleErrors(changePassword));
authRoutes.post("/otp-verification", HandleErrors(otpVerification));
authRoutes.get("/match-token", Auth, HandleErrors(matchToken));
authRoutes.post("/profile", profileValidation, Auth, HandleErrors(profile));
authRoutes.post("/social-login", HandleErrors(socialLogin));
authRoutes.get("/get-user/:id", HandleErrors(getUserDetail));
authRoutes.delete("/:id/delete", HandleErrors(deleteUser));
authRoutes.get("/:userId/clear-token", Auth, HandleErrors(clearFcmToken))

// authRoutes.post("/social-signup", HandleErrors(socialSignup));

export default authRoutes;
