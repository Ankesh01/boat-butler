import express from "express";

import HandleErrors from "../middlewares/handleError";

import {
  create,
  getEngineMakeList,
  getBoatDetailById,
  getBoatList,
  searchFilters,
  editBoatById,
  getBoatServices,
} from "../controllers/BoatController";
import Auth from "../middlewares/auth";
// import Validation from "../validationSchema/authSchema"

const boatRoutes = express.Router();

boatRoutes.post("/create",  Auth, HandleErrors(create));
boatRoutes.get("/get-engine-make",Auth,  HandleErrors(getEngineMakeList));
boatRoutes.get("/get-boat-list/:id",Auth, HandleErrors(getBoatList));
boatRoutes.get("/get-boat/:boatId",Auth, HandleErrors(getBoatDetailById));
boatRoutes.post("/search",Auth, HandleErrors(searchFilters));
boatRoutes.post("/edit-boat/:boatId",Auth, HandleErrors(editBoatById));
boatRoutes.get("/get-boat-services/:userId",Auth, HandleErrors(getBoatServices));

export default boatRoutes;
