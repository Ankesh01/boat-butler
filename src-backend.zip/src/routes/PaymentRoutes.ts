import express from "express";
import Auth from "../middlewares/auth";

import HandleErrors from "../middlewares/handleError";

import {
    create
  } from "../controllers/PaymentContoller";

const paymentRoutes = express.Router();

paymentRoutes.post("/create",Auth, HandleErrors(create));


export default paymentRoutes ;
