import express from "express";
import HandleErrors from "../middlewares/handleError";
import Auth from "../middlewares/auth";

import { getPresignedUrl, deleteFiles } from "../controllers/FileController";

const fileRoutes = express.Router();

fileRoutes.post("/presignedurl", Auth, HandleErrors(getPresignedUrl));
fileRoutes.post("/delete", Auth, HandleErrors(deleteFiles));

export default fileRoutes;
