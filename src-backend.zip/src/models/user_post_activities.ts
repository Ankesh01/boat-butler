// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { UserPostActivitiesSchema } from "../Interfaces/schemaInterfaces";

const userPostActivitiesSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    saved_post_ids: {
      type: Array,
    },
    shared_post_ids: {
      type: Array,
    },
    liked_post_ids: {
      type: Array,
    },
    replied_post_ids: {
      type: Array,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

userPostActivitiesSchema.set("toObject", { virtuals: true });
userPostActivitiesSchema.set("toJSON", { virtuals: true });

const UserPostActivities = mongoose.model<UserPostActivitiesSchema>(
  "user_post_activities",
  userPostActivitiesSchema
);

export { UserPostActivities, UserPostActivitiesSchema };
