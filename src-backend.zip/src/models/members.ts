import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { MemberSchema } from "../Interfaces/schemaInterfaces";

const memberSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
      required: true,
    },
    image: {
      type: String,
    },
    role: {
      type: String,
    },
    experience: {
      type: Number,
    },
    member_since: {
      type: String,
    },
    job_completed: {
      type: Number,
    },
    phone: {
      type: String,
      required: true,
      unique: true,
    },
    branch: {
      type: String,
      required: true,
    },
    ssn: {
      type: Number,
      required: true,
      unique: true,
    },
    documents: {
      type: Object,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

memberSchema.set("toObject", { virtuals: true });
memberSchema.set("toJSON", { virtuals: true });

const Member = mongoose.model<MemberSchema>("members", memberSchema);

export { Member, MemberSchema };
