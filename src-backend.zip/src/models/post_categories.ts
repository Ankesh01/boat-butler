// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { PostCategoriesSchema } from "../Interfaces/schemaInterfaces";

const postcategoriesSchema = new mongoose.Schema(
  {
    title: {
      type: String,
    },
    is_active: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

postcategoriesSchema.set("toObject", { virtuals: true });
postcategoriesSchema.set("toJSON", { virtuals: true });

const PostCategories = mongoose.model<PostCategoriesSchema>(
  "post_categories",
  postcategoriesSchema
);

export { PostCategories, PostCategoriesSchema };
