import mongoose, { Schema } from "mongoose";
import { ForumSchema } from "../Interfaces/schemaInterfaces";

const forumSchema = new mongoose.Schema(
  {
    title: {
      type: String,
    },
    description: {
      type: String,
    },
    status: {
      type: String,
      enum: ["Active", "Archived", "Blocked"],
      default: "Active",
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

forumSchema.set("toObject", { virtuals: true });
forumSchema.set("toJSON", { virtuals: true });

const Forum = mongoose.model<ForumSchema>("forum", forumSchema);

export { Forum, ForumSchema };
