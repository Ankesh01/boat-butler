import mongoose, { Schema } from "mongoose";
import { ICommunicationTemplates } from "../Interfaces/schemaInterfaces";

const communicationTemplates = new mongoose.Schema(
  {
    provider_id: {
      type: Schema.Types.ObjectId,
      ref: "providers",
      required: true,
    },
    title: {
      type: String,
    },
    description: {
      type: String,
      length: 1000,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

communicationTemplates.set("toObject", { virtuals: true });
communicationTemplates.set("toJSON", { virtuals: true });

const CommunicationTemplates = mongoose.model<ICommunicationTemplates>(
  "communication_templates",
  communicationTemplates
);

export { CommunicationTemplates, ICommunicationTemplates };
