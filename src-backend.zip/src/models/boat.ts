// import { string } from "joi";
import mongoose, {Schema} from "mongoose";
import {BoatSchema} from "../Interfaces/schemaInterfaces";

const boatSchema = new mongoose.Schema(
    {
        user_id: {
            type: Schema.Types.ObjectId,
            ref: "users",
        },

        title: {
            type: String,
            // required: true
        },

        date_of_bought: {
            type: Date,
        },
        seller_phone: {
            type: String,
        },
        registration_id: {
            type: String,
        },
        vin: {
            type: String,
        },
        make: {
            type: String,
        },
        model: {
            type: String,
        },
        year_of_hull: {
            type: Date,
        },
        engine: {
            type: Object,

        },
        other_equipments: {
            type: Array
        },
        photos: {
            type: Array,
        },

    },
    {timestamps: {createdAt: "created_ts", updatedAt: "updated_ts"}}
);

boatSchema.set("toObject", {virtuals: true});
boatSchema.set("toJSON", {virtuals: true});

const Boat = mongoose.model<BoatSchema>("boats", boatSchema);

export {Boat, BoatSchema};
