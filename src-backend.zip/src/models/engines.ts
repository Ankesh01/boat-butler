// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import {EnginesSchema, IMaintenance} from "../Interfaces/schemaInterfaces";

const engineSchema = new mongoose.Schema(
    {
        make: {
            type: String,
            required: true
        },
        model: {
            type: String,
            required: true
        },
        hp: {
            type: Number,
        },
        dry_weight: {
            type: Number,
        },
        start_type: {
            type: String,
        },
        tilt_trim: {
            type: String,
        },
        fuel_type: {
            type: String,
        },
        year: {
            type: Number,
        },
        strock_series: {
            type: String,
        },
        maintenance_settings: {
            type: Object,
        }

    },
    { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

engineSchema.set("toObject", { virtuals: true });
engineSchema.set("toJSON", { virtuals: true });

const Engines = mongoose.model<EnginesSchema>("engines", engineSchema);

export { Engines, EnginesSchema };
