import mongoose, { Schema } from "mongoose";
import { SubscriptionSchema } from "../Interfaces/subscriptionInterfaces";

const subscriptionSchema = new mongoose.Schema(
  {

    title: {
      type: String,
    },

    price: {
      type: Number,
    },
    benefits: {
      type: Object,
    },
    slug: {
      type: String,
    },
    
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

subscriptionSchema.set("toObject", { virtuals: true });
subscriptionSchema.set("toJSON", { virtuals: true });

const subscription_plans = mongoose.model<SubscriptionSchema>("subscription_plans", subscriptionSchema);

export { subscription_plans , SubscriptionSchema };
