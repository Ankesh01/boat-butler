// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { PostSchema } from "../Interfaces/schemaInterfaces";

const postSchema = new mongoose.Schema(
  {
    post_category_id: {
      type: Schema.Types.ObjectId,
      ref: "post_categories",
    },
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },
    type: {
      type: String,
      enum: ["community", "forum"],
    },
    type_item_id: {
      type: String,
    },
    title: {
      type: String,
    },
    description: {
      type: String,
    },
    total: {
      type: Object,
    },
    media_file: {
      type: String,
    },
    status: {
      type: String,
      enum: [
        "Pending",
        "Draft",
        "Published",
        "Archived",
        "Blocked",
        "Reported",
      ],
      //   default: "Pending",
    },
    reported: {
      type: Object,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

postSchema.set("toObject", { virtuals: true });
postSchema.set("toJSON", { virtuals: true });

const Post = mongoose.model<PostSchema>("posts", postSchema);

export { Post, PostSchema };
