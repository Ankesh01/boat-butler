// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { PagesSchema } from "../Interfaces/pagesInterface";

const pageSchema = new mongoose.Schema(
  {
    title: {
      type: String,
    },
    slug: {
      type: String,
    },
    content: {
      type: String,
    },
    is_faq: {
      type: Number,
    },
    status: {
      type: Number,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

pageSchema.set("toObject", { virtuals: true });
pageSchema.set("toJSON", { virtuals: true });

const Pages = mongoose.model<PagesSchema>("pages", pageSchema);

export { Pages, PagesSchema };
