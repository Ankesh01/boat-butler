import mongoose, { Schema } from "mongoose";
import { ReminderSchema } from "../Interfaces/remindersInterface";

const ReminderSchema = new mongoose.Schema(
  {
    user_id: {
      type: Schema.Types.ObjectId,
      ref: "users",
    },

    title: {
      type: String,
    },

    notes: {
      type: String,
    },
    due_start_datetime: {
      type: Date,
    },
    due_end_datetime: {
      type: Date,
    },
    status: {
      type: String,
      enum: ["Pending", "Completed"],
    },
    repeat: {
      type: Number,
      // enum: ["15 Minutes", "30 Minutes", "60 Minutes"],
    },
    priority: {
      type: String,
      enum: ["High", "Medium", "Low"],
    },
      timezone: {
      type: String,
    },
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

ReminderSchema.set("toObject", { virtuals: true });
ReminderSchema.set("toJSON", { virtuals: true });

const Reminders = mongoose.model<ReminderSchema>("reminders", ReminderSchema);

export { Reminders, ReminderSchema };
