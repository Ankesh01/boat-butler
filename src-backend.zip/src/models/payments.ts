// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { PaymentSchema } from "../Interfaces/schemaInterfaces";

const PaymentSchema = new mongoose.Schema(
  {
    user_id: {
        type: Schema.Types.ObjectId,
        ref: "users",
      },
    subscription_id: {
        type: String,
        // ref: "subscription_plans",
      },
    plan_id: {
        type: Schema.Types.ObjectId,
        ref: "subscription_plans",
      },

    transaction_id: {
        type: String,
      },
    transaction_date: {
        type: Date,
      },

    mode: {
      type: String,
    },
   
    status: {
    type: String,
    // enum: ["paid", "pending","failed"]
    },
  
  },
  { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

PaymentSchema.set("toObject", { virtuals: true });
PaymentSchema.set("toJSON", { virtuals: true });

const Payments = mongoose.model<PaymentSchema>("payments", PaymentSchema);

export { Payments, PaymentSchema };
