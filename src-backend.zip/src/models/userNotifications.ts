// import { string } from "joi";
import mongoose, { Schema } from "mongoose";
import { IUserNotificationSchema } from "../Interfaces/schemaInterfaces";

const userNotificationsSchema = new mongoose.Schema(
    {
        user_id: {
            type: Schema.Types.ObjectId,
            ref: "users",
        },
        type: {
            type: String,
            enum : ["reminders", "boat_services"]
        },
        type_item_id: {
            type: String,
        },
        message : {
            type : Object
        },
        send_status : {
            type : Number,
        },
        due_date : {
            type : Date,
        }
    },
    { timestamps: { createdAt: "created_ts", updatedAt: "updated_ts" } }
);

userNotificationsSchema.set("toObject", { virtuals: true });
userNotificationsSchema.set("toJSON", { virtuals: true });

const UserNotifications = mongoose.model<IUserNotificationSchema>("user_notifications", userNotificationsSchema);

export { UserNotifications, IUserNotificationSchema };
